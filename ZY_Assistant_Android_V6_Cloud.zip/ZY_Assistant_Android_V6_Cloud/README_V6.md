# ZY辅助 V6 云端识别桥接（测试版）

该工程保留 V5 SafeStart 相机、HUD、横竖屏、毛玻璃/黑色胶囊控制界面。

- **手机端 AI识别 改为云端模式**：默认关闭且不再加载本地 MediaPipe ObjectDetector。点击开关，首次输入 HTTPS `/detect` 地址和 `DETECT_TOKEN`。摄像头画面仍在手机预览，抽帧约 1.2 秒一次在后台上传 JPEG，UI 主线程不等网络，失败只显示消息，不直接退出。
- **云端 YOLO**：配套 `cloud_server` 由 YOLO11n 返回人物真实坐标、置信度，支持开启时 YOLO11n-pose 返回骨骼。第一次请求可能需要下载模型，CPU 服务器推理延迟依赖配置。
- **识别确认**：最小置信度 0.25，同一全画面连续三次请求中至少两次匹配才显示人物框。1080p 分辨率不等于 YOLO 输入 1080p，默认服务端推理 `imgsz=960`，不保证更远的识别距离。
- **现有 hcnsec API**：**不能代替 YOLO 人物检测接口**。此项目只用其聊天接口为检测到的人数生成可选文字解释（HUD 帮助 → AI解读）；必须在服务器环境中配置 `HCNSEC_API_KEY`，不能存到 APK 或 GitHub。
- 图片仅发往你配置的检测服务器，服务端仅将**人物数量**发送到 hcnsec，不发送原始图片。请确认服务器和上游的数据处理条款。

## 服务器

将 `cloud_server/` 作为 Docker Web Service 部署至支持 Python + CPU 推理的平台。Dockerfile 在该目录。至少建议 1GB 以上内存（实际内存需求可能更高），首启会下载模型，需要出站网络与持久缓存。需要公网 HTTPS，例如 `https://your-service.example.com`。

服务器环境变量：

- `DETECT_TOKEN`: 自己新生成的随机令牌，仅用于保护 `/detect` 与 `/explain`；不要使用 hcnsec 的 `sk-` 密钥作为这个令牌。
- `HCNSEC_API_KEY`: 重新生成的 hcnsec API 密钥，可选。仅用于 `/explain` 文本分析。
- `HCNSEC_MODEL`: 可选，默认为 `DeepSeek-V4-Flash`。
- `YOLO_DEVICE`: 可选，CPU 环境默认 `cpu`。
- `YOLO_TILES`: 可选，设为 `2` 开启 2×2 重叠分块 + 全帧检测（计算耗时与费用显著增加；默认 `1`）。

测试 `GET /health` 应返回 `ok=true`、`has_token=true`。打开 ZY辅助，点黑色胶囊展开，打开 AI识别，填入服务器域名加 `/detect`，另填 `DETECT_TOKEN`。只填写 `https://api.hcnsec.cn/v1` 不能执行人物检测。

## 编译 Android

工程目录下执行 `gradle --no-daemon :app:assembleDebug`，或上传伴随文件 `build_zy_v6_cloud.yml` 到 GitHub 仓库 `.github/workflows/build_zy_v6_cloud.yml`，工作流自动对已有 V4 ZIP 打 V6 源码补丁并生成 APK Artifact。

注意：这次是源代码级的接入和测试，必须完成 **服务器部署 + GitHub Actions 实际 APK 编译 + 手机实测** 后才能确认修复闪退。构建成功不证明远程接口响应正确。

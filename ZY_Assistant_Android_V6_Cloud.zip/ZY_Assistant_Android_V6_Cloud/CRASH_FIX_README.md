# ZY辅助 V5 SafeStart — 相机启动闪退修复与诊断

## 修复重点
- 崩溃位置：启动页正常、点击“开始使用”进入 CameraActivity 时崩溃（用户反馈）。没有 Android logcat，故无法断言单一根因。
- 安装启动阶段异常记录器 CrashGuard：记录最后一个启动阶段及 Java 未捕获异常堆栈（本地保存，不上传）。
- 如果上次进入摄像头未成功，下次会自动进入“兼容模式”：640×360 优先、TextureView 兼容实现、暂不初始化 MediaPipe AI，让相机先稳定显示。
- 兼容模式下可手动点击 HUD 的“AI识别”开关触发离线模型加载。
- 如果 Java 层的 MediaPipe 初始化出错，现在会显示错误，不再让工作线程直接终止进程；同时避免进入摄像头时两个全屏硬件层占用 GPU 内存。
- 完整模式保留原有优先 1080p 摄像头采集、分块远距检测、0.25 阈值、RegionEvidence 2/3 区域确认、骨骼和 HUD。
- 修复 V4 prepareBitmap 中的重复 `bytes` 变量编译错误。
- 新版本 versionCode=9，同一 applicationId，可覆盖安装原版（签名相同时）。

## 安装后怎么反馈
1. 点击“开始使用”。若仍崩溃，重新打开 App；启动页会显示“兼容模式进入”。
2. 点击提示文字查看启动诊断，可复制错误详情发送给开发者。
3. 兼容模式能进入摄像头，表示问题偏向高分辨率 CameraX 或 AI 模型启动，需要根据错误信息定位。
4. 若兼容模式也无法显示相机，检查应用相机权限和设备 logcat；Java 启动日志不足以定位 native SIGSEGV、系统杀进程等错误。
5. 可在启动诊断中选择“尝试完整模式”，退出重开后恢复增强远距。

## 构建
在 GitHub 仓库根目录上传 `ZY_Assistant_Android_V5_SafeStart.zip`，并将 `build_zy_v5_safestart.yml` 上传至 `.github/workflows/`，GitHub Actions 的 `ZY V5 SafeStart APK` 成功后从 Artifacts 下载 `app-debug.apk`。

注意：CI 编译成功≠实机闪退已解决；必须安装测试。

"""ZY Cloud Bridge: YOLO person detection + optional HCNSEC text explanation.

No user images are sent to HCNSEC; its API receives only numeric detection counts.
Put HCNSEC_API_KEY in host environment, never in repository or Android APK.
"""
import io
import os
import threading
import json
from urllib.request import Request as UrlRequest, urlopen
from urllib.error import HTTPError

import numpy as np
from PIL import Image
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field

app = FastAPI(title="ZY辅助云端目标检测 V6", version="0.9.0")
_detector = None
_pose_detector = None
_lock = threading.Lock()


def require_token(token: str | None):
    expected = os.getenv("DETECT_TOKEN", "")
    if not expected:
        raise HTTPException(503, detail="服务器未设置 DETECT_TOKEN")
    import hmac
    if not hmac.compare_digest(token or "", expected):
        raise HTTPException(401, detail="Invalid detector token")


def get_model(pose: bool):
    global _detector, _pose_detector
    from ultralytics import YOLO
    with _lock:
        if pose:
            if _pose_detector is None:
                _pose_detector = YOLO("yolo11n-pose.pt")
            return _pose_detector
        if _detector is None:
            _detector = YOLO("yolo11n.pt")
        return _detector


def iou(a, b):
    x1 = max(a['x1'], b['x1']); y1 = max(a['y1'], b['y1'])
    x2 = min(a['x2'], b['x2']); y2 = min(a['y2'], b['y2'])
    inter = max(0., x2-x1)*max(0., y2-y1)
    area1 = (a['x2']-a['x1'])*(a['y2']-a['y1'])
    area2 = (b['x2']-b['x1'])*(b['y2']-b['y1'])
    return inter / max(1e-6, area1+area2-inter)


def make_pose(raw, width, height):
    """YOLO 17 COCO keypoints -> MediaPipe 33-slot layout expected by existing HUD."""
    # YOLO: shoulders 5,6; elbows 7,8; wrists 9,10; hips 11,12; knees 13,14; ankles 15,16
    indices = {11: 5, 12: 6, 13: 7, 14: 8, 15: 9, 16: 10,
               23: 11, 24: 12, 25: 13, 26: 14, 27: 15, 28: 16}
    result = [[0.0, 0.0, 0.0] for _ in range(33)]
    for to_idx, from_idx in indices.items():
        if from_idx < len(raw):
            x, y, confidence = raw[from_idx]
            result[to_idx] = [float(x / width), float(y / height), float(confidence)]
    return result


@app.get("/health")
def health():
    return {"ok": True, "service": "ZY person detection", "has_token": bool(os.getenv('DETECT_TOKEN'))}


@app.post("/detect")
async def detect(request: Request, pose: int = 0, x_detector_token: str | None = Header(default=None)):
    require_token(x_detector_token)
    if request.headers.get("content-type", "").split(';')[0] != "image/jpeg":
        raise HTTPException(415, detail="image/jpeg required")
    data = await request.body()
    if not data or len(data) > 2_000_000:
        raise HTTPException(413, detail="Expected JPEG <= 2MB")
    try:
        pic = Image.open(io.BytesIO(data)).convert("RGB")
        w, h = pic.size
        if not 0 < w <= 4096 or not 0 < h <= 4096:
            raise ValueError("invalid image dimensions")
    except Exception:
        raise HTTPException(400, detail="Invalid JPEG")
    # CPU inference at a bounded resolution. Remote clients limit to ~1 fps.
    model = get_model(bool(pose))
    # Async FastAPI endpoint offloads inference to the thread pool to avoid blocking the event loop.
    from starlette.concurrency import run_in_threadpool

    # 1 pass is fastest; optional 2x2 overlapping tiles improves small/far people at extra cost.
    tiles = 1 if pose else max(1, min(2, int(os.getenv('YOLO_TILES', '1'))))
    def infer():
        areas = [(0, 0, w, h)]
        if tiles == 2:
            for row in range(2):
                for col in range(2):
                    areas.append((max(0,int((col/2-.06)*w)),max(0,int((row/2-.06)*h)),
                                  min(w,int(((col+1)/2+.06)*w)),min(h,int(((row+1)/2+.06)*h))))
        found_local=[]
        poses_local=[]
        with _lock:
            for x0,y0,x1,y1 in areas:
                image = pic.crop((x0,y0,x1,y1))
                out = model.predict(source=np.asarray(image), imgsz=960, conf=0.25,
                                    classes=[0], verbose=False,
                                    device=os.getenv('YOLO_DEVICE', 'cpu'))[0]
                if out.boxes is None: continue
                coords = out.boxes.xyxy.cpu().numpy()
                probs = out.boxes.conf.cpu().numpy()
                for idx, (r, conf) in enumerate(zip(coords, probs)):
                    box=dict(label="person", confidence=float(conf), x1=float(r[0]+x0),
                             y1=float(r[1]+y0), x2=float(r[2]+x0), y2=float(r[3]+y0))
                    if any(iou(box, old) > .5 for old in found_local):continue
                    found_local.append(box)
                if bool(pose) and out.keypoints is not None:
                    keypoints=out.keypoints.data.cpu().numpy()
                    poses_local=[make_pose(p, w, h) for p in keypoints]
        return found_local,poses_local
    found,poses=await run_in_threadpool(infer)
    return {"width": w, "height": h, "detections": found, "poses": poses}


class ExplainRequest(BaseModel):
    people_count: int = Field(ge=0, le=1000)


@app.post('/explain')
async def explain(data: ExplainRequest, x_detector_token: str | None = Header(default=None)):
    require_token(x_detector_token)
    secret = os.getenv('HCNSEC_API_KEY', '')
    if not secret:
        raise HTTPException(503, detail='HCNSEC_API_KEY is not set on server')
    reqbody = json.dumps({
        'model': os.getenv('HCNSEC_MODEL', 'DeepSeek-V4-Flash'),
        'stream': False,
        'messages': [
            {'role': 'system', 'content': '简洁解释检测数据的局限性。不能声称没看到的细节。'},
            {'role': 'user', 'content': f'摄像头目标检测当前确认了{data.people_count}个人。请用一句中文解释结果和误差可能性。'}
        ]
    }).encode('utf8')
    from starlette.concurrency import run_in_threadpool
    def call():
        req = UrlRequest('https://api.hcnsec.cn/v1/chat/completions', data=reqbody,
                         headers={'Content-Type': 'application/json', 'Authorization': 'Bearer '+secret},
                         method='POST')
        with urlopen(req, timeout=18) as res:
            if int(res.status) != 200:
                raise ValueError('Provider error')
            raw = res.read(65536)
        return json.loads(raw.decode('utf8'))['choices'][0]['message']['content']
    try:
        explanation = await run_in_threadpool(call)
        return {'explanation': str(explanation)[:2000]}
    except Exception:
        raise HTTPException(502, detail='AI text explanation temporarily unavailable')

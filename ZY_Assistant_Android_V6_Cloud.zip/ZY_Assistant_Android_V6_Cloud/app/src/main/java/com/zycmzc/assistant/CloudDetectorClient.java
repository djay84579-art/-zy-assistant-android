package com.zycmzc.assistant;

import android.graphics.Bitmap;
import android.graphics.RectF;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** YOLO /detect client. HCNSEC chat is used only by the proxy's /explain endpoint. */
final class CloudDetectorClient {
    static final class Result {
        final List<RegionEvidence.Box> people;
        final List<float[][]> poses;
        Result(List<RegionEvidence.Box> people,List<float[][]> poses){
            this.people=people;this.poses=poses;
        }
    }
    private static HttpURLConnection open(String endpoint,String token,String contentType) throws Exception {
        if(!endpoint.startsWith("https://"))throw new IOException("仅允许 HTTPS");
        HttpURLConnection conn=(HttpURLConnection)new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(14000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type",contentType);
        if(token!=null&&!token.isEmpty())conn.setRequestProperty("X-Detector-Token",token);
        return conn;
    }
    private static byte[] readBounded(InputStream stream) throws Exception {
        if(stream==null)throw new IOException("服务器返回空响应");
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096];int n;
            while((n=in.read(buffer))!=-1){
                if(out.size()+n>131072)throw new IOException("API响应过大");
                out.write(buffer,0,n);
            }
            return out.toByteArray();
        }
    }
    private static String response(HttpURLConnection conn) throws Exception {
        int status=conn.getResponseCode();
        if(status!=200){
            // Do not display server responses: some gateways echo credentials.
            throw new IOException("HTTP "+status+" · 请检查服务地址与访问令牌");
        }
        return new String(readBounded(conn.getInputStream()),StandardCharsets.UTF_8);
    }
    static Result detect(Bitmap bitmap,String endpoint,String token,float confidence,boolean pose) throws Exception {
        String url=endpoint+(pose?"?pose=1":"");
        byte[] payload;
        try(ByteArrayOutputStream out=new ByteArrayOutputStream()){
            bitmap.compress(Bitmap.CompressFormat.JPEG,76,out);
            payload=out.toByteArray();
        }
        if(payload.length>2_000_000)throw new IOException("画面过大，建议降低分析分辨率");
        HttpURLConnection conn=open(url,token,"image/jpeg");
        try {
            conn.setFixedLengthStreamingMode(payload.length);
            try(OutputStream out=conn.getOutputStream()){out.write(payload);}
            JSONObject obj=new JSONObject(response(conn));
            int remoteW=obj.optInt("width",bitmap.getWidth());
            int remoteH=obj.optInt("height",bitmap.getHeight());
            if(remoteW<=0||remoteH<=0)throw new IOException("服务器返回无效尺寸");
            float sx=bitmap.getWidth()/(float)remoteW,sy=bitmap.getHeight()/(float)remoteH;
            List<RegionEvidence.Box> people=new ArrayList<>();
            JSONArray detections=obj.optJSONArray("detections");
            if(detections==null)throw new IOException("API未返回 detections 字段（不是人物检测接口）");
            for(int i=0;i<detections.length();i++){
                JSONObject d=detections.getJSONObject(i);
                if(!"person".equalsIgnoreCase(d.optString("label","")))continue;
                float score=(float)d.optDouble("confidence",0);
                if(!Float.isFinite(score)||score<confidence||score>1)continue;
                float l=(float)d.getDouble("x1")*sx;
                float t=(float)d.getDouble("y1")*sy;
                float r=(float)d.getDouble("x2")*sx;
                float b=(float)d.getDouble("y2")*sy;
                if(!Float.isFinite(l)||!Float.isFinite(t)||!Float.isFinite(r)||!Float.isFinite(b))continue;
                l=Math.max(0,Math.min(l,bitmap.getWidth()));
                t=Math.max(0,Math.min(t,bitmap.getHeight()));
                r=Math.max(0,Math.min(r,bitmap.getWidth()));
                b=Math.max(0,Math.min(b,bitmap.getHeight()));
                if(r>l&&b>t)people.add(new RegionEvidence.Box(l,t,r,b,score));
            }
            List<float[][]> poses=new ArrayList<>();
            JSONArray allPoses=obj.optJSONArray("poses");
            if(pose && allPoses!=null){
                for(int i=0;i<allPoses.length();i++){
                    JSONArray body=allPoses.getJSONArray(i);
                    float[][] points=new float[33][3];
                    for(int j=0;j<Math.min(body.length(),33);j++){
                        JSONArray pt=body.getJSONArray(j);
                        points[j][0]=(float)pt.getDouble(0);
                        points[j][1]=(float)pt.getDouble(1);
                        points[j][2]=(float)pt.getDouble(2);
                    }
                    poses.add(points);
                }
            }
            return new Result(people,poses);
        } finally {conn.disconnect();}
    }
    static String explain(String detectEndpoint,String token,int people) throws Exception {
        String url=detectEndpoint.substring(0,detectEndpoint.length()-"/detect".length())+"/explain";
        HttpURLConnection conn=open(url,token,"application/json; charset=utf-8");
        try {
            JSONObject body=new JSONObject();body.put("people_count",people);
            byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(data.length);
            try(OutputStream out=conn.getOutputStream()){out.write(data);}
            return new JSONObject(response(conn)).optString("explanation","暂无文字解读");
        } finally {conn.disconnect();}
    }
}

package com.zycmzc.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.text.InputType;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android CameraX preview stays fluid; expensive AI is decimated on a worker. */
public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int CAMERA_REQUEST = 201;
    private PreviewView preview;
    private DetectorHudView hud;
    private StartupCodeView startupCode;
    // Cloud YOLO returns actual person boxes; a 2/3 spatial observation filter prevents false positives.
    private volatile float scoreThreshold=.25f;
    private static final Size[] ANALYSIS_RESOLUTIONS = {
        new Size(1920,1080), new Size(1280,720), new Size(640,360)
    };
    private final RegionEvidence personEvidence = new RegionEvidence();
    private ExecutorService worker;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;
    private volatile boolean destroyed;
    private volatile boolean objectOn = false;
    private volatile boolean poseOn = false; // opt in for smoothest default experience
    private long lastObjectTime;
    private byte[] pixels;
    private ByteBuffer pixelsBuffer;
    private Bitmap rawBitmap, rotatedBitmap;
    private Canvas rotatedCanvas;
    private final Matrix rotationMatrix = new Matrix();
    private final Paint conversionPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private boolean requestedPortrait;
    private boolean safeMode;
    private volatile boolean startupValidated;
    private volatile String roboflowKey="";
    private int lastCloudPersons;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        CrashGuard.install(this);
        CrashGuard.stage(this,"CameraActivity.onCreate");
        safeMode = getIntent().getBooleanExtra("zy_safe_mode",false);
        objectOn=false; // Never auto-load the crashing on-device AI model.
        try {roboflowKey=RoboflowKeyStore.load(this);} catch(Exception ignored) {
            roboflowKey=""; // e.g. key invalidated after device restore; user can re-enter.
        }
        // Never copy the V6 plaintext cloud_token setting into the new key store.
        getSharedPreferences("zy",MODE_PRIVATE).edit()
            .remove("cloud_endpoint").remove("cloud_token").apply();
        requestedPortrait = getSharedPreferences("zy", MODE_PRIVATE).getBoolean("portrait",false);
        setRequestedOrientation(requestedPortrait ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        CrashGuard.stage(this,"初始化 CameraX 预览控件");
        preview = new PreviewView(this);
        // PERFORMANCE uses SurfaceView on supported devices; avoids extra TextureView copies.
        preview.setImplementationMode(safeMode ? PreviewView.ImplementationMode.COMPATIBLE
            : PreviewView.ImplementationMode.PERFORMANCE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        CrashGuard.stage(this,"初始化 HUD 控件");
        hud = new DetectorHudView(this,this);
        hud.setRecognitionState(false); // Cloud detection is opt-in, safe by default.
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        startupCode = new StartupCodeView(this);
        root.addView(startupCode,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        worker = Executors.newSingleThreadExecutor();
        CrashGuard.stage(this, "启动摄像头（云端 AI 默认关闭）");
        hud.setMessage("摄像头启动中 · Roboflow AI 默认关闭");
        startupCode.setAiState("ROBOFLOW/OFF");
        if (checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
            preview.postDelayed(this::startCamera,220);
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==CAMERA_REQUEST) {
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else {hud.setMessage("请允许相机权限才能使用");startupCode.setCameraState("DENIED");}
        }
    }

    private void startCamera() {
        if(destroyed || checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        CrashGuard.stage(this,"获取 CameraProvider");
        ListenableFuture<ProcessCameraProvider> future;
        try { future=ProcessCameraProvider.getInstance(this); }
        catch(Throwable e){
            CrashGuard.note(this,"创建 CameraProvider 失败: " + android.util.Log.getStackTraceString(e));
            hud.setMessage("相机组件无法启动（诊断详情见启动页）");
            return;
        }
        future.addListener(()->{
            if(destroyed)return;
            try {
                cameraProvider=future.get();
                int rotation=preview.getDisplay()==null?getWindowManager().getDefaultDisplay().getRotation():preview.getDisplay().getRotation();
                Exception error=null;
                // Safe mode intentionally begins at 640x360; normal mode still
                // requests 1080p first for remote person detection.
                Size[] resolutions=safeMode?new Size[]{new Size(640,360)}:ANALYSIS_RESOLUTIONS;
                for(Size requested : resolutions){
                    try {
                        CrashGuard.stage(this,"绑定相机 " + requested.getWidth() + "x" + requested.getHeight());
                        // Resolution is expressed in the target display's orientation.
                        Size oriented = (rotation==0 || rotation==2)
                            ? new Size(requested.getHeight(),requested.getWidth()) : requested;
                        Preview p=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
                            .setTargetRotation(rotation).build();
                        p.setSurfaceProvider(preview.getSurfaceProvider());
                        ImageAnalysis analysis=new ImageAnalysis.Builder()
                            .setTargetRotation(rotation)
                            .setTargetResolution(oriented)
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                            .build();
                        analysis.setAnalyzer(worker,this::analyzeFrame);
                        cameraProvider.unbindAll();
                        camera=cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                        worker.execute(personEvidence::clear);
                        hud.clearDetections();
                        hud.setMessage((safeMode?"兼容预览":"Roboflow AI 待开启")
                            + " · 请求 " + oriented.getWidth() + "×" + oriented.getHeight());
                        startupCode.setCameraState("READY");
                        return;
                    } catch(Exception bindException){error=bindException;}
                }
                throw new IllegalStateException("该设备不支持预览+分析组合",error);
            } catch(Throwable e) {
                CrashGuard.note(this,"摄像头绑定失败: " + android.util.Log.getStackTraceString(e));
                hud.setMessage("摄像头启动失败: "+e.getClass().getSimpleName());
                startupCode.setCameraState("ERROR");
            }
        },getMainExecutor());
    }

    /** No local ObjectDetector is constructed. Network IO runs only on CameraX's worker. */
    private void analyzeFrame(ImageProxy frame) {
        try {
            if(destroyed)return;
            if(!startupValidated){startupValidated=true;CrashGuard.stable(this);}
            long now=SystemClock.elapsedRealtime();
            if(!objectOn || roboflowKey.isEmpty() || now-lastObjectTime<1600)return;
            lastObjectTime=now; // Throttle even when the network fails.
            Bitmap bitmap=prepareBitmap(frame);
            int width=bitmap.getWidth(),height=bitmap.getHeight();
            long started=SystemClock.elapsedRealtime();
            CloudDetectorClient.Result result=CloudDetectorClient.detect(
                bitmap,roboflowKey,scoreThreshold);
            long completed=SystemClock.elapsedRealtime();
            personEvidence.observe(0,result.people,completed);
            List<DetectorHudView.Found> out=new ArrayList<>();
            for(RegionEvidence.Box b:personEvidence.confirmed(completed)) {
                out.add(new DetectorHudView.Found(
                    new RectF(b.left,b.top,b.right,b.bottom),"person",b.score));
            }
            lastCloudPersons=out.size();
            int elapsed=(int)(completed-started);
            runOnUiThread(()->{
                if(destroyed)return;
                hud.setDetections(out,width,height,elapsed>0?1000/elapsed:0,elapsed);
                // This published workflow does not output keypoints.
                startupCode.setAiState("CLOUD READY");
            });
        } catch(Exception e) {
            // Never persist raw API exception messages: an upstream gateway might echo credentials.
            String message=(e instanceof java.io.IOException && e.getMessage()!=null)
                ? e.getMessage() : "接口响应异常（"+e.getClass().getSimpleName()+"）";
            CrashGuard.note(this,"Roboflow 检测异常（密钥已隐藏）: "+e.getClass().getSimpleName());
            runOnUiThread(()->{if(!destroyed){
                hud.setMessage("云端识别暂不可用: "+message);
                startupCode.setAiState("CLOUD ERROR");
            }});
        } catch(OutOfMemoryError e) {
            objectOn=false;
            CrashGuard.note(this,"云端检测分配内存失败: "+e);
            runOnUiThread(()->{if(!destroyed){hud.setRecognitionState(false);
                hud.setMessage("内存不足，AI已自动关闭");}});
        } finally {frame.close();}
    }

    /** Reuses pixel byte buffer, raw bitmap and rotation canvas instead of allocating MBs each frame. */
    private Bitmap prepareBitmap(ImageProxy frame) {
        int w=frame.getWidth(),h=frame.getHeight();
        int bytes=w*h*4;
        if(rawBitmap==null || rawBitmap.getWidth()!=w || rawBitmap.getHeight()!=h){
            if(rawBitmap!=null)rawBitmap.recycle();
            rawBitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        }
        ImageProxy.PlaneProxy plane=frame.getPlanes()[0];
        ByteBuffer input=plane.getBuffer();
        int stride=plane.getRowStride(),rowBytes=w*4;
        if(stride==rowBytes){
            // Direct buffer copy avoids allocating + copying an extra 8MB at 1080p.
            input.rewind();rawBitmap.copyPixelsFromBuffer(input);
        } else {
            if(pixels==null || pixels.length!=bytes){
                pixels=new byte[bytes];pixelsBuffer=ByteBuffer.wrap(pixels);
            }
            for(int y=0;y<h;y++){
                input.position(y*stride);
                input.get(pixels,y*rowBytes,rowBytes);
            }
            pixelsBuffer.rewind();rawBitmap.copyPixelsFromBuffer(pixelsBuffer);
        }
        int rotation=frame.getImageInfo().getRotationDegrees();
        if(rotation==0)return rawBitmap;
        int ow=(rotation==90||rotation==270)?h:w;
        int oh=(rotation==90||rotation==270)?w:h;
        if(rotatedBitmap==null || rotatedBitmap.getWidth()!=ow || rotatedBitmap.getHeight()!=oh){
            if(rotatedBitmap!=null)rotatedBitmap.recycle();
            rotatedBitmap=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            rotatedCanvas=new Canvas(rotatedBitmap);
        }
        rotationMatrix.reset();
        rotationMatrix.setRotate(rotation);
        if(rotation==90)rotationMatrix.postTranslate(h,0);
        else if(rotation==180)rotationMatrix.postTranslate(w,h);
        else if(rotation==270)rotationMatrix.postTranslate(0,w);
        rotatedCanvas.drawColor(Color.TRANSPARENT,android.graphics.PorterDuff.Mode.CLEAR);
        rotatedCanvas.drawBitmap(rawBitmap,rotationMatrix,conversionPaint);
        return rotatedBitmap;
    }

    @Override public void onRecognitionChanged(boolean enable){
        if(enable && roboflowKey.isEmpty()) {
            objectOn=false;
            hud.setRecognitionState(false);
            openRoboflowSettings(true);
            return;
        }
        objectOn=enable;
        if(!enable && worker!=null)worker.execute(()->personEvidence.clear());
        hud.setMessage(enable?"Roboflow 云端人物检测开启":"已暂停云端识别");
        startupCode.setAiState(enable?"ROBOFLOW ACTIVE":"ROBOFLOW/OFF");
    }
    private void openRoboflowSettings(boolean startAfterSaving){
        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int p=Math.round(getResources().getDisplayMetrics().density*18);
        form.setPadding(p,p,p,p);
        EditText keyInput=new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setHint(roboflowKey.isEmpty()?"粘贴 Roboflow API Key":"已保存密钥；留空保持不变");
        form.addView(keyInput);
        new AlertDialog.Builder(this).setTitle("Roboflow 人物识别 · V7")
            .setMessage("已绑定你的 ZY Assistant Person Detection 工作流。首次输入 Roboflow API Key；将使用 Android Keystore 加密保存。无需 Cloudflare。\n\n请勿把密钥上传 GitHub。")
            .setView(form).setNegativeButton("取消",(d,w)->{
                if(startAfterSaving){objectOn=false;hud.setRecognitionState(false);}
            })
            .setPositiveButton("保存",(d,w)->{
                String proposed=keyInput.getText().toString().trim();
                if(!proposed.isEmpty()){
                    try {
                        RoboflowKeyStore.save(this,proposed);
                        roboflowKey=proposed;
                    } catch(Exception e) {
                        hud.setMessage("密钥加密保存失败，请检查系统安全设置");
                        objectOn=false;hud.setRecognitionState(false);return;
                    }
                }
                if(roboflowKey.isEmpty()){
                    hud.setMessage("未设置 Roboflow API Key");
                    objectOn=false;hud.setRecognitionState(false);return;
                }
                if(startAfterSaving){objectOn=true;hud.setRecognitionState(true);}
                hud.setMessage("Roboflow 已配置 · "+(objectOn?"识别已开启":"开启 AI识别 开关启动"));
                startupCode.setAiState(objectOn?"ROBOFLOW/ON":"ROBOFLOW/OFF");
            }).show();
    }
    @Override public void onSensitivityChanged(float threshold){scoreThreshold=threshold;}
    @Override public void onPoseChanged(boolean enable){
        poseOn=false;
        hud.setPoseState(false);
        hud.setMessage("该工作流暂未提供骨骼关键点，已保持关闭");
    }
    @Override public void onNightChanged(boolean enable){
        if(camera==null)return;
        try {
            androidx.camera.core.ExposureState exp=camera.getCameraInfo().getExposureState();
            if(exp.isExposureCompensationSupported()){
                int upper=exp.getExposureCompensationRange().getUpper();
                camera.getCameraControl().setExposureCompensationIndex(enable?Math.min(2,upper):0);
            } else hud.setMessage("本机不支持曝光补偿");
        } catch(Exception e){hud.setMessage("夜间增强不可用");}
    }
    @Override public void onRotatePressed(){
        requestedPortrait=!requestedPortrait;
        getSharedPreferences("zy",MODE_PRIVATE).edit().putBoolean("portrait",requestedPortrait).apply();
        setRequestedOrientation(requestedPortrait?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);
        preview.postDelayed(this::startCamera,160);
    }
    @Override public void onClosePressed(){finish();}
    @Override public void onHelpPressed(){
        new AlertDialog.Builder(this).setTitle("ZY辅助 · V7 Roboflow 直连")
            .setMessage("黑色胶囊：点击展开深色控制面板。\n\n"+
                "物品绘制默认关闭，与人物方框、骨骼、射线独立控制。\n\n"+
                "云端检测：不加载本地人物检测模型；由 Roboflow HTTPS 工作流返回真实人物框。\n\n"+
                "本版本自动限制上传画面最长边 1280 像素，尚未做远距分块。弱网时会降频或提示，不能保证实时。\n\n"+
                "骨骼：当前 Roboflow 工作流不提供关键点，因此暂不绘制。\n\n"+
                "横竖屏：点击顶部 ↻ 按钮切换。\n\n"+
                "云端 AI 约每 1.6 秒抽样一帧；每次识别消耗云端额度。\n\n"+
                "距离需要相机标定，尚不提供米数。底部频道：@ZYCMZC")
            .setPositiveButton("设置 API Key",(d,w)->openRoboflowSettings(false))
            .setNegativeButton("关闭",null).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        if(cameraProvider!=null)cameraProvider.unbindAll();
        if(worker!=null){
            worker.execute(()->{
                if(rawBitmap!=null)rawBitmap.recycle();
                if(rotatedBitmap!=null)rotatedBitmap.recycle();
            });
            worker.shutdown();
        }
        super.onDestroy();
    }
}

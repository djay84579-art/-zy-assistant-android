package com.zycmzc.assistant;

import android.graphics.Bitmap;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Direct client for the user's published Roboflow Workflows Cloud API.
 *  The API key is supplied at runtime from Android Keystore, never compiled in. */
final class CloudDetectorClient {
    static final String WORKFLOW_URL = "https://serverless.roboflow.com/cxys-workspace-lzbqi/workflows/zy-assistant-person-detection-1793025687536";
    static final class Result {
        final List<RegionEvidence.Box> people;
        final List<float[][]> poses;
        Result(List<RegionEvidence.Box> people, List<float[][]> poses) {
            this.people = people; this.poses = poses;
        }
    }
    private CloudDetectorClient() {}

    private static byte[] bounded(InputStream input) throws Exception {
        if(input == null) throw new IOException("云端返回空内容");
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[8192]; int n;
            // Some workflows return an annotated preview encoded as base64.
            // Limit the full response so bad inputs never exhaust phone memory.
            while((n = in.read(chunk)) != -1) {
                if(out.size() + n > 6_000_000) throw new IOException("云端响应过大，请在工作流中关闭可视化输出");
                out.write(chunk, 0, n);
            }
            return out.toByteArray();
        }
    }

    static Result detect(Bitmap bitmap, String apiKey, float minConfidence) throws Exception {
        if(apiKey == null || apiKey.trim().isEmpty()) throw new IOException("请先设置 Roboflow API Key");
        // Send a smaller image to cap memory / bandwidth and improve phone smoothness.
        final int maxSide = 1280;
        Bitmap toSend = bitmap;
        int fullW = bitmap.getWidth(), fullH = bitmap.getHeight();
        float ratio = Math.min(1f, maxSide / (float)Math.max(fullW,fullH));
        if(ratio < 1f) {
            toSend = Bitmap.createScaledBitmap(bitmap,
                Math.max(1,Math.round(fullW*ratio)), Math.max(1,Math.round(fullH*ratio)), true);
        }
        byte[] jpg;
        try(ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if(!toSend.compress(Bitmap.CompressFormat.JPEG,68,out)) throw new IOException("JPEG 压缩失败");
            jpg = out.toByteArray();
        } finally {
            if(toSend != bitmap) toSend.recycle();
        }
        if(jpg.length > 1_800_000) throw new IOException("发送画面超过限制，请降低分辨率");
        JSONObject body = new JSONObject();
        body.put("api_key", apiKey);
        JSONObject image = new JSONObject();
        image.put("type", "base64");
        image.put("value", Base64.encodeToString(jpg,Base64.NO_WRAP));
        JSONObject inputs = new JSONObject();
        inputs.put("image",image);
        body.put("inputs",inputs);
        byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
        HttpURLConnection conn=(HttpURLConnection)new URL(WORKFLOW_URL).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(14000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept","application/json");
            conn.setFixedLengthStreamingMode(request.length);
            try(OutputStream out=conn.getOutputStream()) {out.write(request);}
            int status = conn.getResponseCode();
            if(status != 200) {
                // NEVER include response body or URL in diagnostics; some gateways echo credentials.
                if(status==401 || status==403) throw new IOException("Roboflow 密钥无效或无权限 (HTTP "+status+")");
                if(status==429) throw new IOException("Roboflow 调用过于频繁或额度受限 (HTTP 429)");
                throw new IOException("Roboflow API 错误 HTTP "+status);
            }
            String json=new String(bounded(conn.getInputStream()), StandardCharsets.UTF_8);
            return parse(json, fullW, fullH, minConfidence);
        } finally { conn.disconnect(); }
    }

    /** Handles the Workflows response [ { predictions: { image:{}, predictions:[] } } ].
     *  Also accepts object and nested outputs for workflow-version compatibility. */
    static Result parse(String json, int width, int height, float threshold) throws Exception {
        String source=json.trim();
        JSONObject top;
        if(source.startsWith("[")) {
            JSONArray arr=new JSONArray(source);
            if(arr.length()==0) throw new IOException("工作流未返回结果");
            top=arr.optJSONObject(0);
        } else top=new JSONObject(source);
        if(top==null) throw new IOException("工作流结果不是 JSON 对象");

        // Some Roboflow deployments wrap results in `outputs` or `output`.
        JSONArray outputs=top.optJSONArray("outputs");
        if(outputs!=null && outputs.length()>0 && outputs.optJSONObject(0)!=null)
            top=outputs.optJSONObject(0);
        JSONObject output=top.optJSONObject("output");
        if(output!=null)top=output;

        JSONObject predictionsObject=top.optJSONObject("predictions");
        JSONArray predictions=top.optJSONArray("predictions");
        JSONObject dims=top.optJSONObject("image");
        if(predictionsObject!=null) {
            predictions=predictionsObject.optJSONArray("predictions");
            if(predictionsObject.optJSONObject("image")!=null)
                dims=predictionsObject.optJSONObject("image");
        }
        if(predictions==null) throw new IOException("工作流未返回 predictions 列表，请检查模型输出设置");
        float srcW=dims==null?width:(float)dims.optDouble("width",width);
        float srcH=dims==null?height:(float)dims.optDouble("height",height);
        if(!Float.isFinite(srcW)||!Float.isFinite(srcH)||srcW<=0||srcH<=0)
            throw new IOException("云端图像尺寸错误");
        float sx=width/srcW, sy=height/srcH;
        List<RegionEvidence.Box> people=new ArrayList<>();
        for(int i=0;i<predictions.length();i++) {
            JSONObject p=predictions.optJSONObject(i);
            if(p==null) continue;
            String category=p.optString("class",p.optString("label", ""));
            if(!"person".equalsIgnoreCase(category) && !"human".equalsIgnoreCase(category)
                    && !"people".equalsIgnoreCase(category)) continue;
            float score=(float)p.optDouble("confidence",0);
            if(!Float.isFinite(score)||score<threshold||score>1)continue;
            float x=(float)p.optDouble("x",Float.NaN);
            float y=(float)p.optDouble("y",Float.NaN);
            float w=(float)p.optDouble("width",Float.NaN);
            float h=(float)p.optDouble("height",Float.NaN);
            if(!Float.isFinite(x)||!Float.isFinite(y)||!Float.isFinite(w)||!Float.isFinite(h)) continue;
            // Roboflow x/y are CENTER coordinates, not top-left.
            float l=Math.max(0,Math.min(width,(x-w/2f)*sx));
            float t=Math.max(0,Math.min(height,(y-h/2f)*sy));
            float r=Math.max(0,Math.min(width,(x+w/2f)*sx));
            float b=Math.max(0,Math.min(height,(y+h/2f)*sy));
            if(r>l && b>t) people.add(new RegionEvidence.Box(l,t,r,b,score));
        }
        return new Result(people, new ArrayList<>()); // Workflow V1 has no pose keypoints.
    }
}

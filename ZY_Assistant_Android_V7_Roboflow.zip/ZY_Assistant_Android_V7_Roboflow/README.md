# ZY辅助 V7 · Roboflow 直连测试版

已固定你的 **Roboflow 人物检测工作流**：
`https://serverless.roboflow.com/cxys-workspace-lzbqi/workflows/zy-assistant-person-detection-1793025687536`

## 使用方法（安卓手机）

1. 用 GitHub Actions 将 Android 工程编译为 APK，安装后允许摄像头权限。
2. 打开摄像头，点黑色胶囊 > **AI识别**。
3. 首次会弹出 **Roboflow API Key** 输入框。在手机本地输入新的密钥，点击保存。系统使用 **Android Keystore AES-256-GCM** 加密存储，代码、APK、GitHub 均不内置密钥。
4. 保持网络畅通即可测试。每 1.6 秒最多提交一个采样画面；服务端如响应慢则频率自动更低。
5. 可通过帮助/设置修改密钥。云端模型处理图片会产生推理 credits。该工作流目前的阈值约 0.50；APP 侧 0.25 只能过滤返回的框，无法让服务端找回被 0.50 阈值过滤的结果。

## 保留 / 暂未支持

- 保留：摄像头、黑色胶囊、纯黑启动页、毛玻璃 UI、横/竖屏、人物框、分区域观察结果确认（3 次中至少 2 次）、夜间曝光辅助、少量 HUD 显示。
- 云端：手机侧完全不加载本地 MediaPipe 检测模型，人物坐标使用 Roboflow `predictions`，并转换成 HUD 坐标。请求只用 HTTPS。
- **未实现**：骨骼关键点（工作流 V1 未提供）、服务器端远距 3×3 分块、稳定实时视频（目前低频逐帧，网络延迟决定体验）、精确距离。
- 弱网、额度不足、密钥无效：显示文字错误，尽量不关闭摄像头。
- **安全提醒**：本项目是无中转的直接调用方案，密钥不在 APK 中硬编码，但客户端可被持有设备的高级攻击者分析，不等价于服务端保护；正式产品建议用受控服务端代理。

## GitHub 编译

**方式 A**：将本完整 ZIP 解压后放在仓库根目录，确保 `app/build.gradle` 在仓库根目录，然后使用内置 `.github/workflows/build.yml` 的 `ZY V7 Roboflow Direct APK` 工作流。

**方式 B**（适合原有仓库只有 `ZY_Assistant_Android_V4.zip` 的情况）：只需将配套 `build_zy_v7_onefile.yml` 上传至仓库 `.github/workflows/build_zy_v7_onefile.yml`，它会从原先 ZIP 提取源码并覆写 V7 修改文件，然后编译 APK。

**运行状态**：通过模拟工作流 JSON 结构检查以及纯 Java 人物证据测试；本机没有 Android SDK，不是已验证的可安装 APK。尚未调用你的私有 Roboflow 工作流，也未在安卓真机实测。若 GitHub 构建失败需检查新的 Actions 任务日志。

**重要**：请吊销之前在聊天中发送过的 Roboflow 或 hcnsec API 密钥，使用新密钥在手机设置中填写。

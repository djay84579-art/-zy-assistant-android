package com.zycmzc.assistant;
import java.util.Arrays;
import java.util.Collections;
public class RegionEvidenceTest {
  private static void check(boolean condition, String message){if(!condition)throw new AssertionError(message);}
  private static RegionEvidence.Box box(float x){return new RegionEvidence.Box(x,10,x+40,100,.33f);}
  public static void main(String[] args) {
    RegionEvidence e=new RegionEvidence();
    e.observe(1,Arrays.asList(box(10)),1000);
    check(e.confirmed(1000).isEmpty(),"one observation must not display");
    e.observe(2,Arrays.asList(box(10)),1100);
    check(e.confirmed(1100).isEmpty(),"another tile must not fake confirmation");
    e.observe(1,Collections.emptyList(),1200);
    e.observe(1,Arrays.asList(box(12)),1300);
    check(e.confirmed(1300).size()==1,"101 in three observations must display");
    e.observe(2,Arrays.asList(box(11)),1350);
    check(e.confirmed(1350).size()==1,"overlapping tiles should de-duplicate");
    check(e.confirmed(4501).isEmpty(),"expired evidence must not display");
    e.observe(1,Collections.emptyList(),4700);
    check(e.confirmed(4700).isEmpty(),"missing tile observation should reduce votes");
    e.clear();
    check(e.confirmed(4800).isEmpty(),"clear should reset all tracks");
    System.out.println("RegionEvidenceTest PASS");
  }
}

# ZY辅助 V8 · 极速骨骼版

Android APK 显示名为「ZY辅助」，胶囊内不出现「离线」二字。

- **骨骼开关默认开启**：MediaPipe Pose Landmarker Lite (float16) + VIDEO 模式跟踪最多 4 人的 33 关节点；绘制简洁 12 条骨骼连接线，并从真实关节生成近似人体方框。
- **关闭骨骼**：切换为 EfficientDet-Lite0 int8 本地人物检测。两种模型不同时运行。
- 相机/AI 使用独立单线程分析、KEEP_ONLY_LATEST，只处理最新画面；85ms 最短分析间隔只是上限目标，不是实测帧率。
- 模型在 APK 构建时由 GitHub Actions 下载并内置；安装后无需服务器或 API Key，也不上传摄像头图片。
- 保留「3 次观察至少 2 次」确认目标、横竖屏、黑色胶囊和左下角频道标记。
- 当前骨骼模式上限 4 人，为速度与内存权衡；对远距离小目标可能丢失关节点，建议关闭骨骼改用普通人物检测。
- AI 初始化或 Java 推理错误优先降级/关闭 AI，继续保留相机；仍需真实设备测试，不能保证绝不闪退。

## GitHub Actions 构建

1. 上传 `ZY_Assistant_V8_FastPose.zip` 到仓库根目录（不需要上传 V4/V7 压缩包）。
2. 在 `.github/workflows/` 上传 `build_zy_v8_fast_pose.yml`。
3. 打开 Actions -> `ZY V8 FastPose APK` -> `Run workflow`。
4. 进入成功的构建，下载 `ZY-Assistant-V8-FastPose-APK`。

## 开源模型

- EfficientDet-Lite0 int8: https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/latest/efficientdet_lite0.tflite
- MediaPipe Pose Landmarker Lite: https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task
- 官方 Android 指南: https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/android

**构建状态**：完成 ZIP 静态检查和 Java 人物确认测试；未完成 Android Gradle 编译或实机运行验证。

package com.zycmzc.assistant;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Persistent launch checkpoint + fatal Java exception record, no network or log permission. */
public final class CrashGuard {
    private static final String PREFS = "zy_startup_health";
    private static volatile boolean installed;
    private static volatile String phase = "";
    private CrashGuard() { }

    public static synchronized void install(Context context) {
        if (installed) return;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter writer = new StringWriter();
                error.printStackTrace(new PrintWriter(writer));
                String report = "线程: " + thread.getName() + "\n阶段: " + phase + "\n" + writer;
                if (report.length() > 12000) report = report.substring(0,12000);
                prefs(app).edit().putString("last_crash",report)
                    .putBoolean("incomplete",true).putString("phase",phase).commit();
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread,error);
            else android.os.Process.killProcess(android.os.Process.myPid());
        });
        installed = true;
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    }
    public static boolean needsSafeStart(Context ctx) {
        return prefs(ctx).getBoolean("incomplete",false)
            || prefs(ctx).getBoolean("compatibility_lock",false);
    }
    public static void lockSafeMode(Context ctx){
        prefs(ctx).edit().putBoolean("compatibility_lock",true).commit();
    }
    public static void allowFullMode(Context ctx){
        prefs(ctx).edit().putBoolean("compatibility_lock",false)
            .putBoolean("incomplete",false).commit();
    }
    public static String previousPhase(Context ctx) {
        return prefs(ctx).getString("phase", "");
    }
    public static String report(Context ctx) {
        String r=prefs(ctx).getString("last_crash", "");
        return r.isEmpty() ? "没有捕获到 Java 崩溃堆栈（也可能是系统杀进程或 native 崩溃）。\n上次阶段: "
            + previousPhase(ctx) : r;
    }
    public static void begin(Context ctx) {
        phase = "启动摄像头界面";
        prefs(ctx).edit().putBoolean("incomplete",true)
            .putString("phase",phase).commit();
    }
    public static void stage(Context ctx,String value) {
        phase = value;
        prefs(ctx).edit().putBoolean("incomplete",true)
            .putString("phase",value).commit();
    }
    public static void stable(Context ctx) {
        phase = "摄像头运行正常";
        prefs(ctx).edit().putBoolean("incomplete",false)
            .putString("phase",phase).commit();
    }
    public static void note(Context ctx,String detail) {
        prefs(ctx).edit().putString("last_crash",detail).apply();
    }
}

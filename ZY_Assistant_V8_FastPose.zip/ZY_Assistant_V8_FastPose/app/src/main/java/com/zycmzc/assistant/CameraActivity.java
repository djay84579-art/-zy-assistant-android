package com.zycmzc.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V8 FastPose: single active local model; camera remains live on AI failure. */
public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int CAMERA_REQUEST = 201;
    // Fast preset: 640x360 -> EfficientDet-Lite0 int8 (320x320) on CPU.
    // Input can be lower than preview; model results are scaled to source pixels.
    private static final Size[] ANALYSIS_RESOLUTIONS = {
        new Size(640,360), new Size(480,270), new Size(320,180)
    };
    private static final long TARGET_INTERVAL_MS = 85L; // Attempt up to ~12 analyses/s, no FPS guarantee.
    private static final int MAX_POSES = 4; // Limit multi-person pose cost to protect FPS.
    private volatile float scoreThreshold = .25f;
    private volatile boolean objectOn = false;
    private volatile boolean poseOn = true; // Start with pose mode enabled; user can toggle it.
    private volatile boolean destroyed = false;
    private boolean safeMode;
    private boolean requestedPortrait;
    private volatile boolean startupValidated = false;
    private PreviewView preview;
    private DetectorHudView hud;
    private StartupCodeView startupCode;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ExecutorService analysisWorker;
    private ObjectDetector detector; // Used ONLY while skeleton switch is off.
    private PoseLandmarker poseLandmarker; // Used ONLY while skeleton switch is on; VIDEO tracking.
    private final RegionEvidence evidence = new RegionEvidence();
    private long lastAnalysis;
    private int consecutiveErrors;
    private byte[] pixels;
    private ByteBuffer pixelsBuffer;
    private Bitmap rawBitmap, rotatedBitmap;
    private Canvas rotatedCanvas;
    private final Matrix rotationMatrix = new Matrix();
    private final Paint conversionPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        CrashGuard.install(this);
        CrashGuard.stage(this,"V8: 初始化摄像头");
        safeMode = getIntent().getBooleanExtra("zy_safe_mode", false);
        requestedPortrait = getSharedPreferences("zy",MODE_PRIVATE).getBoolean("portrait",false);
        setRequestedOrientation(requestedPortrait ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        preview.setImplementationMode(safeMode ? PreviewView.ImplementationMode.COMPATIBLE
            : PreviewView.ImplementationMode.PERFORMANCE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        hud = new DetectorHudView(this,this);
        hud.setRecognitionState(false);
        hud.setPoseState(true);
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        startupCode = new StartupCodeView(this);
        root.addView(startupCode,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        analysisWorker=Executors.newSingleThreadExecutor(r -> {
            Thread thread=new Thread(r,"ZY-FastPose-AI");
            thread.setPriority(Thread.NORM_PRIORITY-1); // Leave headroom for camera/UI.
            return thread;
        });
        hud.setMessage("V8 极速骨骼 · 点击 AI识别 开启");
        startupCode.setAiState("LOCAL/OFF");
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
            preview.postDelayed(this::startCamera,180);
        else requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==CAMERA_REQUEST){
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else{hud.setMessage("需要相机权限");startupCode.setCameraState("DENIED");}
        }
    }

    private void startCamera(){
        if(destroyed || checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        CrashGuard.stage(this,"V8: 创建 CameraProvider");
        ListenableFuture<ProcessCameraProvider> future;
        try {future=ProcessCameraProvider.getInstance(this);}
        catch(Throwable error){cameraError(error);return;}
        future.addListener(()->{
            if(destroyed)return;
            try{
                cameraProvider=future.get();
                int rotation=preview.getDisplay()==null
                    ? getWindowManager().getDefaultDisplay().getRotation()
                    : preview.getDisplay().getRotation();
                Exception lastError=null;
                Size[] sizes=safeMode ? new Size[]{new Size(480,270),new Size(320,180)}
                    : ANALYSIS_RESOLUTIONS;
                for(Size requested:sizes){
                    try{
                        Size oriented=(rotation==0||rotation==2)
                            ? new Size(requested.getHeight(),requested.getWidth()) : requested;
                        Preview p = new Preview.Builder()
                            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                            .setTargetRotation(rotation).build();
                        p.setSurfaceProvider(preview.getSurfaceProvider());
                        ImageAnalysis analysis = new ImageAnalysis.Builder()
                            .setTargetRotation(rotation)
                            .setTargetResolution(oriented)
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                            .build();
                        analysis.setAnalyzer(analysisWorker,this::analyzeFrame);
                        cameraProvider.unbindAll();
                        camera=cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                        analysisWorker.execute(evidence::clear);
                        hud.clearDetections();
                        hud.setMessage("相机就绪 · "+oriented.getWidth()+"×"+oriented.getHeight());
                        startupCode.setCameraState("READY");
                        return;
                    }catch(Exception e){lastError=e;}
                }
                throw new IllegalStateException("CameraX 不支持预览+分析组合",lastError);
            }catch(Throwable e){cameraError(e);}
        },getMainExecutor());
    }

    private void cameraError(Throwable error){
        CrashGuard.note(this,"V8 摄像头异常: "+android.util.Log.getStackTraceString(error));
        if(destroyed)return;
        hud.setMessage("摄像头兼容性问题，请重启后使用兼容模式");
        startupCode.setCameraState("ERROR");
    }

    /** Runs on one low-priority analysis executor; no work is done on UI thread. */
    private void analyzeFrame(ImageProxy frame){
        try{
            if(destroyed)return;
            if(!startupValidated){startupValidated=true;CrashGuard.stable(this);}
            if(!objectOn)return;
            long now=SystemClock.elapsedRealtime();
            if(now-lastAnalysis<TARGET_INTERVAL_MS)return;
            lastAnalysis=now;
            // Never run person detection and pose estimation together: saves CPU and RAM.
            if(poseOn){
                if(detector!=null){detector.close();detector=null;}
                if(poseLandmarker==null && !initializePoseLandmarker())return;
            }else{
                if(poseLandmarker!=null){poseLandmarker.close();poseLandmarker=null;}
                if(detector==null && !initializeDetector())return;
            }
            long started=SystemClock.elapsedRealtime();
            Bitmap bitmap=prepareBitmap(frame);
            MPImage image=new BitmapImageBuilder(bitmap).build();
            List<RegionEvidence.Box> people=new ArrayList<>();
            List<float[][]> skeletons=new ArrayList<>();
            if(poseOn){
                // VIDEO mode reuses tracking information between frames for lower latency.
                PoseLandmarkerResult result=poseLandmarker.detectForVideo(
                    image,SystemClock.uptimeMillis());
                for(List<NormalizedLandmark> body:result.landmarks()){
                    if(body.size()<29)continue;
                    float[][] points=new float[body.size()][3];
                    float minX=1f,minY=1f,maxX=0f,maxY=0f;
                    float visibilitySum=0f;
                    int coreCount=0;
                    for(int i=0;i<body.size();i++){
                        NormalizedLandmark joint=body.get(i);
                        float confidence=joint.visibility().orElse(0f);
                        points[i][0]=joint.x();points[i][1]=joint.y();points[i][2]=confidence;
                        // Only use visible torso/limb joints to form realistic boxes.
                        if(i>=11 && i<=28 && confidence>=.42f){
                            float x=Math.max(0,Math.min(1,joint.x()));
                            float y=Math.max(0,Math.min(1,joint.y()));
                            minX=Math.min(minX,x);minY=Math.min(minY,y);
                            maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
                            coreCount++;visibilitySum+=confidence;
                        }
                    }
                    // Require enough visible body joints before drawing a skeleton.
                    if(coreCount<6 || maxX-minX<.02f || maxY-minY<.04f)continue;
                    skeletons.add(points);
                    float marginX=(maxX-minX)*.14f, marginY=(maxY-minY)*.16f;
                    float l=Math.max(0,minX-marginX)*bitmap.getWidth();
                    float t=Math.max(0,minY-marginY)*bitmap.getHeight();
                    float r=Math.min(1,maxX+marginX)*bitmap.getWidth();
                    float b=Math.min(1,maxY+marginY)*bitmap.getHeight();
                    people.add(new RegionEvidence.Box(l,t,r,b,
                        Math.max(.3f,Math.min(.99f,visibilitySum/coreCount))));
                }
            }else{
                ObjectDetectorResult result=detector.detect(image);
                for(com.google.mediapipe.tasks.components.containers.Detection detection:result.detections()){
                    if(detection.categories().isEmpty())continue;
                    com.google.mediapipe.tasks.components.containers.Category category=
                        detection.categories().get(0);
                    if(!"person".equalsIgnoreCase(category.categoryName()))continue;
                    float score=category.score();
                    if(score<scoreThreshold)continue;
                    RectF rect=detection.boundingBox();
                    if(rect.width()<2||rect.height()<2)continue;
                    people.add(new RegionEvidence.Box(rect.left,rect.top,rect.right,rect.bottom,score));
                }
            }
            long end=SystemClock.elapsedRealtime();
            evidence.observe(0,people,end);
            List<DetectorHudView.Found> out=new ArrayList<>();
            for(RegionEvidence.Box b:evidence.confirmed(end)){
                out.add(new DetectorHudView.Found(new RectF(b.left,b.top,b.right,b.bottom),"person",b.score));
            }
            consecutiveErrors=0;
            int latency=(int)(end-started);
            int fps=(int)Math.min(1000/Math.max(1,latency),1000/TARGET_INTERVAL_MS);
            int w=bitmap.getWidth(),h=bitmap.getHeight();
            final boolean producedPose=poseOn;
            runOnUiThread(()->{
                if(destroyed || !objectOn || producedPose!=poseOn)return;
                hud.setDetections(out,w,h,fps,latency);
                if(producedPose)hud.setPoses(skeletons,w,h);
                startupCode.setAiState("LOCAL/ACTIVE");
            });
        }catch(Throwable error){
            // Java exceptions & OOM are recoverable. Native SIGSEGV cannot be caught;
            // avoid experimental GPU delegate, disable inference after the first error.
            consecutiveErrors++;
            objectOn=false;
            poseOn=false;
            CrashGuard.note(this,"V8 人物/骨骼 AI 错误: "+android.util.Log.getStackTraceString(error));
            runOnUiThread(()->{
                if(destroyed)return;
                hud.setRecognitionState(false);
                hud.setPoseState(false);
                hud.clearDetections();
                hud.setMessage("本地 AI 出错，已自动关闭；相机可继续使用");
                startupCode.setAiState("LOCAL/ERROR");
            });
        }finally{
            frame.close(); // Essential to avoid CameraX queue stalls and memory growth.
        }
    }

    /** Own the pose model on analysisWorker, never on the UI thread. */
    private boolean initializePoseLandmarker(){
        try{
            CrashGuard.stage(this,"V8: 加载极速骨骼模型");
            BaseOptions base=BaseOptions.builder()
                .setModelAssetPath("pose_landmarker_lite.task").build();
            PoseLandmarker.PoseLandmarkerOptions opts=PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumPoses(MAX_POSES)
                .setMinPoseDetectionConfidence(.45f)
                .setMinPosePresenceConfidence(.45f)
                .setMinTrackingConfidence(.55f)
                .build();
            poseLandmarker=PoseLandmarker.createFromOptions(this,opts);
            CrashGuard.stable(this);
            runOnUiThread(()->{if(!destroyed)hud.setMessage("极速骨骼已启动 · 最多4人");});
            return true;
        }catch(Throwable error){
            // Fall back to object-only detection rather than killing the camera/UI.
            poseOn=false;
            CrashGuard.note(this,"V8 骨骼模型失败，切换人物检测: "
                +android.util.Log.getStackTraceString(error));
            runOnUiThread(()->{if(!destroyed){
                hud.setPoseState(false);
                hud.setMessage("骨骼初始化失败，已自动切换人物检测");
            }});
            return false;
        }
    }

    /** Model is created lazily on the analysis executor. CPU only, 2 threads. */
    private boolean initializeDetector(){
        try{
            CrashGuard.stage(this,"V8: 加载人物识别模型");
            BaseOptions base=BaseOptions.builder()
                .setModelAssetPath("efficientdet_lite0_int8.tflite")
                .build();
            ObjectDetector.ObjectDetectorOptions opts=ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.IMAGE)
                .setScoreThreshold(.25f)
                .build();
            detector=ObjectDetector.createFromOptions(this,opts);
            CrashGuard.stable(this);
            runOnUiThread(()->{if(!destroyed)hud.setMessage("人物识别已启动");});
            return true;
        }catch(Throwable error){
            objectOn=false;
            CrashGuard.note(this,"V8 模型初始化失败: "+android.util.Log.getStackTraceString(error));
            runOnUiThread(()->{
                if(!destroyed){hud.setRecognitionState(false);
                    hud.setMessage("模型初始化失败，已保持摄像头运行；查看启动诊断");
                    startupCode.setAiState("LOCAL/ERROR");}
            });
            return false;
        }
    }

    /** Reuses pixel byte buffer, raw bitmap and rotation canvas instead of allocating MBs each frame. */
    private Bitmap prepareBitmap(ImageProxy frame) {
        int w=frame.getWidth(),h=frame.getHeight();
        int bytes=w*h*4;
        if(rawBitmap==null || rawBitmap.getWidth()!=w || rawBitmap.getHeight()!=h){
            if(rawBitmap!=null)rawBitmap.recycle();
            rawBitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        }
        ImageProxy.PlaneProxy plane=frame.getPlanes()[0];
        ByteBuffer input=plane.getBuffer();
        int stride=plane.getRowStride(),rowBytes=w*4;
        if(stride==rowBytes){
            // Direct buffer copy avoids allocating + copying an extra 8MB at 1080p.
            input.rewind();rawBitmap.copyPixelsFromBuffer(input);
        } else {
            if(pixels==null || pixels.length!=bytes){
                pixels=new byte[bytes];pixelsBuffer=ByteBuffer.wrap(pixels);
            }
            for(int y=0;y<h;y++){
                input.position(y*stride);
                input.get(pixels,y*rowBytes,rowBytes);
            }
            pixelsBuffer.rewind();rawBitmap.copyPixelsFromBuffer(pixelsBuffer);
        }
        int rotation=frame.getImageInfo().getRotationDegrees();
        if(rotation==0)return rawBitmap;
        int ow=(rotation==90||rotation==270)?h:w;
        int oh=(rotation==90||rotation==270)?w:h;
        if(rotatedBitmap==null || rotatedBitmap.getWidth()!=ow || rotatedBitmap.getHeight()!=oh){
            if(rotatedBitmap!=null)rotatedBitmap.recycle();
            rotatedBitmap=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            rotatedCanvas=new Canvas(rotatedBitmap);
        }
        rotationMatrix.reset();
        rotationMatrix.setRotate(rotation);
        if(rotation==90)rotationMatrix.postTranslate(h,0);
        else if(rotation==180)rotationMatrix.postTranslate(w,h);
        else if(rotation==270)rotationMatrix.postTranslate(0,w);
        rotatedCanvas.drawColor(Color.TRANSPARENT,android.graphics.PorterDuff.Mode.CLEAR);
        rotatedCanvas.drawBitmap(rawBitmap,rotationMatrix,conversionPaint);
        return rotatedBitmap;
    }



    @Override public void onRecognitionChanged(boolean enabled){
        objectOn=enabled;
        if(!enabled){
            hud.clearDetections();
            analysisWorker.execute(evidence::clear);
        }
        hud.setMessage(enabled?"本地人物识别开启 · CPU稳定模式":"本地识别已暂停");
        startupCode.setAiState(enabled?"LOCAL/STARTING":"LOCAL/OFF");
    }
    @Override public void onSensitivityChanged(float threshold){scoreThreshold=threshold;}
    @Override public void onPoseChanged(boolean enabled){
        poseOn=enabled;
        hud.setPoseState(enabled);
        // Drop detections from the previous model when changing modes.
        if(analysisWorker!=null)analysisWorker.execute(evidence::clear);
        hud.clearDetections();
        hud.setMessage(enabled?"骨骼模式：轻量跟踪识别":"普通模式：快速人物识别");
    }
    @Override public void onNightChanged(boolean enabled){
        if(camera==null)return;
        try{
            androidx.camera.core.ExposureState state=camera.getCameraInfo().getExposureState();
            if(state.isExposureCompensationSupported()){
                int min=state.getExposureCompensationRange().getLower();
                int max=state.getExposureCompensationRange().getUpper();
                camera.getCameraControl().setExposureCompensationIndex(
                    enabled?Math.max(min,Math.min(max,2)):0);
            }else hud.setMessage("本机不支持曝光补偿");
        }catch(Exception e){hud.setMessage("夜间增强不可用");}
    }
    @Override public void onRotatePressed(){
        requestedPortrait=!requestedPortrait;
        getSharedPreferences("zy",MODE_PRIVATE).edit().putBoolean("portrait",requestedPortrait).apply();
        setRequestedOrientation(requestedPortrait?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);
        if(preview!=null)preview.postDelayed(this::startCamera,200);
    }
    @Override public void onClosePressed(){finish();}
    @Override public void onHelpPressed(){
        new AlertDialog.Builder(this).setTitle("ZY辅助 V8 · 极速骨骼版")
            .setMessage("骨骼打开：MediaPipe Pose Lite + VIDEO 跟踪，最多同时4人，绘制真实关节点。\n\n"
                +"骨骼关闭：EfficientDet-Lite0 人物检测，适合快速显示人物方框。\n\n"
                +"两种模型不会同时运行，尽量减少 CPU 和内存占用。\n\n"
                +"使用本机 AI，不需要服务器或 API Key。目标每85ms检查一次最新帧，实际速度取决于设备性能。\n\n"
                +"骨骼关键点过少或远处小人物可能无法识别；可关闭骨骼改用普通模式。\n\n"
                +"发生模型错误时优先保持摄像头运行，但不能保证所有设备都绝不闪退。")
            .setPositiveButton("知道了",null).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        objectOn=false;
        if(cameraProvider!=null){try{cameraProvider.unbindAll();}catch(Exception ignored){}}
        if(analysisWorker!=null){
            analysisWorker.execute(()->{
                if(detector!=null){try{detector.close();}catch(Throwable ignored){}detector=null;}
                if(poseLandmarker!=null){try{poseLandmarker.close();}catch(Throwable ignored){}poseLandmarker=null;}
                if(rawBitmap!=null){rawBitmap.recycle();rawBitmap=null;}
                if(rotatedBitmap!=null){rotatedBitmap.recycle();rotatedBitmap=null;}
            });
            analysisWorker.shutdown();
        }
        super.onDestroy();
    }
}

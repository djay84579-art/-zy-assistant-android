package com.zycmzc.assistant;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

/** Tiny camera-entry code animation at bottom-left, lasts 2.4 seconds then fades. */
public final class StartupCodeView extends View {
    private static final long RUN_MS=1900;
    private static final long FADE_MS=500;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private final long began=SystemClock.elapsedRealtime();
    private String cameraState="CONNECTING", aiState="LOADING";

    public StartupCodeView(Context context){
        super(context);
        density=getResources().getDisplayMetrics().density;
        setClickable(false);
        setLayerType(LAYER_TYPE_NONE,null);
    }
    public void setCameraState(String state){cameraState=state;invalidate();}
    public void setAiState(String state){aiState=state;invalidate();}
    private float dp(float size){return size*density;}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        long elapsed=SystemClock.elapsedRealtime()-began;
        if(elapsed>=RUN_MS+FADE_MS){setVisibility(GONE);return;}
        float fade=elapsed<RUN_MS?1f:1f-(elapsed-RUN_MS)/(float)FADE_MS;
        String[] lines={
            "> ZY.camera.init()",
            "> CAM: "+cameraState,
            "> AI:  "+aiState,
            "> UI:  READY"
        };
        int count=Math.min(lines.length,1+(int)(elapsed/330));
        // 2-second, 4-line console with tiny text. Doesn't block the scene.
        float textSize=dp(9.5f),step=dp(15);
        float y0=getHeight()-dp(116);
        float width=Math.min(getWidth()-dp(20),dp(206));
        RectF bg=new RectF(dp(10),y0-dp(17),dp(10)+width,y0+dp(11)+step*3);
        paint.setColor(0xC909111C);paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(Math.round(190*fade));
        c.drawRoundRect(bg,dp(9),dp(9),paint);
        paint.setTypeface(Typeface.MONOSPACE);paint.setTextSize(textSize);
        for(int i=0;i<count;i++){
            // The current line types in progressively, then becomes complete.
            int symbols=Math.max(0,Math.min(lines[i].length(),(int)((elapsed-i*330)/18)));
            String fragment=lines[i].substring(0,symbols);
            paint.setColor(i==3?0xFF50DABB:0xFF8BC5EE);
            paint.setAlpha(Math.round(240*fade));
            c.drawText(fragment,dp(19),y0+i*step,paint);
        }
        postInvalidateOnAnimation();
    }
}

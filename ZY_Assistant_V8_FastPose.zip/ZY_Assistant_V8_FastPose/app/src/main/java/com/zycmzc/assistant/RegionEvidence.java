package com.zycmzc.assistant;

import java.util.ArrayList;
import java.util.List;

/**
 * Spatial evidence for remote person detections. Completely separate from the
 * HUD: a tile contributes at most one vote per actual observation of that tile.
 * A person is confirmed after hits in >=2 of the last 3 observations of its
 * own region; other tiles cannot fabricate confirmations.
 */
final class RegionEvidence {
    static final int REGION_COUNT = 10; // whole-frame + 3x3 tiles
    static final long MAX_DISPLAY_AGE_MS = 3000L;
    static final long MAX_CANDIDATE_AGE_MS = 9500L;

    static final class Box {
        final float left, top, right, bottom, score;
        Box(float left, float top, float right, float bottom, float score) {
            this.left=left; this.top=top; this.right=right; this.bottom=bottom; this.score=score;
        }
    }

    private static final class Candidate {
        float left,top,right,bottom,score;
        int votes = 1; // bit 0 = most recent observation
        long lastSeen;
        boolean matched;
        Candidate(Box b, long now) {
            left=b.left;top=b.top;right=b.right;bottom=b.bottom;score=b.score;lastSeen=now;
        }
        Box box(){ return new Box(left,top,right,bottom,score); }
        void hit(Box b,long now) {
            // Moderately smooth coordinates, but never treat this smoothing as a new observation.
            left=.25f*left+.75f*b.left;
            top=.25f*top+.75f*b.top;
            right=.25f*right+.75f*b.right;
            bottom=.25f*bottom+.75f*b.bottom;
            score=b.score;lastSeen=now;votes|=1;matched=true;
        }
        boolean confirmed(){return Integer.bitCount(votes)>=2;}
    }

    @SuppressWarnings("unchecked")
    private final List<Candidate>[] regions=(List<Candidate>[])new List[REGION_COUNT];
    RegionEvidence(){for(int i=0;i<regions.length;i++)regions[i]=new ArrayList<>();}
    void clear(){for(List<Candidate> region:regions)region.clear();}

    void observe(int region,List<Box> observations,long now) {
        if(region<0 || region>=REGION_COUNT)throw new IllegalArgumentException("Invalid region");
        List<Candidate> entries=regions[region];
        entries.removeIf(c -> now-c.lastSeen>MAX_CANDIDATE_AGE_MS);
        for(Candidate c:entries){c.votes=(c.votes<<1)&7;c.matched=false;}
        for(Box b:observations){
            if(b.right<=b.left || b.bottom<=b.top)continue;
            Candidate best=null;
            float bestScore=.20f;
            for(Candidate c:entries){
                if(c.matched)continue;
                float overlap=iou(b,c.box());
                if(overlap>bestScore){best=c;bestScore=overlap;}
            }
            if(best==null)entries.add(new Candidate(b,now));
            else best.hit(b,now);
        }
        // Three actual region observations define the vote window.
        entries.removeIf(c -> c.votes==0);
    }

    List<Box> confirmed(long now) {
        List<Box> all=new ArrayList<>();
        for(List<Candidate> region:regions)for(Candidate c:region){
            if(c.confirmed() && now-c.lastSeen<=MAX_DISPLAY_AGE_MS)all.add(c.box());
        }
        // Non-max suppression: overlapping tile and full-frame evidence draws ONE box.
        all.sort((a,b)->Float.compare(b.score,a.score));
        List<Box> chosen=new ArrayList<>();
        for(Box b:all){
            boolean duplicate=false;
            for(Box keep:chosen){
                if(iou(b,keep)>=.32f){duplicate=true;break;}
            }
            if(!duplicate)chosen.add(b);
        }
        return chosen;
    }

    private static float iou(Box a,Box b){
        float w=Math.max(0f,Math.min(a.right,b.right)-Math.max(a.left,b.left));
        float h=Math.max(0f,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
        float intersection=w*h;
        float aa=Math.max(0f,a.right-a.left)*Math.max(0f,a.bottom-a.top);
        float bb=Math.max(0f,b.right-b.left)*Math.max(0f,b.bottom-b.top);
        float u=aa+bb-intersection;
        return u>0f?intersection/u:0f;
    }
}

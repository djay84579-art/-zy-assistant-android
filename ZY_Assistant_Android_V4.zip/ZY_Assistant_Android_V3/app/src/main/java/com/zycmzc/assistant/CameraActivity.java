package com.zycmzc.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult;
import com.google.mediapipe.tasks.components.containers.Detection;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android CameraX preview stays fluid; expensive AI is decimated on a worker. */
public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int CAMERA_REQUEST = 201;
    private PreviewView preview;
    private DetectorHudView hud;
    private StartupCodeView startupCode;
    // Enhanced remote mode: the model is always queried at its true >=0.25 score floor.
    // A 2-of-3 spatial observation filter prevents one-off low-score boxes from displaying.
    private volatile float scoreThreshold=.25f;
    private static final float MIN_PERSON_CONFIDENCE = .25f;
    private static final int ANALYSIS_LONG_EDGE = 640;
    private static final Size[] ANALYSIS_RESOLUTIONS = {
        new Size(1920,1080), new Size(1280,720), new Size(640,360)
    };
    private final RegionEvidence personEvidence = new RegionEvidence();
    private int nextRegion = 1;
    private int gridSize = 3;
    private int scanBatches;
    private int sourceWidth = -1, sourceHeight = -1;
    private List<DetectorHudView.Found> lastObjects = new ArrayList<>();
    private long lastObjectsAt;
    private int averageTileMs = 100;
    private ExecutorService worker;
    private ObjectDetector objectDetector;
    private PoseLandmarker poseLandmarker;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;
    private volatile boolean destroyed;
    private volatile boolean objectOn = true;
    private volatile boolean poseOn = false; // opt in for smoothest default experience
    private long lastObjectTime, lastPoseTime;
    private int adaptiveObjectIntervalMs = 210;
    private int inferenceMs, detectionCount, inferenceRate;
    private long fpsWindow;
    private byte[] pixels;
    private ByteBuffer pixelsBuffer;
    private Bitmap rawBitmap, rotatedBitmap, globalBitmap, tileBitmap;
    private Canvas globalCanvas, tileCanvas;
    private final Rect bitmapCrop = new Rect();
    private final RectF inferenceDestination = new RectF();
    private Canvas rotatedCanvas;
    private final Matrix rotationMatrix = new Matrix();
    private final Paint conversionPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private boolean requestedPortrait;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestedPortrait = getSharedPreferences("zy", MODE_PRIVATE).getBoolean("portrait",false);
        setRequestedOrientation(requestedPortrait ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        // PERFORMANCE uses SurfaceView on supported devices; avoids extra TextureView copies.
        preview.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        hud = new DetectorHudView(this,this);
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        startupCode = new StartupCodeView(this);
        root.addView(startupCode,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        worker = Executors.newSingleThreadExecutor();
        hud.setMessage("初始化离线 AI …");
        worker.execute(this::loadDetector);
        if (checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
            preview.postDelayed(this::startCamera,220);
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
    }

    private void loadDetector() {
        try {
            ObjectDetector.ObjectDetectorOptions opts = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("efficientdet_lite0.tflite").build())
                .setRunningMode(RunningMode.IMAGE).setScoreThreshold(.25f)
                // No setMaxResults: all available model results, no arbitrary 2/4/12 cap.
                .build();
            ObjectDetector d = ObjectDetector.createFromOptions(this,opts);
            objectDetector=d;
            runOnUiThread(()->{if(!destroyed){hud.setMessage("AI已就绪"); startupCode.setAiState("READY");}});
        } catch(Exception e) {
            runOnUiThread(()->{if(!destroyed){hud.setMessage("AI初始化失败: "+e.getMessage()); startupCode.setAiState("ERROR");}});
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==CAMERA_REQUEST) {
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else {hud.setMessage("请允许相机权限才能使用");startupCode.setCameraState("DENIED");}
        }
    }

    private void startCamera() {
        if(destroyed || checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(destroyed)return;
            try {
                cameraProvider=future.get();
                int rotation=preview.getDisplay()==null?getWindowManager().getDefaultDisplay().getRotation():preview.getDisplay().getRotation();
                Exception error=null;
                // CameraX resolution is a preference, not an unconditional guarantee.
                // Some devices cannot bind Preview + 1080p RGBA Analysis together.
                for(Size requested : ANALYSIS_RESOLUTIONS){
                    try {
                        // Resolution is expressed in the target display's orientation.
                        Size oriented = (rotation==0 || rotation==2)
                            ? new Size(requested.getHeight(),requested.getWidth()) : requested;
                        Preview p=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
                            .setTargetRotation(rotation).build();
                        p.setSurfaceProvider(preview.getSurfaceProvider());
                        ImageAnalysis analysis=new ImageAnalysis.Builder()
                            .setTargetRotation(rotation)
                            .setTargetResolution(oriented)
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                            .build();
                        analysis.setAnalyzer(worker,this::analyzeFrame);
                        cameraProvider.unbindAll();
                        camera=cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                        worker.execute(()->{
                            personEvidence.clear();lastObjects.clear();
                            sourceWidth=-1;sourceHeight=-1;nextRegion=1;gridSize=3;scanBatches=0;
                        });
                        hud.clearDetections();
                        hud.setMessage("增强远距已开启 · 请求 " + oriented.getWidth() + "×" + oriented.getHeight());
                        startupCode.setCameraState("READY");
                        return;
                    } catch(Exception bindException){error=bindException;}
                }
                throw new IllegalStateException("该设备不支持预览+分析组合",error);
            } catch(Exception e) {
                hud.setMessage("摄像头启动失败: "+e.getMessage());
                startupCode.setCameraState("ERROR");
            }
        },getMainExecutor());
    }

    /** Reuses only two small model bitmaps; no 1920x1080 neural-network input. */
    private Bitmap scaleRegion(Bitmap src, boolean whole, int tileNumber) {
        int sw=src.getWidth(),sh=src.getHeight();
        int ow=sw>=sh?ANALYSIS_LONG_EDGE:Math.max(1,Math.round(ANALYSIS_LONG_EDGE*(float)sw/sh));
        int oh=sh>sw?ANALYSIS_LONG_EDGE:Math.max(1,Math.round(ANALYSIS_LONG_EDGE*(float)sh/sw));
        Bitmap output=whole?globalBitmap:tileBitmap;
        Canvas outputCanvas=whole?globalCanvas:tileCanvas;
        if(output==null || output.getWidth()!=ow || output.getHeight()!=oh){
            if(output!=null)output.recycle();
            output=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            outputCanvas=new Canvas(output);
            if(whole){globalBitmap=output;globalCanvas=outputCanvas;}
            else{tileBitmap=output;tileCanvas=outputCanvas;}
        }
        if(whole)bitmapCrop.set(0,0,sw,sh);
        else {
            int row=(tileNumber-1)/gridSize,col=(tileNumber-1)%gridSize;
            float cellW=sw/(float)gridSize,cellH=sh/(float)gridSize;
            // Overlap neighboring tiles to avoid splitting tiny distant people.
            bitmapCrop.set(Math.max(0,Math.round((col-.10f)*cellW)),
                Math.max(0,Math.round((row-.10f)*cellH)),
                Math.min(sw,Math.round((col+1.10f)*cellW)),
                Math.min(sh,Math.round((row+1.10f)*cellH)));
        }
        inferenceDestination.set(0,0,ow,oh);
        outputCanvas.drawBitmap(src,bitmapCrop,inferenceDestination,conversionPaint);
        return output;
    }

    /** One inference, with person boxes remapped from cropped-image to source pixels. */
    private List<RegionEvidence.Box> detectRegion(Bitmap source, boolean whole, int region,
                                                    List<DetectorHudView.Found> objects) {
        Bitmap input=scaleRegion(source,whole,region);
        MPImage image=new BitmapImageBuilder(input).build();
        ObjectDetectorResult result;
        try {result=objectDetector.detect(image);}
        finally {image.close();}
        float sx=bitmapCrop.width()/(float)input.getWidth();
        float sy=bitmapCrop.height()/(float)input.getHeight();
        int ox=bitmapCrop.left,oy=bitmapCrop.top;
        List<RegionEvidence.Box> persons=new ArrayList<>();
        for(Detection d:result.detections()){
            if(d.categories().isEmpty())continue;
            Category category=d.categories().get(0);
            String label=category.categoryName()==null?"目标":category.categoryName();
            boolean isPerson="person".equalsIgnoreCase(label);
            float required=isPerson?Math.max(scoreThreshold,MIN_PERSON_CONFIDENCE):scoreThreshold;
            if(category.score()<required)continue;
            RectF r=d.boundingBox();
            float l=Math.max(0f,Math.min(source.getWidth(),ox+r.left*sx));
            float t=Math.max(0f,Math.min(source.getHeight(),oy+r.top*sy));
            float right=Math.max(0f,Math.min(source.getWidth(),ox+r.right*sx));
            float bottom=Math.max(0f,Math.min(source.getHeight(),oy+r.bottom*sy));
            if(right<=l || bottom<=t)continue;
            if(isPerson)persons.add(new RegionEvidence.Box(l,t,right,bottom,category.score()));
            else if(whole)objects.add(new DetectorHudView.Found(new RectF(l,t,right,bottom),label,category.score()));
        }
        return persons;
    }

    private void analyzeFrame(ImageProxy frame) {
        try {
            long now=SystemClock.elapsedRealtime();
            boolean detect = objectOn && objectDetector!=null
                && now-lastObjectTime >= adaptiveObjectIntervalMs;
            boolean pose = poseOn && now-lastPoseTime>=850;
            if(destroyed || (!detect && !pose))return;
            if(pose && poseLandmarker==null) {
                // Lazy load: turn off skeleton to avoid holding a second large model by default.
                try {
                    PoseLandmarker.PoseLandmarkerOptions opts=PoseLandmarker.PoseLandmarkerOptions.builder()
                        .setBaseOptions(BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build())
                        .setRunningMode(RunningMode.IMAGE).setNumPoses(6)
                        .setMinPoseDetectionConfidence(.48f).build();
                    poseLandmarker=PoseLandmarker.createFromOptions(this,opts);
                    runOnUiThread(()->{if(!destroyed)hud.setMessage("多人骨骼模型已加载（最多6姿态）");});
                } catch(Exception e) {
                    poseOn=false;
                    runOnUiThread(()->{if(!destroyed){hud.setPoseState(false);hud.setMessage("骨骼加载失败: "+e.getMessage());}});
                    pose=false;
                }
            }
            if(!detect && !pose)return;
            Bitmap bitmap=prepareBitmap(frame);
            int imageWidth=bitmap.getWidth(),imageHeight=bitmap.getHeight();
            if(sourceWidth!=imageWidth || sourceHeight!=imageHeight){
                sourceWidth=imageWidth;sourceHeight=imageHeight;
                personEvidence.clear();lastObjects.clear();nextRegion=1;scanBatches=0;
                runOnUiThread(()->{if(!destroyed){
                    hud.clearDetections();
                    hud.setMessage("实际分析 " + imageWidth + "×" + imageHeight + " · 分块远距");
                }});
            }
            if(detect){
                lastObjectTime=now;
                long start=SystemClock.elapsedRealtime();
                // Roll through nine overlapping tiles; fallback to four on slow phones.
                // Lightweight phones run one tile per batch; faster phones run two.
                int tilePasses=averageTileMs<=135?2:1;
                for(int i=0;i<tilePasses;i++){
                    int region=nextRegion;
                    nextRegion=region==gridSize*gridSize?1:region+1;
                    long began=SystemClock.elapsedRealtime();
                    List<RegionEvidence.Box> people=detectRegion(bitmap,false,region,new ArrayList<>());
                    personEvidence.observe(region,people,SystemClock.elapsedRealtime());
                    int spent=(int)(SystemClock.elapsedRealtime()-began);
                    averageTileMs=(averageTileMs*3+spent)/4;
                }
                if(gridSize==3 && averageTileMs>280){
                    // Avoid a very long sweep on entry-level/thermally limited devices.
                    gridSize=2;nextRegion=1;personEvidence.clear();
                }
                // Periodic whole-frame inference still finds nearby people/other objects.
                if(scanBatches++%3==0 || lastObjectsAt==0){
                    List<DetectorHudView.Found> objects=new ArrayList<>();
                    List<RegionEvidence.Box> people=detectRegion(bitmap,true,0,objects);
                    personEvidence.observe(0,people,SystemClock.elapsedRealtime());
                    lastObjects=objects;lastObjectsAt=now;
                }
                inferenceMs=(int)(SystemClock.elapsedRealtime()-start);
                // Camera preview is independent and KEEP_ONLY_LATEST drops old AI frames.
                adaptiveObjectIntervalMs=Math.max(180,Math.min(1100,
                    (int)(inferenceMs*1.35f)+75));
                List<DetectorHudView.Found> detections=new ArrayList<>();
                for(RegionEvidence.Box b:personEvidence.confirmed(SystemClock.elapsedRealtime())){
                    detections.add(new DetectorHudView.Found(
                        new RectF(b.left,b.top,b.right,b.bottom),"person",b.score));
                }
                if(now-lastObjectsAt<1700)detections.addAll(lastObjects);
                detectionCount++;
                if(fpsWindow==0)fpsWindow=now;
                if(now-fpsWindow>=1000){
                    inferenceRate=(int)(detectionCount*1000f/(now-fpsWindow));
                    detectionCount=0;fpsWindow=now;
                }
                int rate=inferenceRate,time=inferenceMs;
                runOnUiThread(()->{if(!destroyed)hud.setDetections(detections,imageWidth,imageHeight,rate,time);});
            }
            if(pose && poseLandmarker!=null){
                lastPoseTime=now;
                // Run optional skeleton model on the small whole-frame image, not 1080p.
                Bitmap small=scaleRegion(bitmap,true,0);
                MPImage image=new BitmapImageBuilder(small).build();
                PoseLandmarkerResult poses;
                try {poses=poseLandmarker.detect(image);}
                finally {image.close();}
                List<float[][]> points=new ArrayList<>();
                for(List<NormalizedLandmark> landmarks:poses.landmarks()){
                    float[][] one=new float[landmarks.size()][3];
                    for(int i=0;i<landmarks.size();i++){
                        NormalizedLandmark pt=landmarks.get(i);
                        one[i][0]=pt.x();one[i][1]=pt.y();
                        one[i][2]=pt.visibility().orElse(1f);
                    }
                    points.add(one);
                }
                runOnUiThread(()->{if(!destroyed)hud.setPoses(points,imageWidth,imageHeight);});
            }
        } catch(Exception e){
            runOnUiThread(()->{if(!destroyed)hud.setMessage("AI帧处理失败: "+e.getMessage());});
        } finally {frame.close();}
    }

    /** Reuses pixel byte buffer, raw bitmap and rotation canvas instead of allocating MBs each frame. */
    private Bitmap prepareBitmap(ImageProxy frame) {
        int w=frame.getWidth(),h=frame.getHeight();
        int bytes=w*h*4;
        if(rawBitmap==null || rawBitmap.getWidth()!=w || rawBitmap.getHeight()!=h){
            if(rawBitmap!=null)rawBitmap.recycle();
            rawBitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        }
        ImageProxy.PlaneProxy plane=frame.getPlanes()[0];
        ByteBuffer input=plane.getBuffer();
        int stride=plane.getRowStride(),rowBytes=w*4;
        if(stride==rowBytes){
            // Direct buffer copy avoids allocating + copying an extra 8MB at 1080p.
            input.rewind();rawBitmap.copyPixelsFromBuffer(input);
        } else {
            int bytes=w*h*4;
            if(pixels==null || pixels.length!=bytes){
                pixels=new byte[bytes];pixelsBuffer=ByteBuffer.wrap(pixels);
            }
            for(int y=0;y<h;y++){
                input.position(y*stride);
                input.get(pixels,y*rowBytes,rowBytes);
            }
            pixelsBuffer.rewind();rawBitmap.copyPixelsFromBuffer(pixelsBuffer);
        }
        int rotation=frame.getImageInfo().getRotationDegrees();
        if(rotation==0)return rawBitmap;
        int ow=(rotation==90||rotation==270)?h:w;
        int oh=(rotation==90||rotation==270)?w:h;
        if(rotatedBitmap==null || rotatedBitmap.getWidth()!=ow || rotatedBitmap.getHeight()!=oh){
            if(rotatedBitmap!=null)rotatedBitmap.recycle();
            rotatedBitmap=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            rotatedCanvas=new Canvas(rotatedBitmap);
        }
        rotationMatrix.reset();
        rotationMatrix.setRotate(rotation);
        if(rotation==90)rotationMatrix.postTranslate(h,0);
        else if(rotation==180)rotationMatrix.postTranslate(w,h);
        else if(rotation==270)rotationMatrix.postTranslate(0,w);
        rotatedCanvas.drawColor(Color.TRANSPARENT,android.graphics.PorterDuff.Mode.CLEAR);
        rotatedCanvas.drawBitmap(rawBitmap,rotationMatrix,conversionPaint);
        return rotatedBitmap;
    }

    @Override public void onRecognitionChanged(boolean enable){
        objectOn=enable;
        if(!enable)worker.execute(()->{personEvidence.clear();lastObjects.clear();});
        hud.setMessage(enable?"增强远距识别已开启":"已暂停识别，节省性能");
    }
    @Override public void onSensitivityChanged(float threshold){scoreThreshold=threshold;}
    @Override public void onPoseChanged(boolean enable){poseOn=enable;hud.setMessage(enable?"骨骼已开启（会增加耗电）":"骨骼已关闭，流畅优先");}
    @Override public void onNightChanged(boolean enable){
        if(camera==null)return;
        try {
            androidx.camera.core.ExposureState exp=camera.getCameraInfo().getExposureState();
            if(exp.isExposureCompensationSupported()){
                int upper=exp.getExposureCompensationRange().getUpper();
                camera.getCameraControl().setExposureCompensationIndex(enable?Math.min(2,upper):0);
            } else hud.setMessage("本机不支持曝光补偿");
        } catch(Exception e){hud.setMessage("夜间增强不可用");}
    }
    @Override public void onRotatePressed(){
        requestedPortrait=!requestedPortrait;
        getSharedPreferences("zy",MODE_PRIVATE).edit().putBoolean("portrait",requestedPortrait).apply();
        setRequestedOrientation(requestedPortrait?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);
        preview.postDelayed(this::startCamera,160);
    }
    @Override public void onClosePressed(){finish();}
    @Override public void onHelpPressed(){
        new AlertDialog.Builder(this).setTitle("ZY辅助 · V4 远距增强")
            .setMessage("黑色胶囊：点击展开深色控制面板。\n\n"+
                "物品绘制默认关闭，与人物方框、骨骼、射线独立控制。\n\n"+
                "增强远距：优先请求1080p相机分析帧；3×3分块轮询，人物阈值最低25%，同一区域三次观察至少两次命中才显示。\n\n"+
                "远距分块越多，结果更新越慢；无法保证超出摄像头与模型的成像极限。\n\n"+
                "骨骼：MediaPipe 多人姿态模型，最多6个人，默认关闭以优先保持流畅。\n\n"+
                "横竖屏：点击顶部 ↻ 按钮切换。\n\n"+
                "AI每秒处理次数≠手机摄像头预览帧率；视频预览不会被AI处理频率限制。\n\n"+
                "距离需要相机标定，尚不提供米数。底部频道：@ZYCMZC")
            .setPositiveButton("了解",null).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        if(cameraProvider!=null)cameraProvider.unbindAll();
        if(worker!=null){
            worker.execute(()->{
                if(objectDetector!=null)objectDetector.close();
                if(poseLandmarker!=null)poseLandmarker.close();
                if(rawBitmap!=null)rawBitmap.recycle();
                if(rotatedBitmap!=null)rotatedBitmap.recycle();
                if(globalBitmap!=null)globalBitmap.recycle();
                if(tileBitmap!=null)tileBitmap.recycle();
            });
            worker.shutdown();
        }
        super.onDestroy();
    }
}

# ZY辅助 V0.4 · 原生离线 AI 版

这是 Android 原生摄像头与真实 AI 检测项目，不是网页封装，也不再默认显示虚构街道与假识别框。

## 已实现/接入

- 竖屏纯黑启动页，**使用你提供的第二张动漫图片**作为中央软件图标及应用图标；`ZY辅助` 和 `开始使用` 按钮，含平滑渐显、缩放及转场动画。
- 点击开始，打开独立的**横屏原生后置摄像头**。CameraX 管理传感器旋转与 FILL_CENTER 裁剪，替代 V0.3 有问题的 Camera2 固定 1280×720。
- EfficientDet-Lite0 (int8, COCO 80 类) + MediaPipe ObjectDetector，对真实相机帧进行设备本地识别，包括 person、car、bus、truck、bicycle、motorcycle 等。
- 简洁 iOS 风格半透明/毛玻璃视觉面板；5 开关：识别、视觉锁定、夜间增强、距离显示、射线。
- 绿色框取自实际模型输出和置信度；射线从面板下方顶部中央连到真实目标，选中的框高亮；视觉框采用 IoU 简易平滑追踪，**不操纵镜头、瞄准或外部程序**。
- 夜间增强尝试设置设备支持的正曝光补偿，若不支持则提示，不是红外夜视。
- 距离功能需要相机标定，**未标定不会显示虚假的具体米数**。
- 左下角固定 `@ZYCMZC`；不含截图、录屏、模拟目标、复杂雷达。

## 如何使用你现有的 GitHub Actions（安卓手机，无须电脑）

由于原有工作流已经成功跑通，为方便替换，**刻意保留旧 ZIP 名称和内部根文件夹名称**：

- 上传到仓库根目录：`ZY_Assistant_Android_V3.zip`（用本包替换同名旧文件）
- ZIP 内部根目录：`ZY_Assistant_Android_V3/`
- 旧的 `.github/workflows/build.yml` **无需修改**。push 更换 ZIP 时自动运行并生成 `ZY-assistant-debug-apk`。

Gradle 会在构建时从 Google 官方地址下载 `efficientdet_lite0.tflite` 并打进 APK。**GitHub 构建阶段必须联网**，APK 安装后 AI 模型在本机工作，不需要联网推理。若 GitHub 无法下载模型，任务会明确报错并停止，而不是生成没有 AI 的假 APK。

> 如果你希望项目本地离线构建，先手动将模型放到 `app/src/main/assets/efficientdet_lite0.tflite` 中，Gradle 检查到模型文件后将跳过下载。

官方模型地址：https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite

参考： https://developers.google.com/edge/mediapipe/solutions/vision/object_detector/android

## 局限及重要说明

- 本项目是第一版真实 AI 接入源码，**这里无法运行 Android SDK 或手机实机测试**；尚需你的 GitHub Actions 验证 Gradle 编译、再在手机上试运行。不能保证首编译必成功。
- 模型会误检和漏检，计算速度依设备而异。距离数字不具备直接测量依据。应用仅支持**本应用内的后置相机**，没有跨应用悬浮检测或控制其他程序的能力。
- 相机权限只用于本地分析，**未提供网络上传代码**。
- 将来要发布 APK 时应使用正式签名密钥，不建议分发调试签名 APK。

版本 `com.zycmzc.assistant` / `versionCode 4` / `0.4.0-ai`

# ZY辅助 V0.5 · 流畅优先 + 识别数量不限 + 人体骨骼

## 功能

- 竖屏纯黑启动页；沿用你选择的动漫图标、开始使用按钮与进入动画。
- 原生后置相机，高质量预览（CameraX PERFORMANCE）；顶部半透明毛玻璃悬浮面板。
- 顶部 `↻` 按钮切换横屏或竖屏，保存选择，不需要切换其他程序。
- 六个开关：识别、锁定、夜间、距离、射线、骨骼。
- AI 原生离线目标识别，不再设置人为的目标数量上限；但能识别多少目标取决于 EfficientDet-Lite0 模型本身、手机和场景。
- **真正的多人人体骨骼识别**：MediaPipe Pose Landmarker Lite；目前最多输出 6 个姿态，默认关闭；不是根据识别框虚构骨骼。
- 性能改进：约 640×360 分析分辨率、`KEEP_ONLY_LATEST` 丢弃积压帧；**复用像素缓冲区和 Bitmap**；根据检测耗时动态降低推理频率，避免卡住摄像头预览。
- UI 硬件加速：无发光阴影，其他目标只有细框；只给选中目标绘制一条射线；仅在画面或动画变化时刷新。
- 没有截图/录屏按钮，没有虚构距离，左下角固定 `@ZYCMZC`。

**重要区别：** 无“绘制目标数量”人为上限 ≠ 无限 AI 识别能力；骨骼最多6姿态，因为多人姿态推理非常耗性能。AI 次数/秒也不是摄像头预览 FPS。骨骼开启可能降低续航和速度，请按需使用。

## 使用你现在的 GitHub Actions

上传文件名称必须仍是 `ZY_Assistant_Android_V3.zip`，内层仍是 `ZY_Assistant_Android_V3/`。替换仓库里同名 ZIP 并 Commit，原 `.github/workflows/build.yml` 不用改。成功后 Actions → 构建记录 → Artifacts → `ZY-assistant-debug-apk`。

构建时联网从 Google 官方存储下载并内嵌两个模型：`efficientdet_lite0.tflite` 与 `pose_landmarker_lite.task`；安装后这两个模型可离线运行。

## 验证与限制

本项目仅在本地完成源代码和目录检查，**尚未通过 GitHub Actions 实际编译，也未通过安卓真机检验。** 请先编译并测试：横竖屏切换、像素坐标对齐、多人姿态、FPS 是否改善。如果失败，提供失败的 `apk` 构建步骤中红色 Error 行便于修复。

MediaPipe 文档：https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/android

## 构建修复

修正 `app/build.gradle` 中重复声明的 `poseModel` 变量及 `downloadPoseModel` 任务（此前会使 Gradle 配置失败）。其它功能维持不变。

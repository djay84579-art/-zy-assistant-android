# ZY辅助 Android 原生横屏毛玻璃体验版 (v0.3.1 · 摄像头横屏修正版)

**这个项目是原生 Android 应用，不是 WebView 封装。** 采用 Java + Android Camera2 + Canvas 原生绘制。

已实现：
- 强制横屏；沉浸式全屏；“ZY辅助”简洁毛玻璃式控制面板。
- 5 个开关：识别、锁定、夜间增强（视觉演示）、距离显示（演示数值）、顶部射线。
- 开关位置的平滑滑动动画，悬浮面板收起/展开动画，启动过渡动画。
- 左下角 `@ZYCMZC`；无截图、录屏功能。
- 演示模式的背景高斯模糊毛玻璃；后置摄像头实时预览（需要允许相机权限）。

**未实现：真实 AI 识别、物体跟踪、离线模型、真实距离测量、对其他应用的系统级悬浮窗。** 演示模式的目标框、射线与距离均为示意，并标注。摄像头模式不显示虚假的目标框。相机模式面板半透明，但暂未实现实时视频背景的真正动态模糊。

## 仅用 Android 手机构建 APK

1. 在 GitHub 创建新仓库 `zy-assistant-android`，设为 Public。
2. 上传源码包 `ZY_Assistant_Android_V3.zip` 到仓库根目录。
3. 创建 `.github/workflows/build.yml`，内容使用外部提供的 `build-zy-v3.yml`。
4. 仓库 -> Actions -> Build ZY Native APK -> Run workflow。
5. 构建成功后打开对应构建记录，在 Artifacts 下载 `ZY-assistant-debug-apk`，解压取出 `app-debug.apk`，安装到手机。

源码 ZIP 是一个压缩项目，GitHub 不会自动解压；工作流会自行解压并构建。

本项目未在真实 Android SDK 编译环境中验证，请以 Actions 构建结果为准。

## 2026-10-22 相机修复 V0.3.1
- 修复横屏相机预览旋转 90°、画面被拉伸的问题。
- 根据设备屏幕旋转、摄像头 SENSOR_ORIENTATION 及实际支持的预览分辨率自动计算 TextureView 变换。
- 原有演示模式、毛玻璃控制面板、5 个开关及动画不变。
- 注意：不同品牌手机的相机传感器可能不同，需要安装 APK 实机验证。仍未接入 AI 模型。

package com.zycmzc.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;

public class MainActivity extends Activity implements GlassHudView.Listener {
    private FrameLayout root;
    private ImageView demo;
    private TextureView cameraView;
    private GlassHudView hud;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private boolean visible = false;
    private boolean previewWanted = false;
    private boolean opening = false;
    private boolean alive = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(34,55,63));

        demo = new ImageView(this);
        demo.setImageResource(R.drawable.demo_street);
        demo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(demo,new FrameLayout.LayoutParams(-1,-1));

        cameraView = new TextureView(this);
        cameraView.setVisibility(View.GONE);
        root.addView(cameraView,new FrameLayout.LayoutParams(-1,-1));
        cameraView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h) { startCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { closeCamera(); return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) {}
        });
        hud = new GlassHudView(this, this);
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        addSplash();
    }

    @Override protected void onResume() {
        super.onResume(); alive = true;
        if(previewWanted && cameraView!=null && cameraView.isAvailable())startCamera();
    }
    @Override protected void onPause() { alive = false; closeCamera(); super.onPause(); }
    @Override protected void onDestroy() { closeCamera(); super.onDestroy(); }

    private void addSplash() {
        TextView label=new TextView(this);
        label.setText("ZY辅助\n\n简洁 · 毛玻璃 · 横屏");
        label.setGravity(Gravity.CENTER);
        label.setTextSize(23);label.setTextColor(Color.WHITE);
        label.setBackgroundColor(0xED7294AD);
        FrameLayout.LayoutParams l=new FrameLayout.LayoutParams(-1,-1);
        root.addView(label,l);
        label.animate().alpha(0).setStartDelay(600).setDuration(550)
                .withEndAction(()->root.removeView(label)).start();
    }
    @Override public void onModeRequested(boolean cameraMode) {
        if(cameraMode) {
            previewWanted=true;
            cameraView.setAlpha(0f);
            cameraView.setVisibility(View.VISIBLE);
            if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA},57);
                return;
            }
            startCamera();
            cameraView.animate().alpha(1f).setDuration(360).start();
            demo.animate().alpha(0f).setDuration(360).start();
            hud.setCameraMode(true);
            show("相机模式：真实 AI 识别尚未接入");
        } else {
            previewWanted=false;
            hud.setCameraMode(false);
            demo.animate().alpha(1f).setDuration(350).start();
            cameraView.animate().alpha(0f).setDuration(350).withEndAction(()->{
                cameraView.setVisibility(View.GONE);closeCamera();
            }).start();
        }
    }
    @Override public void onHelpRequested() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("ZY辅助 · V0.3 原生体验版")
            .setMessage("这是一款 Android 原生界面体验版。\n\n" +
                "演示：识别框、目标锁定、射线、距离标签为模拟效果，不能代表真实 AI 识别。\n\n" +
                "相机：可预览手机后置摄像头；尚未接入离线 AI 模型，因而不会显示虚假检测框或距离。\n\n" +
                "开关、横屏、毛玻璃风格、界面过渡动画已经接入。\n\n"+
                "左下角频道：@ZYCMZC")
            .setPositiveButton("知道了",null).show();
    }
    @Override public void onCloseRequested() { finish(); }

    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if(req==57) {
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED){
                startCamera();
                if(previewWanted) {
                    cameraView.animate().alpha(1f).setDuration(350).start();
                    demo.animate().alpha(0f).setDuration(350).start();
                    hud.setCameraMode(true);
                }
            } else {
                previewWanted=false;
                cameraView.setVisibility(View.GONE);
                cameraView.setAlpha(0f);
                hud.setCameraMode(false);
                show("未获得摄像头权限，已返回演示模式");
            }
        }
    }
    private void startCamera() {
        if(!previewWanted || !alive || camera!=null || opening ||
                cameraView==null || !cameraView.isAvailable() ||
                checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) return;
        opening=true;
        try {
            CameraManager manager=(CameraManager)getSystemService(CAMERA_SERVICE);
            String chosen=null;
            for(String id:manager.getCameraIdList()) {
                Integer dir=manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if(dir!=null && dir==CameraCharacteristics.LENS_FACING_BACK){ chosen=id;break; }
            }
            if(chosen==null && manager.getCameraIdList().length>0) chosen=manager.getCameraIdList()[0];
            if(chosen==null){opening=false;show("找不到摄像头");return;}
            manager.openCamera(chosen,new CameraDevice.StateCallback(){
                @Override public void onOpened(CameraDevice cd){
                    opening=false;
                    if(!alive || !previewWanted){cd.close();return;}
                    camera=cd;startPreview();
                }
                @Override public void onDisconnected(CameraDevice cd){opening=false;cd.close();if(camera==cd)camera=null;}
                @Override public void onError(CameraDevice cd,int e){opening=false;cd.close();if(camera==cd)camera=null;show("相机启动失败 "+e);}
            },null);
        } catch(Exception e) {opening=false;show("摄像头不可用："+e.getMessage());}
    }
    private void startPreview() {
        if(camera==null || !cameraView.isAvailable())return;
        try{
            SurfaceTexture st=cameraView.getSurfaceTexture();
            st.setDefaultBufferSize(1280,720);
            Surface surf=new Surface(st);
            CaptureRequest.Builder req=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            req.addTarget(surf);
            req.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            camera.createCaptureSession(Collections.singletonList(surf),new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession cs){
                    if(camera==null || !previewWanted){cs.close();return;}
                    session=cs;
                    try{cs.setRepeatingRequest(req.build(),null,null);} catch(CameraAccessException e){show("预览配置失败");}
                }
                @Override public void onConfigureFailed(CameraCaptureSession cs){show("相机预览失败");}
            },null);
        } catch(Exception e){show("相机预览异常："+e.getMessage());}
    }
    private void closeCamera(){
        if(session!=null){session.close();session=null;}
        if(camera!=null){camera.close();camera=null;}
        opening=false;
    }
    private void show(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}

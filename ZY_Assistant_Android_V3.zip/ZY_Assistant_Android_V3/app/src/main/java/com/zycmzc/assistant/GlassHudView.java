package com.zycmzc.assistant;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

public class GlassHudView extends View {
    public interface Listener {
        void onModeRequested(boolean camera);
        void onHelpRequested();
        void onCloseRequested();
    }
    private final Listener listener;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap blurredBackground;
    private final String[] labels = {"识别", "锁定", "夜间增强", "距离显示", "射线"};
    private final boolean[] checked = {true, true, false, true, true};
    private final float[] smooth = {1f,1f,0f,1f,1f};
    private float expand = 1f;
    private boolean expanded = true;
    private boolean cameraMode = false;
    private float px,py,pw,ph;
    private final RectF[] tileHits = new RectF[5];
    private RectF closeHit,collapseHit,modeHit,helpHit,restoreHit;
    private long lastTime;
    private float t;
    private float d;
    private final int WHITE = Color.WHITE;
    private final int GREEN = Color.rgb(45,226,125);

    public GlassHudView(Context context, Listener listener) {
        super(context);
        this.listener=listener;
        d=context.getResources().getDisplayMetrics().density;
        for(int i=0;i<tileHits.length;i++)tileHits[i]=new RectF();
        blurredBackground = BitmapFactory.decodeResource(context.getResources(), R.drawable.demo_street_blur);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    public void setCameraMode(boolean b) { cameraMode=b; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        if(w<1 || h<1)return;
        long now=System.currentTimeMillis();
        float dt=lastTime==0 ? .016f : Math.min(.05f,(now-lastTime)/1000f);
        lastTime=now;
        t+=dt;
        float k=1-(float)Math.pow(.001,dt);
        float target=expanded?1f:0f;
        expand += (target-expand)*k;
        for(int i=0;i<5;i++)smooth[i]+=( (checked[i]?1f:0f)-smooth[i])*k;
        float m = Math.min(w,h);
        pw=Math.min(w*.74f,dp(810)); ph=Math.max(dp(122),h*.30f);
        ph=Math.min(ph,h*.43f);
        px=(w-pw)/2f;py=Math.max(dp(9),h*.037f);
        float actualH=ph*expand;

        // A very light overlay is only an enhancement preview, not real night-vision processing.
        if(smooth[2]>.01f) {
            p.setShader(new LinearGradient(0,0,0,h,0x18FFFFFF,0x0EECF6FF,Shader.TileMode.CLAMP));
            p.setAlpha(Math.round(155*smooth[2]));
            c.drawRect(0,0,w,h,p);
            p.setAlpha(255);p.setShader(null);
        }
        if(!cameraMode)drawDemoDetections(c,w,h);
        else drawCameraNotice(c,w,h);

        // True prerendered Gaussian blur is used behind the demo glass.
        if(expand>.035f)drawFrostedPanel(c,new RectF(px,py,px+pw,py+actualH),w,h,expand);
        if(expand>.75f) {
            drawTitleBar(c);
            drawTiles(c);
        }
        if(expand<.9f)drawRestore(c,w);
        drawBrandAndMode(c,w,h);

        if(Math.abs(expand-target)>.003f || movingToggles())postInvalidateOnAnimation();
        else if(!cameraMode && checked[0])postInvalidateDelayed(60);
    }
    private boolean movingToggles(){
        for(int i=0;i<5;i++)if(Math.abs(smooth[i]-(checked[i]?1f:0f))>.003f)return true;
        return false;
    }
    private float dp(float value){return value*d;}
    private int alpha(int rgb,int a){return (rgb & 0x00FFFFFF) | (Math.max(0,Math.min(255,a))<<24);}
    private void fill(int color){p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.FILL);p.setColor(color);}
    private void stroke(int color,float width){p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);p.setColor(color);}
    private void rr(Canvas c,RectF r,float radius,int color){fill(color);c.drawRoundRect(r,radius,radius,p);}
    private void text(Canvas c,String s,float x,float y,float size,int color, boolean bold,boolean center){
        fill(color);p.setTextSize(size);p.setFakeBoldText(bold);
        if(center)p.setTextAlign(Paint.Align.CENTER);
        c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);p.setFakeBoldText(false);
    }
    private void drawFrostedPanel(Canvas c,RectF r,float w,float h,float opacity){
        Path mask=new Path();float radius=dp(26);mask.addRoundRect(r,radius,radius,Path.Direction.CW);
        if(!cameraMode && blurredBackground!=null){
            c.save();c.clipPath(mask);
            int bw=blurredBackground.getWidth(), bh=blurredBackground.getHeight();
            float srcAspect=bw/(float)bh, dstAspect=w/h;
            Rect src;
            if(srcAspect>dstAspect){int crop=(int)(bh*dstAspect);src=new Rect((bw-crop)/2,0,(bw+crop)/2,bh);}
            else{int crop=(int)(bw/dstAspect);src=new Rect(0,(bh-crop)/2,bw,(bh+crop)/2);}
            fill(WHITE);c.drawBitmap(blurredBackground,src,new RectF(0,0,w,h),p);
            c.restore();
        }
        fill(alpha(0xFFCEDEEF,(int)(154*opacity)));
        p.setShader(new LinearGradient(r.left,r.top,r.right,r.bottom,
                alpha(0xFFF6FBFF,(int)(178*opacity)),alpha(0xFF9AB3C7,(int)(120*opacity)),Shader.TileMode.CLAMP));
        c.drawRoundRect(r,radius,radius,p);p.setShader(null);
        stroke(alpha(WHITE,(int)(210*opacity)),dp(1.2f));c.drawRoundRect(r,radius,radius,p);
    }
    private void drawTitleBar(Canvas c){
        float ty=py+ph*.22f;
        text(c,"Z",px+dp(22),ty,dp(21),0xFFFFFFFF,true,false);
        text(c,"ZY辅助",px+pw/2,ty,dp(20),0xFFFFFFFF,true,true);
        float btnR=dp(14);
        float bx=px+pw-dp(78), cx=px+pw-dp(35), cy=py+ph*.19f;
        fill(0x3BFFFFFF);c.drawCircle(bx,cy,btnR,p);c.drawCircle(cx,cy,btnR,p);
        stroke(WHITE,dp(1.7f));c.drawLine(bx-dp(6),cy,bx+dp(6),cy,p);
        c.drawLine(cx-dp(5),cy-dp(5),cx+dp(5),cy+dp(5),p);
        c.drawLine(cx-dp(5),cy+dp(5),cx+dp(5),cy-dp(5),p);
        collapseHit=new RectF(bx-dp(19),cy-dp(18),bx+dp(19),cy+dp(18));
        closeHit=new RectF(cx-dp(19),cy-dp(18),cx+dp(19),cy+dp(18));
    }
    private void drawTiles(Canvas c){
        float pad=dp(13),gap=dp(7);
        float ww=(pw-pad*2-gap*4)/5;
        float top=py+ph*.35f, height=ph*.56f;
        for(int i=0;i<5;i++){
            float x=px+pad+i*(ww+gap);
            RectF r=new RectF(x,top,x+ww,top+height);
            tileHits[i].set(r);
            rr(c,r,dp(16),0x25FFFFFF);
            stroke(0x40FFFFFF,dp(.65f));c.drawRoundRect(r,dp(16),dp(16),p);
            float cx=r.centerX();
            text(c,labels[i],cx,top+height*.38f,Math.min(dp(13),ww*.14f),0xFFFBFFFF,true,true);
            float sw=Math.min(dp(49),ww*.55f), sh=Math.min(dp(24),height*.27f);
            RectF track=new RectF(cx-sw/2,top+height*.55f,cx+sw/2,top+height*.55f+sh);
            fill(0x99000000);c.drawRoundRect(track,sh/2,sh/2,p);
            fill(alpha(GREEN,(int)(255*smooth[i])));c.drawRoundRect(track,sh/2,sh/2,p);
            stroke(0x80FFFFFF,dp(.8f));c.drawRoundRect(track,sh/2,sh/2,p);
            float knob=sh*.43f;
            float knobX=track.left+sh/2+(sw-sh)*smooth[i];
            fill(WHITE);c.drawCircle(knobX,track.centerY(),knob,p);
        }
    }
    private void drawRestore(Canvas c,float w){
        float width=dp(123), height=dp(38), cx=w/2f;
        float y=py;
        restoreHit=new RectF(cx-width/2,y,cx+width/2,y+height);
        rr(c,restoreHit,dp(19),0xB5BFD8E9);
        stroke(0xDDFFFFFF,dp(1));c.drawRoundRect(restoreHit,dp(19),dp(19),p);
        text(c,"ZY辅助  ⌄",cx,y+dp(25),dp(15),WHITE,true,true);
    }
    private void drawDemoDetections(Canvas c,float w,float h){
        if(smooth[0]<=.01f)return;
        float[][] boxes={{.13f,.60f,.26f,.91f},{.32f,.69f,.48f,.85f},{.52f,.70f,.61f,.81f},{.73f,.69f,.9f,.88f}};
        String[] names={"人","车","车","车"};
        String[] meters={"12.3m","18.6m","28.4m","10.5m"};
        float lineOpacity=smooth[4]*smooth[0];
        float startX=w/2, startY=py+ph*expand+dp(2);
        if(lineOpacity>.01f && expand>.60f){
            stroke(alpha(0xFFFF6A7A,(int)(240*lineOpacity)),dp(1.7f));
            p.setShadowLayer(dp(6),0,0,alpha(0xFFFF3D55,(int)(205*lineOpacity)));
            for(int i=0;i<boxes.length;i++){
                float center=(boxes[i][0]+boxes[i][2])/2*w;
                float ty=boxes[i][1]*h-dp(3);
                c.drawLine(startX,startY,center,ty,p);
            }
            p.clearShadowLayer();
        }
        for(int i=0;i<boxes.length;i++){
            float movement=(float)Math.sin(t*.8f+i)*dp(1.2f);
            float l=boxes[i][0]*w, y=boxes[i][1]*h+movement;
            float r=boxes[i][2]*w, bottom=boxes[i][3]*h+movement;
            boolean locked=i==3&&smooth[1]>.05f;
            int color=locked?alpha(0xFFFF6370,(int)(255*smooth[1])):GREEN;
            stroke(color,Math.max(dp(1.2f),w*.0015f));
            c.drawRoundRect(new RectF(l,y,r,bottom),dp(5),dp(5),p);
            String label=names[i] + (smooth[3]>.5f?" "+meters[i]:"");
            float size=dp(12);
            p.setTextSize(size);float labelW=p.measureText(label)+dp(15);
            RectF tag=new RectF(l,y-dp(27),l+labelW,y-dp(3));
            rr(c,tag,dp(6),locked?0xDEB73D52:0xDA19382A);
            stroke(color,dp(1));c.drawRoundRect(tag,dp(6),dp(6),p);
            text(c,label,l+dp(7),y-dp(10),size,WHITE,true,false);
        }
        text(c,"演示模式 · 检测框与距离为示意",w/2,h-dp(21),dp(12),0xF5FFFFFF,false,true);
    }
    private void drawCameraNotice(Canvas c,float w,float h){
        text(c,"相机预览 · AI 检测未接入 · 距离未标定",w/2,h-dp(22),dp(12),WHITE,false,true);
    }
    private void drawBrandAndMode(Canvas c,float w,float h){
        float bottom=h-dp(18), hh=dp(38);
        RectF brand=new RectF(dp(16),bottom-hh,dp(175),bottom);
        rr(c,brand,dp(19),0x8EA4BAC7);
        stroke(0xC6FFFFFF,dp(.9f));c.drawRoundRect(brand,dp(19),dp(19),p);
        text(c,"@ZYCMZC",brand.centerX(),brand.centerY()+dp(5),dp(15),WHITE,true,true);

        float right=w-dp(16), cw=dp(155);
        modeHit=new RectF(right-cw,bottom-hh,right,bottom);
        rr(c,modeHit,dp(18),0xA6BACBD8);
        stroke(0xCBFFFFFF,dp(.9f));c.drawRoundRect(modeHit,dp(18),dp(18),p);
        text(c,cameraMode?"相机模式  ·  切换":"演示模式  ·  切换",modeHit.centerX(),modeHit.centerY()+dp(5),dp(13),WHITE,true,true);
        helpHit=new RectF(w-dp(53),py+ph*.12f,w-dp(12),py+ph*.30f);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX(),y=e.getY();
        if(expand<.6f){
            if(restoreHit!=null && restoreHit.contains(x,y)){expanded=true;invalidate();return true;}
        } else {
            if(closeHit!=null&&closeHit.contains(x,y)){listener.onCloseRequested();return true;}
            if(collapseHit!=null&&collapseHit.contains(x,y)){expanded=false;invalidate();return true;}
            for(int i=0;i<5;i++)if(tileHits[i]!=null&&tileHits[i].contains(x,y)){
                checked[i]=!checked[i];invalidate();return true;
            }
            // Tap the header brand for help.
            if(x>px&&x<px+pw*.28f&&y>py&&y<py+ph*.32f){listener.onHelpRequested();return true;}
        }
        if(modeHit!=null && modeHit.contains(x,y)){
            listener.onModeRequested(!cameraMode);return true;
        }
        return true;
    }
}

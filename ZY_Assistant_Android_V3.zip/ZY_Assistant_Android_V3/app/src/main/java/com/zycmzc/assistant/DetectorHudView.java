package com.zycmzc.assistant;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Minimal dark controls. Detection rectangles and skeletons come only from real model results. */
public class DetectorHudView extends View {
    public interface Listener {
        void onRecognitionChanged(boolean value);
        void onPoseChanged(boolean value);
        void onNightChanged(boolean value);
        void onSensitivityChanged(float threshold);
        void onRotatePressed();
        void onClosePressed();
        void onHelpPressed();
    }

    public static class Found {
        public final RectF rect;
        public final String label;
        public final float confidence;
        public Found(RectF rect, String label, float confidence) {
            this.rect = new RectF(rect);
            this.label = label;
            this.confidence = confidence;
        }
    }

    private static class Track {
        final int id;
        final String label;
        float confidence;
        final RectF current;
        final RectF target;
        long seen;
        Track(int id, Found item, long now) {
            this.id = id;
            this.label = item.label;
            this.confidence = item.confidence;
            current = new RectF(item.rect);
            target = new RectF(item.rect);
            seen = now;
        }
    }

    // Real MediaPipe pose joints, not synthetic skeletons.
    private static final int[][] BONES = {
        {11,12},{11,13},{13,15},{12,14},{14,16},
        {11,23},{12,24},{23,24},{23,25},{25,27},{24,26},{26,28}
    };
    private static final int TEXT = 0xFFF0F5FF;
    private static final int MUTED = 0xFF9FB0CB;
    private static final int ACCENT = 0xFF22BDFB;
    private static final int TARGET = 0xFF70DDC4;
    private static final int LOCK = 0xFF60BFFE;

    private static final Typeface FONT_NORMAL = Typeface.create("sans-serif",Typeface.NORMAL);
    private static final Typeface FONT_MEDIUM = Typeface.create("sans-serif-medium",Typeface.NORMAL);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Listener listener;
    private final List<Track> tracks = new ArrayList<>();
    private final RectF[] buttons = new RectF[8];
    // Object drawing is separate from person boxes and is OFF by default.
    private final boolean[] enabled = {true, true, false, false, false, true, false, false};
    private final float[] animated = {1,1,0,0,0,1,0,0};
    private final String[] titles = {
        "AI识别", "人体方框", "骨骼绘制", "射线绘制",
        "物品绘制", "目标锁定", "夜间增强", "距离显示"
    };
    private final RectF capsule = new RectF();
    private final RectF rotate = new RectF();
    private final RectF close = new RectF();
    private final RectF info = new RectF();
    private final RectF slider = new RectF();
    private final RectF screenBox = new RectF();
    private final RectF panelBox = new RectF();
    private final RectF switchBox = new RectF();
    private final List<float[][]> emptyPoses = new ArrayList<>();
    private List<float[][]> poses = emptyPoses;
    private int srcW = 640, srcH = 360;
    private int nextTrack = 1, lockedTrack = -1, analyzeRate, analyzeTime;
    private float density, expandedProgress, sensitivity = .40f;
    private float panelLeft, panelTop, panelWidth, panelHeight;
    private long lastDraw, posesUpdated, statusUpdated;
    private String status = "相机连接中";
    private boolean expanded = false; // default only the small black dynamic island
    private boolean sliderDragging;

    public DetectorHudView(Context context, Listener callback) {
        super(context);
        listener = callback;
        density = context.getResources().getDisplayMetrics().density;
        for (int i=0; i<buttons.length; i++) buttons[i]=new RectF();
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    private float dp(float value){ return value*density; }
    private void paint(int color){
        paint.reset(); paint.setAntiAlias(true); paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
    }
    private void stroke(int color, float size){
        paint(color); paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(size);
    }
    private void round(Canvas canvas, RectF r, float radius, int color){
        paint(color);canvas.drawRoundRect(r,radius,radius,paint);
    }
    private int withAlpha(int color, float alpha){
        return (Math.round(255*Math.max(0,Math.min(1,alpha))) << 24) | (color & 0x00FFFFFF);
    }
    private void write(Canvas c,String text,float x,float y,float size,int color,boolean center,boolean bold){
        paint(color);paint.setTextSize(size);
        paint.setTypeface(bold ? FONT_MEDIUM : FONT_NORMAL);
        paint.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);
        c.drawText(text,x,y,paint);
    }

    public void setMessage(String msg){
        status = msg;statusUpdated = SystemClock.elapsedRealtime();invalidate();
    }
    public void setPoseState(boolean on){enabled[2] = on;invalidate();}
    public void setPoses(List<float[][]> data,int width,int height){
        poses=data;posesUpdated=SystemClock.elapsedRealtime();srcW=width;srcH=height;invalidate();
    }
    public void setDetections(List<Found> found, int width,int height,int rate,int time){
        srcW=Math.max(1,width);srcH=Math.max(1,height);
        analyzeRate=rate;analyzeTime=time;
        long now=SystemClock.elapsedRealtime();
        List<Track> available=new ArrayList<>(tracks);
        for(Found item:found){
            Track best=null;
            float match=.18f;
            for(Track tr:available){
                if(!tr.label.equals(item.label))continue;
                float score=iou(tr.target,item.rect);
                if(score>match){match=score;best=tr;}
            }
            if(best==null)tracks.add(new Track(nextTrack++,item,now));
            else {
                best.target.set(item.rect);best.confidence=item.confidence;best.seen=now;
                available.remove(best);
            }
        }
        tracks.removeIf(tr->now-tr.seen>800);
        if(enabled[5] && !contains(lockedTrack)){
            Track best=null;
            for(Track tr:tracks){
                if(!visible(tr)) continue;
                if(best==null || tr.target.width()*tr.target.height()>best.target.width()*best.target.height())best=tr;
            }
            lockedTrack=best==null?-1:best.id;
        }
        // Avoid triggering expensive continuous rendering if user only wants camera preview.
        if(enabled[1]||enabled[4]||enabled[2])postInvalidateOnAnimation();
    }
    private boolean person(Track t){return "person".equalsIgnoreCase(t.label);}
    private boolean visible(Track t){return person(t)?enabled[1]:enabled[4];}
    private boolean contains(int id){
        for(Track t:tracks)if(t.id==id && visible(t))return true;
        return false;
    }
    private static float iou(RectF a,RectF b){
        float w=Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left));
        float h=Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
        float area=w*h, union=a.width()*a.height()+b.width()*b.height()-area;
        return union<=0?0:area/union;
    }
    private void project(RectF input,int width,int height,RectF dest){
        float scale=Math.max((float)width/srcW,(float)height/srcH);
        float dx=(width-srcW*scale)/2f,dy=(height-srcH*scale)/2f;
        dest.set(dx+input.left*scale,dy+input.top*scale,dx+input.right*scale,dy+input.bottom*scale);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(),h=getHeight();if(w==0||h==0)return;
        long now=SystemClock.elapsedRealtime();
        float frameTime=lastDraw==0?.016f:Math.min(.05f,(now-lastDraw)/1000f);
        lastDraw=now;
        float spring=1-(float)Math.exp(-13*frameTime);
        boolean moving=false;
        float targetExpand=expanded?1:0;
        expandedProgress+=(targetExpand-expandedProgress)*spring;
        if(Math.abs(targetExpand-expandedProgress)>.005f)moving=true;
        for(int i=0;i<animated.length;i++){
            float goal=enabled[i]?1:0;
            animated[i]+=(goal-animated[i])*spring;
            if(Math.abs(goal-animated[i])>.01f)moving=true;
        }
        boolean portrait=h>w;
        float capWidth=Math.min(dp(158),w*.50f);
        capsule.set((w-capWidth)/2,dp(7),(w+capWidth)/2,dp(45));
        panelWidth=Math.min(w-dp(20),portrait?dp(380):dp(560));
        panelHeight=Math.min(h-dp(67),portrait?dp(330):dp(210));
        panelLeft=(w-panelWidth)/2;panelTop=dp(50);

        if(enabled[0] && (enabled[1]||enabled[4]))moving|=drawObjects(c,w,h,spring);
        if(enabled[2] && now-posesUpdated<1500)drawPose(c,w,h);
        drawPanel(c,portrait);
        // Channel mark small, unobtrusive and ALWAYS present.
        write(c,"@ZYCMZC",dp(12),h-dp(14),dp(11),0xD7FFFFFF,false,true);
        if(now-statusUpdated<2000 && !expanded){
            write(c,status,Math.max(dp(130),w*.57f),h-dp(14),dp(9.5f),0xBCFFFFFF,false,false);
        }
        if(moving)postInvalidateOnAnimation();
    }

    private void drawPanel(Canvas c,boolean portrait){
        // Dark island remains visible whether or not the panel is open.
        round(c,capsule,dp(19),0xF4080A0F);
        stroke(0x87677C9F,dp(.85f));c.drawRoundRect(capsule,dp(19),dp(19),paint);
        paint(ACCENT);c.drawCircle(capsule.left+dp(15),capsule.centerY(),dp(3),paint);
        write(c,"ZY辅助",capsule.centerX(),capsule.centerY()+dp(5),dp(14),TEXT,true,true);
        write(c,expanded?"⌃":"⌄",capsule.right-dp(17),capsule.centerY()+dp(5),dp(14),MUTED,true,true);
        if(expandedProgress<.01f)return;
        panelBox.set(panelLeft,panelTop,panelLeft+panelWidth,
            panelTop+panelHeight*expandedProgress);
        round(c,panelBox,dp(18),0xE91B202B);
        stroke(0x80677D9B,dp(.9f));c.drawRoundRect(panelBox,dp(18),dp(18),paint);
        if(expandedProgress<.92f)return;
        c.save();c.clipRect(panelBox);
        float margin=dp(10),gap=dp(6);
        int cols=portrait?2:4,rows=portrait?4:2;
        float rowsHeight=panelHeight-dp(58);
        float itemW=(panelWidth-2*margin-gap*(cols-1))/cols;
        float itemH=(rowsHeight-gap*(rows-1))/rows;
        for(int i=0;i<8;i++){
            int col=i%cols,row=i/cols;
            float x=panelLeft+margin+col*(itemW+gap);
            float y=panelTop+dp(10)+row*(itemH+gap);
            RectF item=buttons[i]; item.set(x,y,x+itemW,y+itemH);
            round(c,item,dp(10),enabled[i]?0x49305075:0x44373C47);
            stroke(enabled[i]?0xAD229DF2:0x4B748198,dp(.75f));
            c.drawRoundRect(item,dp(10),dp(10),paint);
            write(c,titles[i],item.left+dp(9),item.top+dp(16),
                portrait?dp(11):dp(11.5f),TEXT,false,false);
            float knobW=dp(32),knobH=dp(17);
            float x0=item.right-dp(9)-knobW;
            float y0=item.bottom-dp(7)-knobH;
            switchBox.set(x0,y0,x0+knobW,y0+knobH);
            round(c,switchBox,dp(9),0xFF49525F);
            round(c,switchBox,dp(9),withAlpha(0xFF159FF6,animated[i]));
            paint(Color.WHITE);
            c.drawCircle(x0+dp(9)+(knobW-knobH)*animated[i],y0+knobH/2,dp(6.5f),paint);
        }
        float bottom=panelTop+panelHeight;
        float baseline=bottom-dp(17);
        float sliderStart=panelLeft+dp(73);
        float sliderEnd=panelLeft+panelWidth-dp(124);
        if(sliderEnd<sliderStart+dp(22))sliderEnd=sliderStart+dp(22);
        write(c,"灵敏度",panelLeft+dp(12),baseline+dp(4),dp(11),MUTED,false,false);
        slider.set(sliderStart,baseline-dp(12),sliderEnd,baseline+dp(10));
        stroke(0xFF4B586B,dp(4));c.drawLine(sliderStart,baseline,sliderEnd,baseline,paint);
        float norm=(sensitivity-.25f)/.45f;
        stroke(ACCENT,dp(4));c.drawLine(sliderStart,baseline,sliderStart+(sliderEnd-sliderStart)*norm,baseline,paint);
        paint(0xFFF3FAFF);c.drawCircle(sliderStart+(sliderEnd-sliderStart)*norm,baseline,dp(5),paint);
        float rb=panelLeft+panelWidth-dp(114);
        rotate.set(rb,bottom-dp(35),rb+dp(66),bottom-dp(7));
        round(c,rotate,dp(8),0xFF1D587E);
        write(c,"横 / 竖",rotate.centerX(),rotate.centerY()+dp(4),dp(10.5f),TEXT,true,true);
        close.set(panelLeft+panelWidth-dp(41),bottom-dp(35),panelLeft+panelWidth-dp(9),bottom-dp(7));
        round(c,close,dp(8),0xFF323945);
        write(c,"×",close.centerX(),close.centerY()+dp(5),dp(17),TEXT,true,false);
        info.set(panelLeft,panelTop,panelLeft+dp(40),panelTop+dp(34));
        c.restore();
    }

    private boolean drawObjects(Canvas c,int w,int h,float factor){
        boolean inMotion=false;
        Track chosen=null;
        if(enabled[5])for(Track t:tracks)if(t.id==lockedTrack && visible(t))chosen=t;
        for(Track t:tracks){
            if(!visible(t))continue;
            float sum=Math.abs(t.current.left-t.target.left)+Math.abs(t.current.top-t.target.top)
                    +Math.abs(t.current.right-t.target.right)+Math.abs(t.current.bottom-t.target.bottom);
            if(sum>1f){
                inMotion=true;
                t.current.left+=(t.target.left-t.current.left)*factor;
                t.current.top+=(t.target.top-t.current.top)*factor;
                t.current.right+=(t.target.right-t.current.right)*factor;
                t.current.bottom+=(t.target.bottom-t.current.bottom)*factor;
            } else t.current.set(t.target);
            project(t.current,w,h,screenBox);
            if(screenBox.right<0 || screenBox.left>w || screenBox.bottom<0 || screenBox.top>h)continue;
            boolean locked=(t==chosen);
            stroke(locked?LOCK:TARGET,dp(locked?1.8f:1.1f));
            c.drawRoundRect(screenBox,dp(3),dp(3),paint);
            if(locked){
                write(c,translate(t.label)+"  "+Math.round(t.confidence*100)+"%",
                    Math.max(dp(5),screenBox.left),Math.max(dp(13),screenBox.top-dp(5)),dp(11),TEXT,false,true);
                if(enabled[3]){
                    stroke(0xC947B5FF,dp(1.4f));
                    c.drawLine(w/2f,dp(48),screenBox.centerX(),screenBox.top,paint);
                }
            }
        }
        return inMotion;
    }
    private String translate(String label){
        if(label==null)return "目标";
        switch(label.toLowerCase(Locale.ROOT)){
            case "person":return "人物";
            case "car":return "车辆";
            case "truck":return "卡车";
            case "bus":return "公交";
            case "motorcycle":return "摩托";
            case "bicycle":return "自行车";
            default:return label;
        }
    }
    private void drawPose(Canvas c,int w,int h){
        float scale=Math.max((float)w/srcW,(float)h/srcH);
        float ox=(w-srcW*scale)/2f,oy=(h-srcH*scale)/2f;
        stroke(0xD14BB9FF,dp(1.3f));
        for(float[][] body:poses){
            for(int[] edge:BONES){
                if(edge[0]>=body.length || edge[1]>=body.length)continue;
                float[] p=body[edge[0]],q=body[edge[1]];
                if(p[2]<.42f || q[2]<.42f)continue;
                c.drawLine(ox+p[0]*srcW*scale,oy+p[1]*srcH*scale,
                    ox+q[0]*srcW*scale,oy+q[1]*srcH*scale,paint);
            }
        }
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        float x=event.getX(),y=event.getY();
        if(event.getAction()==MotionEvent.ACTION_DOWN){
            sliderDragging=expanded && expandedProgress>.92f && slider.contains(x,y);
            if(sliderDragging)changeSensitivity(x);
            return true;
        }
        if(event.getAction()==MotionEvent.ACTION_MOVE){
            if(sliderDragging)changeSensitivity(x);
            return true;
        }
        if(event.getAction()==MotionEvent.ACTION_CANCEL){sliderDragging=false;return true;}
        if(event.getAction()!=MotionEvent.ACTION_UP)return true;
        if(sliderDragging){changeSensitivity(x);sliderDragging=false;return true;}
        if(capsule.contains(x,y)){
            expanded=!expanded;postInvalidateOnAnimation();return true;
        }
        if(!expanded || expandedProgress<.92f)return true;
        if(close.contains(x,y)){listener.onClosePressed();return true;}
        if(rotate.contains(x,y)){listener.onRotatePressed();return true;}
        for(int i=0;i<buttons.length;i++){
            if(!buttons[i].contains(x,y))continue;
            enabled[i]=!enabled[i];
            if(i==0){listener.onRecognitionChanged(enabled[i]);if(!enabled[i])tracks.clear();}
            if(i==1 || i==4){if(!contains(lockedTrack))lockedTrack=-1;}
            if(i==2){listener.onPoseChanged(enabled[i]);if(!enabled[i])poses=emptyPoses;}
            if(i==6)listener.onNightChanged(enabled[i]);
            if(i==7 && enabled[i])setMessage("距离尚未标定，不显示虚假米数");
            postInvalidateOnAnimation();return true;
        }
        for(Track tr:tracks){
            if(!visible(tr))continue;
            project(tr.current,getWidth(),getHeight(),screenBox);
            if(screenBox.contains(x,y)){
                lockedTrack=tr.id;postInvalidateOnAnimation();return true;
            }
        }
        return true;
    }
    private void changeSensitivity(float x){
        float norm=Math.max(0,Math.min(1,(x-slider.left)/Math.max(1,slider.width())));
        float next=.25f+.45f*norm;
        if(Math.abs(next-sensitivity)<.005f)return;
        sensitivity=next;
        listener.onSensitivityChanged(sensitivity);
        invalidate();
    }
}

package com.zycmzc.assistant;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DetectorHudView extends View {
    public interface Listener {
        void onNightChanged(boolean enabled);
        void onClosePressed();
        void onHelpPressed();
    }
    public static class Found {
        public final RectF rect;
        public final String label;
        public final float confidence;
        public Found(RectF r,String label,float conf) {
            this.rect=new RectF(r);this.label=label;this.confidence=conf;
        }
    }
    private static class Track {
        int id; RectF current,target; String label; float confidence;
        long seen;
        Track(int id,Found f,long ms){this.id=id;current=new RectF(f.rect);
            target=new RectF(f.rect);label=f.label;confidence=f.confidence;seen=ms;}
    }
    private final Listener listener;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Track> tracks=new ArrayList<>();
    private final RectF[] switchHits=new RectF[5];
    private final boolean[] checked={true,true,false,false,true};
    private final float[] eased={1f,1f,0f,0f,1f};
    private final String[] labels={"识别","锁定","夜间增强","距离显示","射线"};
    private int nextId=1,sourceWidth=1280,sourceHeight=720, fps, inference;
    private String message="准备启动原生相机…";
    private long messageAt,lastDrawTime;
    private boolean expanded=true;
    private float expandedProgress=1f;
    private RectF collapseHit=new RectF(), closeHit=new RectF(), restoreHit=new RectF(),titleHit=new RectF();
    private float panelLeft,panelTop,panelW,panelH;
    private int selectedId=-1;
    private final int MINT=0xFF34E894;
    private final int WHITE=0xFFF8FBFF;
    private final int RED=0xFFFF536A;
    private float density;

    public DetectorHudView(Context context,Listener listener) {
        super(context);this.listener=listener;
        density=context.getResources().getDisplayMetrics().density;
        for(int i=0;i<5;i++)switchHits[i]=new RectF();
        setLayerType(LAYER_TYPE_SOFTWARE,null);
    }
    private float dp(float x){return x*density;}
    private void fill(int color) {paint.reset();paint.setAntiAlias(true);paint.setColor(color);paint.setStyle(Paint.Style.FILL);}
    private void stroke(int color,float width) {fill(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);}
    private void round(Canvas c,RectF r,float corner,int color){fill(color);c.drawRoundRect(r,corner,corner,paint);}
    private int alpha(int color,float f){return (color & 0x00FFFFFF)|(((int)(Math.max(0,Math.min(1,f))*255))<<24);}
    private void writeText(Canvas c,String text,float x,float y,float px,int color, boolean center,boolean bold){
        fill(color);paint.setTextSize(px);paint.setFakeBoldText(bold);
        paint.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);
        c.drawText(text,x,y,paint);
        paint.setFakeBoldText(false);
    }
    public void setMessage(String text){message=text;messageAt=SystemClock.elapsedRealtime();invalidate();}

    public void setDetections(List<Found> results,int width,int height,int frames,int ms) {
        sourceWidth=width;sourceHeight=height;fps=frames;inference=ms;
        long now=SystemClock.elapsedRealtime();
        List<Track> free=new ArrayList<>(tracks);
        for(Found f:results) {
            Track best=null; float bestScore=0.17f;
            for(Track track:free) {
                if(!track.label.equals(f.label))continue;
                float iou=iou(track.target,f.rect);
                if(iou>bestScore){bestScore=iou;best=track;}
            }
            if(best==null) tracks.add(new Track(nextId++,f,now));
            else {
                best.target.set(f.rect);best.confidence=f.confidence;
                best.seen=now;free.remove(best);
            }
        }
        tracks.removeIf(track->now-track.seen>520);
        if(checked[1] && !tracks.isEmpty() && !containsId(selectedId)) {
            float largest=-1;
            for(Track t:tracks){float a=t.target.width()*t.target.height();
                if(a>largest){largest=a;selectedId=t.id;}}
        }
        invalidate();
    }
    private boolean containsId(int id){for(Track t:tracks)if(t.id==id)return true;return false;}
    private float iou(RectF a, RectF b){
        float x=Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left));
        float y=Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
        float area=x*y;
        float total=a.width()*a.height()+b.width()*b.height()-area;
        return total<=0?0:area/total;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float width=getWidth(),height=getHeight();
        if(width<=0||height<=0)return;
        long now=SystemClock.elapsedRealtime();
        float dt=lastDrawTime==0?.016f:Math.min(.045f,(now-lastDrawTime)/1000f);
        lastDrawTime=now;
        float factor=1-(float)Math.exp(-9f*dt);
        float targetExp=expanded?1f:0f;
        expandedProgress+=(targetExp-expandedProgress)*factor;
        boolean animating=Math.abs(expandedProgress-targetExp)>.004f;
        for(int i=0;i<5;i++){
            float dest=checked[i]?1f:0f;
            eased[i]+=(dest-eased[i])*factor;
            if(Math.abs(eased[i]-dest)>.004f)animating=true;
        }
        if(eased[2]>.03f){
            fill(alpha(0xFFDBE8FF,.09f*eased[2]));
            c.drawRect(0,0,width,height,paint);
        }
        panelW=Math.min(width*.77f,dp(840));panelH=Math.min(dp(150),height*.31f);
        panelLeft=(width-panelW)/2;panelTop=dp(12);
        drawTargets(c,width,height,now,factor);
        if(expandedProgress>.05f) {
            drawPanel(c,new RectF(panelLeft,panelTop,panelLeft+panelW,panelTop+panelH*expandedProgress));
            if(expandedProgress>.85f){drawTitle(c);drawSwitches(c);}
        }
        if(expandedProgress<.84f)drawCollapsed(c,width);
        drawFooter(c,width,height,now);
        if(animating || (!tracks.isEmpty()&&checked[0]))postInvalidateDelayed(25);
    }
    private void drawPanel(Canvas c,RectF r){
        float rad=dp(26);
        paint.setShader(new LinearGradient(r.left,r.top,r.right,r.bottom,
            new int[]{0xBEE6F3FF,0x9B9FBEDC,0xB5BED9EA},null,Shader.TileMode.CLAMP));
        paint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(r,rad,rad,paint);paint.setShader(null);
        stroke(0xE6FFFFFF,dp(1.2f));c.drawRoundRect(r,rad,rad,paint);
    }
    private void drawTitle(Canvas c){
        writeText(c,"ZY辅助",panelLeft+panelW/2,panelTop+dp(34),dp(20),WHITE,true,true);
        writeText(c,"Z",panelLeft+dp(22),panelTop+dp(33),dp(22),WHITE,false,true);
        float y=panelTop+dp(27),right=panelLeft+panelW;
        float x1=right-dp(80),x2=right-dp(37);
        fill(0x35FFFFFF);c.drawCircle(x1,y,dp(16),paint);c.drawCircle(x2,y,dp(16),paint);
        stroke(WHITE,dp(2));c.drawLine(x1-dp(6),y,x1+dp(6),y,paint);
        c.drawLine(x2-dp(5),y-dp(5),x2+dp(5),y+dp(5),paint);
        c.drawLine(x2-dp(5),y+dp(5),x2+dp(5),y-dp(5),paint);
        collapseHit.set(x1-dp(20),y-dp(20),x1+dp(20),y+dp(20));
        closeHit.set(x2-dp(20),y-dp(20),x2+dp(20),y+dp(20));
        titleHit.set(panelLeft,panelTop,panelLeft+panelW*.20f,panelTop+dp(45));
    }
    private void drawSwitches(Canvas c){
        float pad=dp(15),gap=dp(8);
        float tileW=(panelW-pad*2-gap*4)/5;
        float startY=panelTop+dp(51);
        float tileH=panelH-dp(63);
        for(int i=0;i<5;i++){
            float l=panelLeft+pad+i*(tileW+gap);
            RectF tile=new RectF(l,startY,l+tileW,startY+tileH);
            switchHits[i].set(tile);
            round(c,tile,dp(16),0x29FFFFFF);
            stroke(0x66FFFFFF,dp(.7f));c.drawRoundRect(tile,dp(16),dp(16),paint);
            writeText(c,labels[i],tile.centerX(),startY+tileH*.43f,
                Math.min(dp(13),tileW*.18f),WHITE,true,true);
            float sw=Math.min(dp(53),tileW*.58f);
            float sh=Math.min(dp(23),tileH*.27f);
            RectF t=new RectF(tile.centerX()-sw/2,startY+tileH*.59f,
                tile.centerX()+sw/2,startY+tileH*.59f+sh);
            round(c,t,sh/2,0x78506375);
            round(c,t,sh/2,alpha(0xFF18D18A,eased[i]));
            stroke(0xAAFFFFFF,dp(.6f));c.drawRoundRect(t,sh/2,sh/2,paint);
            fill(WHITE);
            c.drawCircle(t.left+sh*.5f+(sw-sh)*eased[i],t.centerY(),sh*.43f,paint);
        }
    }
    private void drawCollapsed(Canvas c,float w){
        float pillW=dp(142),pillH=dp(44),left=w/2-pillW/2;
        restoreHit.set(left,dp(10),left+pillW,dp(10)+pillH);
        round(c,restoreHit,dp(26),0xC1B9D8E9);
        stroke(WHITE,dp(1));c.drawRoundRect(restoreHit,dp(26),dp(26),paint);
        writeText(c,"ZY辅助  ∨",w/2,restoreHit.centerY()+dp(6),dp(16),WHITE,true,true);
    }
    private String displayLabel(String s){
        switch(s.toLowerCase(Locale.US)){
            case "person":return "人";
            case "car":return "汽车";
            case "truck":return "卡车";
            case "bus":return "公交车";
            case "bicycle":return "自行车";
            case "motorcycle":return "摩托车";
            case "dog":return "狗";
            case "cat":return "猫";
            default:return s;
        }
    }
    private RectF toScreen(RectF src,float width,float height){
        float scale=Math.max(width/sourceWidth,height/sourceHeight);
        float offX=(width-sourceWidth*scale)/2,offY=(height-sourceHeight*scale)/2;
        return new RectF(src.left*scale+offX,src.top*scale+offY,
            src.right*scale+offX,src.bottom*scale+offY);
    }
    private void drawTargets(Canvas c,float w,float h,long now,float factor){
        if(eased[0]<.02f)return;
        for(Track t:tracks){
            t.current.left+=(t.target.left-t.current.left)*factor;
            t.current.top+=(t.target.top-t.current.top)*factor;
            t.current.right+=(t.target.right-t.current.right)*factor;
            t.current.bottom+=(t.target.bottom-t.current.bottom)*factor;
            RectF b=toScreen(t.current,w,h);
            if(b.bottom<0||b.top>h||b.right<0||b.left>w)continue;
            boolean locked=checked[1] && selectedId==t.id;
            int lineColor=locked?RED:MINT;
            if(eased[4]>.02f){
                float startY=panelTop+Math.max(panelH*expandedProgress,dp(44));
                stroke(alpha(0xFFFF627A,.8f*eased[4]),dp(1.7f));
                paint.setShadowLayer(dp(4),0,0,0xB0F43B5A);
                c.drawLine(w/2,startY,b.centerX(),b.top,paint);paint.clearShadowLayer();
            }
            stroke(alpha(lineColor,eased[0]),dp(2));
            c.drawRoundRect(b,dp(5),dp(5),paint);
            String tag=displayLabel(t.label)+"  "+Math.round(t.confidence*100)+"%";
            // No fabricated meter labels: distance must be calibrated separately.
            float textPx=dp(13);
            fill(WHITE);paint.setTextSize(textPx);
            float tagWidth=Math.max(dp(73),paint.measureText(tag)+dp(14));
            RectF bar=new RectF(b.left,Math.max(0,b.top-dp(29)),b.left+tagWidth,b.top-dp(3));
            round(c,bar,dp(7),locked?0xE8B04455:0xE91B4435);
            stroke(lineColor,dp(1));c.drawRoundRect(bar,dp(7),dp(7),paint);
            writeText(c,tag,bar.left+dp(7),bar.bottom-dp(7),textPx,WHITE,false,true);
        }
    }
    private void drawFooter(Canvas c,float w,float h,long now){
        RectF brand=new RectF(dp(14),h-dp(53),dp(163),h-dp(13));
        round(c,brand,dp(22),0x9A9DB5C6);
        stroke(0xAFFFFFFF,dp(.8f));c.drawRoundRect(brand,dp(22),dp(22),paint);
        writeText(c,"@ZYCMZC",brand.centerX(),brand.centerY()+dp(5),dp(14),WHITE,true,true);
        String status="AI识别  "+fps+" FPS  ·  "+inference+"ms";
        if(checked[3])status="距离需标定  ·  "+status;
        if(now-messageAt<3800 && message!=null)status=message;
        writeText(c,status,w/2,h-dp(21),dp(12),WHITE,true,false);
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=event.getX(),y=event.getY();
        if(expandedProgress<.6f){
            if(restoreHit.contains(x,y)){expanded=true;invalidate();return true;}
        } else {
            if(closeHit.contains(x,y)){listener.onClosePressed();return true;}
            if(collapseHit.contains(x,y)){expanded=false;invalidate();return true;}
            if(titleHit.contains(x,y)){listener.onHelpPressed();return true;}
            for(int i=0;i<switchHits.length;i++){
                if(switchHits[i].contains(x,y)){
                    checked[i]=!checked[i];
                    if(i==2)listener.onNightChanged(checked[i]);
                    if(i==3&&checked[3])setMessage("距离显示需要标定相机，目前不显示米数");
                    invalidate();return true;
                }
            }
        }
        // Tap a real detected box to lock it; no synthetic targets.
        if(checked[1]){
            for(Track t:tracks){
                if(toScreen(t.current,getWidth(),getHeight()).contains(x,y)){
                    selectedId=t.id;invalidate();return true;
                }
            }
        }
        return true;
    }
}

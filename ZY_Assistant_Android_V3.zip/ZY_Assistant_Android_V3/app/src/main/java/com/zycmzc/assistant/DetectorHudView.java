package com.zycmzc.assistant;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lightweight, hardware accelerated camera overlay; no artificial targets. */
public class DetectorHudView extends View {
    public interface Listener {
        void onRecognitionChanged(boolean value);
        void onPoseChanged(boolean value);
        void onNightChanged(boolean value);
        void onRotatePressed();
        void onClosePressed();
        void onHelpPressed();
    }
    public static class Found {
        public final RectF rect;
        public final String label;
        public final float confidence;
        public Found(RectF rect,String label,float confidence){
            this.rect=new RectF(rect);this.label=label;this.confidence=confidence;
        }
    }
    private static class Track {
        int id;
        String label;
        float confidence;
        RectF current,target;
        long seen;
        Track(int id,Found f,long now){
            this.id=id;label=f.label;confidence=f.confidence;
            current=new RectF(f.rect);target=new RectF(f.rect);seen=now;
        }
    }
    // Only structural joints to keep the overlay readable, not every possible body keypoint.
    private static final int[][] BONES={
        {11,12},{11,13},{13,15},{12,14},{14,16},
        {11,23},{12,24},{23,24},{23,25},{25,27},{24,26},{26,28}
    };
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Listener listener;
    private final List<Track> tracks=new ArrayList<>();
    private final RectF[] switches=new RectF[6];
    private final boolean[] checked={true,true,false,false,true,false};
    private final float[] eased={1,1,0,0,1,0};
    private final String[] labels={"识别","锁定","夜间","距离","射线","骨骼"};
    private final RectF collapse=new RectF(),restore=new RectF(),close=new RectF(),rotate=new RectF(),help=new RectF();
    private List<float[][]> poses=new ArrayList<>();
    private long posesAt,updateAt,drawAt,messageAt;
    private int nextId=1,selectedId=-1;
    private int sourceWidth=640,sourceHeight=360;
    private int aiRate,aiMs;
    private String message="连接相机中…";
    private boolean expanded=true;
    private float expandedAmount=1;
    private float left,top,panelW,panelH;
    private float density;
    private static final int WHITE=0xFFF8FCFF;
    private static final int GREEN=0xFF40E09B;
    private static final int RED=0xFFF47781;

    public DetectorHudView(Context context,Listener l){
        super(context);listener=l;
        density=context.getResources().getDisplayMetrics().density;
        for(int i=0;i<switches.length;i++)switches[i]=new RectF();
        // No SOFTWARE layer or per-target blur / shadow, because they cause jank.
        setLayerType(LAYER_TYPE_HARDWARE,null);
    }
    private float dp(float x){return x*density;}
    private void fill(int color){paint.reset();paint.setAntiAlias(true);paint.setColor(color);paint.setStyle(Paint.Style.FILL);}
    private void stroke(int color,float w){fill(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(w);}
    private void round(Canvas c,RectF r,float radius,int color){fill(color);c.drawRoundRect(r,radius,radius,paint);}
    private int transparency(int color,float opacity){return (color&0xFFFFFF)|(Math.round(Math.min(1,Math.max(0,opacity))*255)<<24);}
    private void text(Canvas c,String s,float x,float y,float sz,int color,boolean centered,boolean bold){
        fill(color);paint.setTextSize(sz);paint.setFakeBoldText(bold);
        paint.setTextAlign(centered?Paint.Align.CENTER:Paint.Align.LEFT);
        c.drawText(s,x,y,paint);
    }
    public void setMessage(String msg){message=msg;messageAt=SystemClock.elapsedRealtime();invalidate();}
    public void setPoseState(boolean on){checked[5]=on;invalidate();}
    public void setPoses(List<float[][]> items,int width,int height){
        poses=items;posesAt=SystemClock.elapsedRealtime();sourceWidth=width;sourceHeight=height;
        invalidate();
    }
    public void setDetections(List<Found> results,int width,int height,int rate,int milliseconds){
        sourceWidth=width;sourceHeight=height;aiRate=rate;aiMs=milliseconds;
        long now=SystemClock.elapsedRealtime();
        List<Track> free=new ArrayList<>(tracks);
        for(Found found:results){
            Track best=null;float score=.17f;
            for(Track t:free){
                if(!t.label.equals(found.label))continue;
                float candidate=iou(t.target,found.rect);
                if(candidate>score){score=candidate;best=t;}
            }
            if(best!=null){
                best.target.set(found.rect);best.seen=now;best.confidence=found.confidence;
                free.remove(best);
            } else tracks.add(new Track(nextId++,found,now));
        }
        tracks.removeIf(t->now-t.seen>650);
        if(checked[1] && !tracks.isEmpty() && !hasTrack(selectedId)){
            Track biggest=tracks.get(0);
            for(Track t:tracks)if(t.target.width()*t.target.height()>biggest.target.width()*biggest.target.height())biggest=t;
            selectedId=biggest.id;
        }
        updateAt=now;
        invalidate();
    }
    private boolean hasTrack(int id){for(Track t:tracks)if(t.id==id)return true;return false;}
    private float iou(RectF a,RectF b){
        float w=Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left));
        float h=Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
        float overlap=w*h, union=a.width()*a.height()+b.width()*b.height()-overlap;
        return union<=0?0:overlap/union;
    }
    private RectF toScreen(RectF b,int w,int h){
        float scale=Math.max((float)w/sourceWidth,(float)h/sourceHeight);
        float dx=(w-sourceWidth*scale)*.5f,dy=(h-sourceHeight*scale)*.5f;
        return new RectF(dx+b.left*scale,dy+b.top*scale,dx+b.right*scale,dy+b.bottom*scale);
    }
    private float screenX(float norm,float w,float scale,float xOff){return xOff+norm*sourceWidth*scale;}
    private float screenY(float norm,float scale,float yOff){return yOff+norm*sourceHeight*scale;}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(),h=getHeight();if(w<=0||h<=0)return;
        long now=SystemClock.elapsedRealtime();
        float dt=drawAt==0?.016f:Math.min(.06f,(now-drawAt)/1000f);
        drawAt=now;
        float delta=1-(float)Math.exp(-13f*dt);
        boolean animate=false;
        float goal=expanded?1:0;
        expandedAmount+=(goal-expandedAmount)*delta;
        if(Math.abs(expandedAmount-goal)>.005f)animate=true;
        for(int i=0;i<checked.length;i++){
            float target=checked[i]?1:0;
            eased[i]+=(target-eased[i])*delta;
            if(Math.abs(eased[i]-target)>.005f)animate=true;
        }
        top=dp(8);
        boolean portrait=h>w;
        panelW=Math.min(w-dp(16),dp(860));
        panelH=portrait?Math.min(h*.40f,dp(258)):Math.min(h*.32f,dp(147));
        left=(w-panelW)*.5f;
        if(checked[0])animate|=drawTargets(c,w,h,delta);
        if(checked[5] && now-posesAt<1500)drawBones(c,w,h);
        if(expandedAmount>.05){
            RectF panel=new RectF(left,top,left+panelW,top+panelH*expandedAmount);
            glass(c,panel);
            if(expandedAmount>.78f){drawHeader(c,w,h,portrait);drawSwitches(c,portrait);}
        }
        if(expandedAmount<.86f)drawCollapsed(c,w);
        drawFooter(c,w,h,now);
        if(animate)postInvalidateOnAnimation();
    }
    private void glass(Canvas c,RectF r){
        float rad=dp(19);
        fill(WHITE);
        paint.setShader(new LinearGradient(r.left,r.top,r.right,r.bottom,
            new int[]{0xD5EFF5FA,0xBEB5C5D4,0xD2D8E6EF},null,Shader.TileMode.CLAMP));
        c.drawRoundRect(r,rad,rad,paint);paint.setShader(null);
        stroke(0xCCFFFFFF,dp(1));c.drawRoundRect(r,rad,rad,paint);
    }
    private void drawHeader(Canvas c,float w,float h,boolean portrait){
        float cy=top+dp(24);
        text(c,"ZY辅助",left+dp(21),cy+dp(6),dp(16),0xFF263A4E,false,true);
        float right=left+panelW;
        rotate.set(right-dp(112),cy-dp(17),right-dp(78),cy+dp(17));
        collapse.set(right-dp(74),cy-dp(17),right-dp(40),cy+dp(17));
        close.set(right-dp(36),cy-dp(17),right-dp(5),cy+dp(17));
        help.set(left,top,left+dp(98),top+dp(48));
        drawIcon(c,rotate,"↻");drawIcon(c,collapse,"−");drawIcon(c,close,"×");
    }
    private void drawIcon(Canvas c,RectF hit,String label){
        round(c,hit,dp(16),0x64FFFFFF);
        text(c,label,hit.centerX(),hit.centerY()+dp(6),dp(20),0xFF314052,true,true);
    }
    private void drawSwitches(Canvas c,boolean portrait){
        int cols=portrait?3:6;
        float pad=dp(10), gap=dp(6);
        int rows=portrait?2:1;
        float xSize=(panelW-pad*2-gap*(cols-1))/cols;
        float yStart=top+dp(46);
        float ySize=(panelH-dp(52)-gap*(rows-1))/rows;
        for(int i=0;i<6;i++){
            int col=i%cols,row=i/cols;
            float l=left+pad+col*(xSize+gap),t=yStart+row*(ySize+gap);
            RectF tile=new RectF(l,t,l+xSize,t+ySize);
            switches[i].set(tile);
            round(c,tile,dp(12),0x38FFFFFF);
            text(c,labels[i],tile.centerX(),t+ySize*.40f,
                Math.min(dp(12),xSize*.21f),0xFF263A4E,true,true);
            float width=Math.min(dp(46),xSize*.58f);
            float height=Math.min(dp(23),Math.max(dp(12),ySize*.28f));
            RectF toggle=new RectF(tile.centerX()-width*.5f,t+ySize*.62f,
                tile.centerX()+width*.5f,t+ySize*.62f+height);
            round(c,toggle,height/2,0x8F6F879B);
            round(c,toggle,height/2,transparency(GREEN,eased[i]));
            fill(Color.WHITE);
            c.drawCircle(toggle.left+height*.5f+(width-height)*eased[i],toggle.centerY(),height*.40f,paint);
        }
    }
    private void drawCollapsed(Canvas c,float w){
        float width=Math.min(dp(146),w*.50f),h=dp(42);
        restore.set(w/2-width/2,top,w/2+width/2,top+h);
        round(c,restore,dp(21),0xCCCFDEE9);
        text(c,"ZY辅助  ▾",restore.centerX(),restore.centerY()+dp(6),dp(14),0xFF2B4056,true,true);
    }
    private boolean drawTargets(Canvas c,int w,int h,float step){
        boolean moving=false;
        for(Track track:tracks){
            float movement=Math.abs(track.current.left-track.target.left)
                +Math.abs(track.current.top-track.target.top)
                +Math.abs(track.current.right-track.target.right)
                +Math.abs(track.current.bottom-track.target.bottom);
            if(movement>1.5f){moving=true;
                track.current.left+=(track.target.left-track.current.left)*step;
                track.current.top+=(track.target.top-track.current.top)*step;
                track.current.right+=(track.target.right-track.current.right)*step;
                track.current.bottom+=(track.target.bottom-track.current.bottom)*step;
            } else track.current.set(track.target);
            RectF b=toScreen(track.current,w,h);
            if(b.right<0||b.left>w||b.bottom<0||b.top>h)continue;
            boolean locked=checked[1] && track.id==selectedId;
            stroke(locked?RED:GREEN,dp(locked?2f:1.3f));
            c.drawRoundRect(b,dp(4),dp(4),paint);
            // One beam for the selected track, never a mass of beams.
            if(locked && checked[4]){
                stroke(0xDDFF627A,dp(1.6f));
                c.drawLine(w/2,top+(expanded?panelH:dp(42)),b.centerX(),b.top,paint);
            }
            // Only locked target gets a label; all other outlines are quiet.
            if(locked){
                String title=label(track.label)+" "+Math.round(track.confidence*100)+"%";
                text(c,title,Math.max(dp(6),b.left),Math.max(dp(16),b.top-dp(5)),dp(12),Color.WHITE,false,true);
            }
        }
        return moving;
    }
    private String label(String s){
        if(s==null)return "目标";
        switch(s.toLowerCase(Locale.US)){
            case "person":return "人";
            case "car":return "汽车";
            case "truck":return "卡车";
            case "bus":return "公交";
            case "motorcycle":return "摩托";
            case "bicycle":return "自行车";
            default:return s;
        }
    }
    private void drawBones(Canvas c,int w,int h){
        float scale=Math.max((float)w/sourceWidth,(float)h/sourceHeight);
        float dx=(w-sourceWidth*scale)*.5f,dy=(h-sourceHeight*scale)*.5f;
        stroke(0xDE5AE9D3,dp(1.8f));
        for(float[][] person:poses){
            for(int[] edge:BONES){
                int a=edge[0],b=edge[1];
                if(a>=person.length||b>=person.length)continue;
                float[] p=person[a],q=person[b];
                if(p[2]<.42f||q[2]<.42f)continue;
                c.drawLine(screenX(p[0],w,scale,dx),screenY(p[1],scale,dy),
                    screenX(q[0],w,scale,dx),screenY(q[1],scale,dy),paint);
            }
        }
    }
    private void drawFooter(Canvas c,int w,int h,long now){
        text(c,"@ZYCMZC",dp(12),h-dp(16),dp(12),Color.WHITE,false,true);
        String status="AI "+aiRate+"次/秒 · "+aiMs+"ms";
        if(checked[5])status+=" · 骨骼";
        if(checked[3])status+=" · 距离未标定";
        if(now-messageAt<2500)status=message;
        // Hide footer stats in very narrow portrait rather than cover the image.
        if(w>dp(310))text(c,status,w*.56f,h-dp(16),dp(10),Color.WHITE,true,false);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX(),y=e.getY();
        if(expandedAmount<.55f){
            if(restore.contains(x,y)){expanded=true;invalidate();}
            return true;
        }
        if(close.contains(x,y)){listener.onClosePressed();return true;}
        if(collapse.contains(x,y)){expanded=false;invalidate();return true;}
        if(rotate.contains(x,y)){listener.onRotatePressed();return true;}
        if(help.contains(x,y)){listener.onHelpPressed();return true;}
        for(int i=0;i<switches.length;i++){
            if(switches[i].contains(x,y)){
                checked[i]=!checked[i];
                if(i==0)listener.onRecognitionChanged(checked[i]);
                if(i==2)listener.onNightChanged(checked[i]);
                if(i==3&&checked[i])setMessage("距离需要标定，暂不显示米数");
                if(i==5)listener.onPoseChanged(checked[i]);
                invalidate();return true;
            }
        }
        if(checked[1])for(Track t:tracks){
            if(toScreen(t.current,getWidth(),getHeight()).contains(x,y)){
                selectedId=t.id;invalidate();return true;
            }
        }
        return true;
    }
}

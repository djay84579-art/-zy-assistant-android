package com.zycmzc.assistant;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Outline;

public class SplashActivity extends Activity {
    private boolean entering = false;
    private ValueAnimator pulse;
    private int dp(float v) { return Math.round(getResources().getDisplayMetrics().density * v); }
    private GradientDrawable bg(int color, int radius, int strokeColor, float strokeWidth) {
        GradientDrawable b = new GradientDrawable();
        b.setColor(color); b.setCornerRadius(dp(radius));
        if (strokeWidth>0) b.setStroke(dp(strokeWidth),strokeColor);
        return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        LinearLayout centered = new LinearLayout(this);
        centered.setOrientation(LinearLayout.VERTICAL);
        centered.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams wrap = new FrameLayout.LayoutParams(-1,-2, Gravity.CENTER);
        root.addView(centered,wrap);

        FrameLayout badge = new FrameLayout(this);
        GradientDrawable shell = bg(0xFF10131B,30,0xFF83B9FF,2);
        badge.setBackground(shell);
        badge.setElevation(dp(13));
        centered.addView(badge,new LinearLayout.LayoutParams(dp(168),dp(168)));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.zy_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(-1,-1);
        iconLp.setMargins(dp(3),dp(3),dp(3),dp(3));
        badge.addView(icon, iconLp);
        icon.setClipToOutline(true);
        icon.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0,0,view.getWidth(),view.getHeight(),dp(27));
            }
        });

        TextView title = new TextView(this);
        title.setText("ZY辅助");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setTextSize(33);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1,dp(70));
        titleLp.topMargin=dp(25);
        centered.addView(title,titleLp);

        TextView start = new TextView(this);
        start.setText("开始使用    ›");
        start.setGravity(Gravity.CENTER);
        start.setTextColor(Color.WHITE);
        start.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        start.setTextSize(19);
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFF17366C,0xFF3973CB,0xFF183565});
        gradient.setCornerRadius(dp(38)); gradient.setStroke(dp(1.5f),0xFF9EC5FF);
        start.setBackground(gradient);
        start.setElevation(dp(10));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(dp(250),dp(64));
        buttonLp.topMargin=dp(90);
        centered.addView(start,buttonLp);

        badge.setAlpha(0f); badge.setScaleX(.76f);badge.setScaleY(.76f); badge.setTranslationY(dp(24));
        title.setAlpha(0f);title.setTranslationY(dp(20));
        start.setAlpha(0f);start.setTranslationY(dp(30));
        DecelerateInterpolator ease = new DecelerateInterpolator(2f);
        badge.animate().alpha(1).translationY(0).scaleX(1).scaleY(1)
            .setDuration(800).setInterpolator(ease).start();
        title.animate().alpha(1).translationY(0).setStartDelay(320)
            .setDuration(650).setInterpolator(ease).start();
        start.animate().alpha(1).translationY(0).setStartDelay(580)
            .setDuration(720).setInterpolator(ease).start();
        pulse=ValueAnimator.ofFloat(1f,1.035f,1f);
        pulse.setDuration(2300);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.addUpdateListener(anim->{
            if(entering) return;
            float f=(Float)anim.getAnimatedValue();
            start.setScaleX(f);start.setScaleY(f);
        });
        pulse.start();
        start.setOnClickListener(v->{
            if(entering)return;
            entering=true;
            if(pulse!=null) pulse.cancel();
            start.animate().scaleX(.94f).scaleY(.94f).alpha(0f).setDuration(290).start();
            badge.animate().alpha(0f).scaleX(1.10f).scaleY(1.10f).setDuration(440).start();
            title.animate().alpha(0f).translationY(-dp(16)).setDuration(390).start();
            root.postDelayed(()->{
                startActivity(new Intent(this,CameraActivity.class));
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                finish();
            },455);
        });
    }
    @Override protected void onDestroy() {
        if(pulse!=null) pulse.cancel();
        super.onDestroy();
    }
}

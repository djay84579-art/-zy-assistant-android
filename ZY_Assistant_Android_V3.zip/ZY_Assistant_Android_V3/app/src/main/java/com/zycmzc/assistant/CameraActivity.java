package com.zycmzc.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult;
import com.google.mediapipe.tasks.components.containers.Detection;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android CameraX preview stays fluid; expensive AI is decimated on a worker. */
public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int CAMERA_REQUEST = 201;
    private PreviewView preview;
    private DetectorHudView hud;
    private StartupCodeView startupCode;
    private volatile float scoreThreshold=.40f;
    private ExecutorService worker;
    private ObjectDetector objectDetector;
    private PoseLandmarker poseLandmarker;
    private Camera camera;
    private ProcessCameraProvider cameraProvider;
    private volatile boolean destroyed;
    private volatile boolean objectOn = true;
    private volatile boolean poseOn = false; // opt in for smoothest default experience
    private long lastObjectTime, lastPoseTime;
    private int adaptiveObjectIntervalMs = 170;
    private int inferenceMs, detectionCount, inferenceRate;
    private long fpsWindow;
    private byte[] pixels;
    private ByteBuffer pixelsBuffer;
    private Bitmap rawBitmap, rotatedBitmap;
    private Canvas rotatedCanvas;
    private final Matrix rotationMatrix = new Matrix();
    private final Paint conversionPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private int lastRotation = -1;
    private boolean requestedPortrait;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestedPortrait = getSharedPreferences("zy", MODE_PRIVATE).getBoolean("portrait",false);
        setRequestedOrientation(requestedPortrait ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        // PERFORMANCE uses SurfaceView on supported devices; avoids extra TextureView copies.
        preview.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        hud = new DetectorHudView(this,this);
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        startupCode = new StartupCodeView(this);
        root.addView(startupCode,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        worker = Executors.newSingleThreadExecutor();
        hud.setMessage("初始化离线 AI …");
        worker.execute(this::loadDetector);
        if (checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
            preview.postDelayed(this::startCamera,220);
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
    }

    private void loadDetector() {
        try {
            ObjectDetector.ObjectDetectorOptions opts = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("efficientdet_lite0.tflite").build())
                .setRunningMode(RunningMode.IMAGE).setScoreThreshold(.25f)
                // No setMaxResults: all available model results, no arbitrary 2/4/12 cap.
                .build();
            ObjectDetector d = ObjectDetector.createFromOptions(this,opts);
            objectDetector=d;
            runOnUiThread(()->{if(!destroyed){hud.setMessage("AI已就绪"); startupCode.setAiState("READY");}});
        } catch(Exception e) {
            runOnUiThread(()->{if(!destroyed){hud.setMessage("AI初始化失败: "+e.getMessage()); startupCode.setAiState("ERROR");}});
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==CAMERA_REQUEST) {
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else {hud.setMessage("请允许相机权限才能使用");startupCode.setCameraState("DENIED");}
        }
    }

    private void startCamera() {
        if(destroyed || checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(destroyed)return;
            try {
                cameraProvider=future.get();
                int rotation=preview.getDisplay()==null?getWindowManager().getDefaultDisplay().getRotation():preview.getDisplay().getRotation();
                Preview p=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .setTargetRotation(rotation).build();
                p.setSurfaceProvider(preview.getSurfaceProvider());
                ImageAnalysis a=new ImageAnalysis.Builder()
                    .setTargetRotation(rotation)
                    // Analyze a small frame; leave the actual camera preview full quality.
                    .setTargetResolution(new Size(640,360))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build();
                a.setAnalyzer(worker,this::analyzeFrame);
                cameraProvider.unbindAll();
                camera=cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,a);
                hud.setMessage("相机已连接 · 后台 AI 分析");
                startupCode.setCameraState("READY");
            } catch(Exception e) {hud.setMessage("摄像头启动失败: "+e.getMessage());startupCode.setCameraState("ERROR");}
        },getMainExecutor());
    }

    private void analyzeFrame(ImageProxy frame) {
        try {
            long now=SystemClock.elapsedRealtime();
            boolean detect = objectOn && objectDetector!=null
                && now-lastObjectTime >= adaptiveObjectIntervalMs;
            boolean pose = poseOn && now-lastPoseTime>=850;
            if(destroyed || (!detect && !pose))return;
            if(pose && poseLandmarker==null) {
                // Lazy load: turn off skeleton to avoid holding a second large model by default.
                try {
                    PoseLandmarker.PoseLandmarkerOptions opts=PoseLandmarker.PoseLandmarkerOptions.builder()
                        .setBaseOptions(BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build())
                        .setRunningMode(RunningMode.IMAGE).setNumPoses(6)
                        .setMinPoseDetectionConfidence(.48f).build();
                    poseLandmarker=PoseLandmarker.createFromOptions(this,opts);
                    runOnUiThread(()->{if(!destroyed)hud.setMessage("多人骨骼模型已加载（最多6姿态）");});
                } catch(Exception e) {
                    poseOn=false;
                    runOnUiThread(()->{if(!destroyed){hud.setPoseState(false);hud.setMessage("骨骼加载失败: "+e.getMessage());}});
                    pose=false;
                }
            }
            if(!detect && !pose)return;
            Bitmap bitmap=prepareBitmap(frame);
            MPImage image=new BitmapImageBuilder(bitmap).build();
            int imageWidth=bitmap.getWidth(),imageHeight=bitmap.getHeight();
            if(detect){
                lastObjectTime=now;
                long start=SystemClock.elapsedRealtime();
                ObjectDetectorResult result=objectDetector.detect(image);
                inferenceMs=(int)(SystemClock.elapsedRealtime()-start);
                // Automatically back off when the phone is busy, while camera preview stays fluid.
                adaptiveObjectIntervalMs=Math.max(130,Math.min(520,inferenceMs*2+70));
                List<DetectorHudView.Found> detections=new ArrayList<>();
                for(Detection d:result.detections()){
                    if(d.categories().isEmpty())continue;
                    Category category=d.categories().get(0);
                    if(category.score()<scoreThreshold)continue;
                    detections.add(new DetectorHudView.Found(new RectF(d.boundingBox()),
                        category.categoryName()==null?"目标":category.categoryName(),category.score()));
                }
                detectionCount++;
                if(fpsWindow==0)fpsWindow=now;
                if(now-fpsWindow>=1000){
                    inferenceRate=(int)(detectionCount*1000f/(now-fpsWindow));
                    detectionCount=0;fpsWindow=now;
                }
                int rate=inferenceRate,time=inferenceMs;
                runOnUiThread(()->{if(!destroyed)hud.setDetections(detections,imageWidth,imageHeight,rate,time);});
            }
            if(pose && poseLandmarker!=null){
                lastPoseTime=now;
                PoseLandmarkerResult poses=poseLandmarker.detect(image);
                List<float[][]> points=new ArrayList<>();
                for(List<NormalizedLandmark> landmarks:poses.landmarks()){
                    float[][] one=new float[landmarks.size()][3];
                    for(int i=0;i<landmarks.size();i++){
                        NormalizedLandmark pt=landmarks.get(i);
                        one[i][0]=pt.x();one[i][1]=pt.y();
                        one[i][2]=pt.visibility().orElse(1f);
                    }
                    points.add(one);
                }
                runOnUiThread(()->{if(!destroyed)hud.setPoses(points,imageWidth,imageHeight);});
            }
        } catch(Exception e){
            runOnUiThread(()->{if(!destroyed)hud.setMessage("AI帧处理失败: "+e.getMessage());});
        } finally {frame.close();}
    }

    /** Reuses pixel byte buffer, raw bitmap and rotation canvas instead of allocating MBs each frame. */
    private Bitmap prepareBitmap(ImageProxy frame) {
        int w=frame.getWidth(),h=frame.getHeight();
        int bytes=w*h*4;
        if(pixels==null || pixels.length!=bytes){
            pixels=new byte[bytes]; pixelsBuffer=ByteBuffer.wrap(pixels);
            if(rawBitmap!=null)rawBitmap.recycle();
            rawBitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        }
        ImageProxy.PlaneProxy plane=frame.getPlanes()[0];
        ByteBuffer input=plane.getBuffer();
        int stride=plane.getRowStride(),rowBytes=w*4;
        if(stride==rowBytes){input.rewind();input.get(pixels,0,bytes);}
        else for(int y=0;y<h;y++){
            input.position(y*stride);
            input.get(pixels,y*rowBytes,rowBytes);
        }
        pixelsBuffer.rewind();rawBitmap.copyPixelsFromBuffer(pixelsBuffer);
        int rotation=frame.getImageInfo().getRotationDegrees();
        if(rotation==0)return rawBitmap;
        int ow=(rotation==90||rotation==270)?h:w;
        int oh=(rotation==90||rotation==270)?w:h;
        if(rotatedBitmap==null || rotatedBitmap.getWidth()!=ow || rotatedBitmap.getHeight()!=oh){
            if(rotatedBitmap!=null)rotatedBitmap.recycle();
            rotatedBitmap=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            rotatedCanvas=new Canvas(rotatedBitmap);
        }
        rotationMatrix.reset();
        rotationMatrix.setRotate(rotation);
        if(rotation==90)rotationMatrix.postTranslate(h,0);
        else if(rotation==180)rotationMatrix.postTranslate(w,h);
        else if(rotation==270)rotationMatrix.postTranslate(0,w);
        rotatedCanvas.drawColor(Color.TRANSPARENT,android.graphics.PorterDuff.Mode.CLEAR);
        rotatedCanvas.drawBitmap(rawBitmap,rotationMatrix,conversionPaint);
        lastRotation=rotation;
        return rotatedBitmap;
    }

    @Override public void onRecognitionChanged(boolean enable){ objectOn=enable;hud.setMessage(enable?"识别已开启":"已暂停识别，节省性能"); }
    @Override public void onSensitivityChanged(float threshold){scoreThreshold=threshold;}
    @Override public void onPoseChanged(boolean enable){poseOn=enable;hud.setMessage(enable?"骨骼已开启（会增加耗电）":"骨骼已关闭，流畅优先");}
    @Override public void onNightChanged(boolean enable){
        if(camera==null)return;
        try {
            androidx.camera.core.ExposureState exp=camera.getCameraInfo().getExposureState();
            if(exp.isExposureCompensationSupported()){
                int upper=exp.getExposureCompensationRange().getUpper();
                camera.getCameraControl().setExposureCompensationIndex(enable?Math.min(2,upper):0);
            } else hud.setMessage("本机不支持曝光补偿");
        } catch(Exception e){hud.setMessage("夜间增强不可用");}
    }
    @Override public void onRotatePressed(){
        requestedPortrait=!requestedPortrait;
        getSharedPreferences("zy",MODE_PRIVATE).edit().putBoolean("portrait",requestedPortrait).apply();
        setRequestedOrientation(requestedPortrait?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);
        preview.postDelayed(this::startCamera,160);
    }
    @Override public void onClosePressed(){finish();}
    @Override public void onHelpPressed(){
        new AlertDialog.Builder(this).setTitle("ZY辅助 · V0.6")
            .setMessage("黑色胶囊：点击展开深色控制面板。\n\n"+
                "物品绘制默认关闭，与人物方框、骨骼、射线独立控制。\n\n"+
                "骨骼：MediaPipe 多人姿态模型，最多6个人，默认关闭以优先保持流畅。\n\n"+
                "横竖屏：点击顶部 ↻ 按钮切换。\n\n"+
                "AI每秒处理次数≠手机摄像头预览帧率；视频预览不会被AI处理频率限制。\n\n"+
                "距离需要相机标定，尚不提供米数。底部频道：@ZYCMZC")
            .setPositiveButton("了解",null).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        if(cameraProvider!=null)cameraProvider.unbindAll();
        if(worker!=null){
            worker.execute(()->{
                if(objectDetector!=null)objectDetector.close();
                if(poseLandmarker!=null)poseLandmarker.close();
                if(rawBitmap!=null)rawBitmap.recycle();
                if(rotatedBitmap!=null)rotatedBitmap.recycle();
            });
            worker.shutdown();
        }
        super.onDestroy();
    }
}

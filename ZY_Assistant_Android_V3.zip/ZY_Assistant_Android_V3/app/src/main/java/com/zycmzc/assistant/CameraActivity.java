package com.zycmzc.assistant;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.app.AlertDialog;
import android.graphics.Color;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.tasks.components.containers.Detection;
import com.google.mediapipe.tasks.components.containers.Category;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int REQ_CAMERA = 201;
    private PreviewView preview;
    private DetectorHudView hud;
    private ExecutorService executor;
    private ObjectDetector detector;
    private Camera camera;
    private long lastAnalyzeMs;
    private int fpsCount, fpsValue;
    private long fpsStartMs;
    private boolean destroyed;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        preview=new PreviewView(this);
        preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        frame.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        hud=new DetectorHudView(this,this);
        frame.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        setContentView(frame);
        executor=Executors.newSingleThreadExecutor();
        hud.setMessage("正在加载离线 AI 模型…");
        executor.execute(()->{
            try {
                BaseOptions base=BaseOptions.builder().setModelAssetPath("efficientdet_lite0.tflite").build();
                ObjectDetector.ObjectDetectorOptions options=ObjectDetector.ObjectDetectorOptions.builder()
                    .setBaseOptions(base).setRunningMode(RunningMode.IMAGE)
                    .setScoreThreshold(.37f).setMaxResults(12).build();
                detector=ObjectDetector.createFromOptions(this,options);
                runOnUiThread(()->{ if(!destroyed) hud.setMessage("AI已加载 · 等待检测目标"); });
            } catch(Exception e) {
                runOnUiThread(()->{
                    if(!destroyed) {
                        hud.setMessage("AI模型加载失败");
                        Toast.makeText(this,"AI 模型加载失败: "+e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==REQ_CAMERA) {
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else hud.setMessage("未获得相机权限，请在系统设置中允许相机访问");
        }
    }
    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            try {
                ProcessCameraProvider provider=future.get();
                int rotation=preview.getDisplay()!=null?preview.getDisplay().getRotation():android.view.Surface.ROTATION_90;
                Preview p=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .setTargetRotation(rotation).build();
                p.setSurfaceProvider(preview.getSurfaceProvider());
                ImageAnalysis analysis=new ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .setTargetRotation(rotation)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build();
                analysis.setAnalyzer(executor,this::analyzeFrame);
                provider.unbindAll();
                camera=provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                if(hud!=null) hud.setMessage("相机已连接 · 正在检测");
            } catch(Exception e) {
                hud.setMessage("无法启动原生后置相机: "+e.getMessage());
            }
        },getMainExecutor());
    }
    private void analyzeFrame(ImageProxy proxy) {
        try {
            long now=SystemClock.elapsedRealtime();
            if(detector==null || now-lastAnalyzeMs<125 || destroyed) return;
            lastAnalyzeMs=now;
            final Bitmap bitmap=makeBitmap(proxy);
            MPImage input=new BitmapImageBuilder(bitmap).build();
            long started=SystemClock.elapsedRealtime();
            ObjectDetectorResult results=detector.detect(input);
            int inferenceMs=(int)(SystemClock.elapsedRealtime()-started);
            List<DetectorHudView.Found> detections=new ArrayList<>();
            for(Detection d:results.detections()) {
                if(d.categories().isEmpty())continue;
                Category cat=d.categories().get(0);
                String name=cat.categoryName();
                if(name==null || name.isEmpty())name="目标";
                detections.add(new DetectorHudView.Found(
                    new RectF(d.boundingBox()),name,cat.score()));
            }
            fpsCount++;
            if(fpsStartMs==0)fpsStartMs=now;
            if(now-fpsStartMs>1000) {
                fpsValue=(int)(fpsCount*1000f/(now-fpsStartMs));
                fpsStartMs=now;fpsCount=0;
            }
            int bw=bitmap.getWidth(),bh=bitmap.getHeight(),fps=fpsValue;
            runOnUiThread(()->{
                if(!destroyed)hud.setDetections(detections,bw,bh,fps,inferenceMs);
            });
            bitmap.recycle();
        } catch (Exception e) {
            runOnUiThread(()->{ if(!destroyed)hud.setMessage("AI识别失败: "+e.getMessage()); });
        } finally {
            proxy.close();
        }
    }
    // CameraX RGBA_8888 is a single plane. Respect rowStride; rotating the
    // analysis bitmap aligns inference coordinates with landscape PreviewView.
    private Bitmap makeBitmap(ImageProxy proxy) {
        final int width=proxy.getWidth(),height=proxy.getHeight();
        ImageProxy.PlaneProxy plane=proxy.getPlanes()[0];
        ByteBuffer buffer=plane.getBuffer();
        buffer.rewind();
        int rowStride=plane.getRowStride();
        int pix=width*4;
        byte[] data=new byte[width*height*4];
        if(rowStride==pix) buffer.get(data,0,data.length);
        else {
            for(int row=0;row<height;row++) {
                buffer.position(row*rowStride);
                buffer.get(data,row*pix,pix);
            }
        }
        Bitmap raw=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        raw.copyPixelsFromBuffer(ByteBuffer.wrap(data));
        int rotation=proxy.getImageInfo().getRotationDegrees();
        if(rotation==0)return raw;
        Matrix matrix=new Matrix();matrix.postRotate(rotation);
        Bitmap rotated=Bitmap.createBitmap(raw,0,0,width,height,matrix,true);
        raw.recycle();
        return rotated;
    }
    @Override public void onNightChanged(boolean enabled) {
        if(camera==null)return;
        try {
            androidx.camera.core.ExposureState state=camera.getCameraInfo().getExposureState();
            if(state.isExposureCompensationSupported()) {
                int idx=enabled?Math.min(2,state.getExposureCompensationRange().getUpper()):0;
                camera.getCameraControl().setExposureCompensationIndex(idx);
                if(enabled)hud.setMessage("已尝试提高相机曝光（不是真正红外夜视）");
            } else hud.setMessage("当前设备不支持曝光补偿");
        } catch(Exception e) { hud.setMessage("夜间增强暂不可用"); }
    }
    @Override public void onClosePressed() { finish(); }
    @Override public void onHelpPressed() {
        new AlertDialog.Builder(this).setTitle("ZY辅助 · V0.4 真实 AI 版")
            .setMessage("本版本使用手机后置摄像头和离线 EfficientDet-Lite0 模型进行真实物体识别。\n\n"+
                "绿色检测框：模型识别结果；锁定：视觉标记与追踪，不控制任何设备；射线：从上方连接检测目标。\n\n"+
                "距离：未进行相机标定，因此不会显示虚假的米数。\n"+
                "夜间增强：尝试调整相机曝光，效果依设备而定。\n"+
                "底部频道：@ZYCMZC")
            .setPositiveButton("知道了",null).show();
    }
    @Override protected void onDestroy() {
        destroyed=true;
        if(executor!=null) {
            executor.execute(()->{ if(detector!=null){detector.close();detector=null;} });
            executor.shutdown();
        }
        super.onDestroy();
    }
}

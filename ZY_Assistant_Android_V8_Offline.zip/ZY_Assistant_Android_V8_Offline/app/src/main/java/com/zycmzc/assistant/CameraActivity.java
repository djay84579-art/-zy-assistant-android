package com.zycmzc.assistant;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Size;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.activity.ComponentActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectorResult;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V8: fully offline person inference. Camera remains live even when local AI fails. */
public class CameraActivity extends ComponentActivity implements DetectorHudView.Listener {
    private static final int CAMERA_REQUEST = 201;
    // Fast preset: 640x360 -> EfficientDet-Lite0 int8 (320x320) on CPU.
    // Input can be lower than preview; model results are scaled to source pixels.
    private static final Size[] ANALYSIS_RESOLUTIONS = {
        new Size(640,360), new Size(480,270), new Size(320,180)
    };
    private static final long TARGET_INTERVAL_MS = 125L; // up to ~8 analyses/s on fast phones
    private volatile float scoreThreshold = .25f;
    private volatile boolean objectOn = false;
    private volatile boolean destroyed = false;
    private boolean safeMode;
    private boolean requestedPortrait;
    private volatile boolean startupValidated = false;
    private PreviewView preview;
    private DetectorHudView hud;
    private StartupCodeView startupCode;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ExecutorService analysisWorker;
    private ObjectDetector detector; // OWNED by analysisWorker only; CPU delegate, no GPU/native concurrency.
    private final RegionEvidence evidence = new RegionEvidence();
    private long lastAnalysis;
    private int consecutiveErrors;
    private byte[] pixels;
    private ByteBuffer pixelsBuffer;
    private Bitmap rawBitmap, rotatedBitmap;
    private Canvas rotatedCanvas;
    private final Matrix rotationMatrix = new Matrix();
    private final Paint conversionPaint = new Paint(Paint.FILTER_BITMAP_FLAG);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        CrashGuard.install(this);
        CrashGuard.stage(this,"V8: 初始化离线摄像头");
        safeMode = getIntent().getBooleanExtra("zy_safe_mode", false);
        requestedPortrait = getSharedPreferences("zy",MODE_PRIVATE).getBoolean("portrait",false);
        setRequestedOrientation(requestedPortrait ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        preview.setImplementationMode(safeMode ? PreviewView.ImplementationMode.COMPATIBLE
            : PreviewView.ImplementationMode.PERFORMANCE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        hud = new DetectorHudView(this,this);
        hud.setRecognitionState(false);
        root.addView(hud,new FrameLayout.LayoutParams(-1,-1));
        startupCode = new StartupCodeView(this);
        root.addView(startupCode,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        analysisWorker=Executors.newSingleThreadExecutor(r -> {
            Thread thread=new Thread(r,"ZY-Offline-AI");
            thread.setPriority(Thread.NORM_PRIORITY-1); // Leave headroom for camera/UI.
            return thread;
        });
        hud.setMessage("V8 纯离线 · 点击 AI识别 开启");
        startupCode.setAiState("LOCAL/OFF");
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
            preview.postDelayed(this::startCamera,180);
        else requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==CAMERA_REQUEST){
            if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startCamera();
            else{hud.setMessage("需要相机权限");startupCode.setCameraState("DENIED");}
        }
    }

    private void startCamera(){
        if(destroyed || checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        CrashGuard.stage(this,"V8: 创建 CameraProvider");
        ListenableFuture<ProcessCameraProvider> future;
        try {future=ProcessCameraProvider.getInstance(this);}
        catch(Throwable error){cameraError(error);return;}
        future.addListener(()->{
            if(destroyed)return;
            try{
                cameraProvider=future.get();
                int rotation=preview.getDisplay()==null
                    ? getWindowManager().getDefaultDisplay().getRotation()
                    : preview.getDisplay().getRotation();
                Exception lastError=null;
                Size[] sizes=safeMode ? new Size[]{new Size(480,270),new Size(320,180)}
                    : ANALYSIS_RESOLUTIONS;
                for(Size requested:sizes){
                    try{
                        Size oriented=(rotation==0||rotation==2)
                            ? new Size(requested.getHeight(),requested.getWidth()) : requested;
                        Preview p = new Preview.Builder()
                            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                            .setTargetRotation(rotation).build();
                        p.setSurfaceProvider(preview.getSurfaceProvider());
                        ImageAnalysis analysis = new ImageAnalysis.Builder()
                            .setTargetRotation(rotation)
                            .setTargetResolution(oriented)
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                            .build();
                        analysis.setAnalyzer(analysisWorker,this::analyzeFrame);
                        cameraProvider.unbindAll();
                        camera=cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis);
                        analysisWorker.execute(evidence::clear);
                        hud.clearDetections();
                        hud.setMessage("离线相机就绪 · "+oriented.getWidth()+"×"+oriented.getHeight());
                        startupCode.setCameraState("READY");
                        return;
                    }catch(Exception e){lastError=e;}
                }
                throw new IllegalStateException("CameraX 不支持预览+分析组合",lastError);
            }catch(Throwable e){cameraError(e);}
        },getMainExecutor());
    }

    private void cameraError(Throwable error){
        CrashGuard.note(this,"V8 摄像头异常: "+android.util.Log.getStackTraceString(error));
        if(destroyed)return;
        hud.setMessage("摄像头兼容性问题，请重启后使用兼容模式");
        startupCode.setCameraState("ERROR");
    }

    /** Runs on one low-priority analysis executor; no work is done on UI thread. */
    private void analyzeFrame(ImageProxy frame){
        try{
            if(destroyed)return;
            if(!startupValidated){startupValidated=true;CrashGuard.stable(this);}
            if(!objectOn)return;
            long now=SystemClock.elapsedRealtime();
            if(now-lastAnalysis<TARGET_INTERVAL_MS)return;
            lastAnalysis=now;
            if(detector==null && !initializeDetector())return;
            long started=SystemClock.elapsedRealtime();
            Bitmap bitmap=prepareBitmap(frame);
            MPImage image=new BitmapImageBuilder(bitmap).build();
            ObjectDetectorResult result=detector.detect(image);
            List<RegionEvidence.Box> people=new ArrayList<>();
            for(com.google.mediapipe.tasks.components.containers.Detection detection:result.detections()){
                if(detection.categories().isEmpty())continue;
                com.google.mediapipe.tasks.components.containers.Category category=
                    detection.categories().get(0);
                if(!"person".equalsIgnoreCase(category.categoryName()))continue;
                float score=category.score();
                if(score<scoreThreshold)continue;
                RectF rect=detection.boundingBox();
                if(rect.width()<2||rect.height()<2)continue;
                people.add(new RegionEvidence.Box(rect.left,rect.top,rect.right,rect.bottom,score));
            }
            long end=SystemClock.elapsedRealtime();
            evidence.observe(0,people,end);
            List<DetectorHudView.Found> out=new ArrayList<>();
            for(RegionEvidence.Box b:evidence.confirmed(end)){
                out.add(new DetectorHudView.Found(new RectF(b.left,b.top,b.right,b.bottom),"person",b.score));
            }
            consecutiveErrors=0;
            int latency=(int)(end-started);
            int fps=(int)Math.min(1000/Math.max(1,latency),1000/TARGET_INTERVAL_MS);
            int w=bitmap.getWidth(),h=bitmap.getHeight();
            runOnUiThread(()->{
                if(destroyed || !objectOn)return;
                hud.setDetections(out,w,h,fps,latency);
                startupCode.setAiState("LOCAL/ACTIVE");
            });
        }catch(Throwable error){
            // Java exceptions & OOM are recoverable. Native SIGSEGV cannot be caught;
            // avoid experimental GPU delegate, disable inference after the first error.
            consecutiveErrors++;
            objectOn=false;
            CrashGuard.note(this,"V8 本地 AI 错误: "+android.util.Log.getStackTraceString(error));
            runOnUiThread(()->{
                if(destroyed)return;
                hud.setRecognitionState(false);
                hud.clearDetections();
                hud.setMessage("本地 AI 出错，已自动关闭；相机可继续使用");
                startupCode.setAiState("LOCAL/ERROR");
            });
        }finally{
            frame.close(); // Essential to avoid CameraX queue stalls and memory growth.
        }
    }

    /** Model is created lazily on the analysis executor. CPU only, 2 threads. */
    private boolean initializeDetector(){
        try{
            CrashGuard.stage(this,"V8: 加载离线 EfficientDet-Lite0 int8");
            BaseOptions base=BaseOptions.builder()
                .setModelAssetPath("efficientdet_lite0_int8.tflite")
                .build();
            ObjectDetector.ObjectDetectorOptions opts=ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.IMAGE)
                .setScoreThreshold(.25f)
                .build();
            detector=ObjectDetector.createFromOptions(this,opts);
            CrashGuard.stable(this);
            runOnUiThread(()->{if(!destroyed)hud.setMessage("离线 AI 已加载 · 无需网络");});
            return true;
        }catch(Throwable error){
            objectOn=false;
            CrashGuard.note(this,"V8 模型初始化失败: "+android.util.Log.getStackTraceString(error));
            runOnUiThread(()->{
                if(!destroyed){hud.setRecognitionState(false);
                    hud.setMessage("模型初始化失败，已保持摄像头运行；查看启动诊断");
                    startupCode.setAiState("LOCAL/ERROR");}
            });
            return false;
        }
    }

    /** Reuses pixel byte buffer, raw bitmap and rotation canvas instead of allocating MBs each frame. */
    private Bitmap prepareBitmap(ImageProxy frame) {
        int w=frame.getWidth(),h=frame.getHeight();
        int bytes=w*h*4;
        if(rawBitmap==null || rawBitmap.getWidth()!=w || rawBitmap.getHeight()!=h){
            if(rawBitmap!=null)rawBitmap.recycle();
            rawBitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        }
        ImageProxy.PlaneProxy plane=frame.getPlanes()[0];
        ByteBuffer input=plane.getBuffer();
        int stride=plane.getRowStride(),rowBytes=w*4;
        if(stride==rowBytes){
            // Direct buffer copy avoids allocating + copying an extra 8MB at 1080p.
            input.rewind();rawBitmap.copyPixelsFromBuffer(input);
        } else {
            if(pixels==null || pixels.length!=bytes){
                pixels=new byte[bytes];pixelsBuffer=ByteBuffer.wrap(pixels);
            }
            for(int y=0;y<h;y++){
                input.position(y*stride);
                input.get(pixels,y*rowBytes,rowBytes);
            }
            pixelsBuffer.rewind();rawBitmap.copyPixelsFromBuffer(pixelsBuffer);
        }
        int rotation=frame.getImageInfo().getRotationDegrees();
        if(rotation==0)return rawBitmap;
        int ow=(rotation==90||rotation==270)?h:w;
        int oh=(rotation==90||rotation==270)?w:h;
        if(rotatedBitmap==null || rotatedBitmap.getWidth()!=ow || rotatedBitmap.getHeight()!=oh){
            if(rotatedBitmap!=null)rotatedBitmap.recycle();
            rotatedBitmap=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);
            rotatedCanvas=new Canvas(rotatedBitmap);
        }
        rotationMatrix.reset();
        rotationMatrix.setRotate(rotation);
        if(rotation==90)rotationMatrix.postTranslate(h,0);
        else if(rotation==180)rotationMatrix.postTranslate(w,h);
        else if(rotation==270)rotationMatrix.postTranslate(0,w);
        rotatedCanvas.drawColor(Color.TRANSPARENT,android.graphics.PorterDuff.Mode.CLEAR);
        rotatedCanvas.drawBitmap(rawBitmap,rotationMatrix,conversionPaint);
        return rotatedBitmap;
    }



    @Override public void onRecognitionChanged(boolean enabled){
        objectOn=enabled;
        if(!enabled){
            hud.clearDetections();
            analysisWorker.execute(evidence::clear);
        }
        hud.setMessage(enabled?"本地人物识别开启 · CPU稳定模式":"本地识别已暂停");
        startupCode.setAiState(enabled?"LOCAL/STARTING":"LOCAL/OFF");
    }
    @Override public void onSensitivityChanged(float threshold){scoreThreshold=threshold;}
    @Override public void onPoseChanged(boolean enabled){
        hud.setPoseState(false);
        hud.setMessage("V8 极速模式暂不加载骨骼模型，避免卡顿");
    }
    @Override public void onNightChanged(boolean enabled){
        if(camera==null)return;
        try{
            androidx.camera.core.ExposureState state=camera.getCameraInfo().getExposureState();
            if(state.isExposureCompensationSupported()){
                int min=state.getExposureCompensationRange().getLower();
                int max=state.getExposureCompensationRange().getUpper();
                camera.getCameraControl().setExposureCompensationIndex(
                    enabled?Math.max(min,Math.min(max,2)):0);
            }else hud.setMessage("本机不支持曝光补偿");
        }catch(Exception e){hud.setMessage("夜间增强不可用");}
    }
    @Override public void onRotatePressed(){
        requestedPortrait=!requestedPortrait;
        getSharedPreferences("zy",MODE_PRIVATE).edit().putBoolean("portrait",requestedPortrait).apply();
        setRequestedOrientation(requestedPortrait?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config){
        super.onConfigurationChanged(config);
        if(preview!=null)preview.postDelayed(this::startCamera,200);
    }
    @Override public void onClosePressed(){finish();}
    @Override public void onHelpPressed(){
        new AlertDialog.Builder(this).setTitle("ZY辅助 V8 · 纯离线极速版")
            .setMessage("默认 CPU 稳定模式：EfficientDet-Lite0 int8，320×320 模型。\n\n"
                +"使用手机本地推理，不上传图片、不需要 API Key 或服务器。\n\n"
                +"图像以约 640×360 采集；根据实际设备性能自动丢弃多余帧，目标间隔 125ms。\n\n"
                +"人物检测采用 3 次中至少 2 次观察确认，尽量减少误报。\n\n"
                +"如果本地模型初始化失败，将自动关闭 AI，摄像头继续运行。\n\n"
                +"骨骼和远距多分块暂不开启，以保障低卡顿。\n\n"
                +"无法承诺绝不闪退或固定帧率，最终以手机测试为准。")
            .setPositiveButton("知道了",null).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        objectOn=false;
        if(cameraProvider!=null){try{cameraProvider.unbindAll();}catch(Exception ignored){}}
        if(analysisWorker!=null){
            analysisWorker.execute(()->{
                if(detector!=null){try{detector.close();}catch(Throwable ignored){}detector=null;}
                if(rawBitmap!=null){rawBitmap.recycle();rawBitmap=null;}
                if(rotatedBitmap!=null){rotatedBitmap.recycle();rotatedBitmap=null;}
            });
            analysisWorker.shutdown();
        }
        super.onDestroy();
    }
}

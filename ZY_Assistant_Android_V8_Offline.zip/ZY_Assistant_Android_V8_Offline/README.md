# ZY辅助 V8 · 本地离线极速版

本工程从之前 ZY辅助 V7 的相机、HUD 和安全启动逻辑迭代。

- 不使用云端 API，不保留 Roboflow 密钥或网络权限。
- 使用 Google MediaPipe Tasks Vision 0.10.35 + EfficientDet-Lite0 int8（COCO 类别 `person`）。
- APK 构建时从 Google 官方模型地址下载 .tflite，打包在 APK 内；**安装后完全离线**。
- CameraX RGBA 分析，640×360 优先，单后台分析线程，KEEP_ONLY_LATEST，丢弃过期帧。
- 尝试每 125ms 分析，实际吞吐取决于手机 CPU、相机和画面转换；不能保证固定 FPS。
- CPU 模型（不启用不稳定的 GPU delegate），异常时自动关 AI 但保留相机，内存复用。
- 人物观测 3 帧内命中至少 2 帧确认，置信度默认 0.25，可由界面调整。
- 骨骼估计、远距多分块暂不启用，先优先运行稳定。
- 黑色胶囊、毛玻璃面板、横竖屏和启动过渡保留。

## 构建（GitHub Actions）

1. 将完整工程压缩包放到仓库根目录，名称 `ZY_Assistant_Android_V8_Offline.zip`。
2. 将提供的 `build_zy_v8_offline.yml` 上传到 `.github/workflows/`。
3. Actions -> `ZY V8 Offline Local APK` -> Run workflow。
4. 成功后在 Artifacts 下载 `ZY-Assistant-V8-Offline-debug-APK`。
5. 首次使用打开相机，按黑色胶囊里 `AI识别` 开启本地检测。

## 模型来源、许可证

EfficientDet-Lite0 int8 官方地址：https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/latest/efficientdet_lite0.tflite
模型基于 COCO 人物类别检测。构建时下载模型；离线运行本身不依赖 Google Play 服务或网络。
MediaPipe 和模型原始许可请参考 Google 发布页面与依赖中的 LICENSE。

## 重要说明

- 本地容器没有 Android SDK 和 Google 模型下载网络，因此这里不能进行完整 APK 构建或真机闪退验证。
- `CrashGuard` 可以诊断 Java 错误并自动进入兼容模式，但 native 崩溃、OOM 杀进程、设备驱动问题无法保证完全消除。
- 如 Actions 报错请提供具体日志再修复；不要声称已验证或保证 0 崩溃。
